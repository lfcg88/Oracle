connect jf/jf

select first_name from vpd.employees;

select first_name from vpd.employees;

select last_name from vpd.employees;

select salary from vpd.employees;

select commission_pct from vpd.employees;
