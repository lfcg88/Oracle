connect vpd/vpd

CREATE CONTEXT vpd_context USING vpd.app_security_context;
