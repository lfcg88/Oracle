
select * from FD."&recycle_bin_name";
