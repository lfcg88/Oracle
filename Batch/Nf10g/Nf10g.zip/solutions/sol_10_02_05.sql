
-- First session

select time_suggested, reason 
from dba_alert_history
where object_name='UT2';
