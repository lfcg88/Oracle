connect jf/jf

select first_name from vpd.employees;

select first_name from vpd.employees;

select last_name from vpd.employees;

select salary from vpd.employees;
