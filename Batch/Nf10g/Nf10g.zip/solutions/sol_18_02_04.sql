
drop table names;

alter session set nls_sort = binary;
