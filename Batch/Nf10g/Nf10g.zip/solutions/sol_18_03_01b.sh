
sqlplus sh/sh
