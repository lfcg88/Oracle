
select * from emp;

select blocks from dba_free_space where tablespace_name='TBSFD';
