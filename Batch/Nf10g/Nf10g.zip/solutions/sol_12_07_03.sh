
rm -rf /home/oracle/tape
