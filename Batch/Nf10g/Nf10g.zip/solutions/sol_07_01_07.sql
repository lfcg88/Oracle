
drop table t1;

