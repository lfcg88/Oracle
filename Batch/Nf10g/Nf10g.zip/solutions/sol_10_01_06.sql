
select reason,resolution
from dba_alert_history
where object_name='TBSALERT';
