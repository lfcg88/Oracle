
connect dp/dp

select table_name from user_tables;
