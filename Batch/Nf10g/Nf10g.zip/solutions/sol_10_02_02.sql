
-- First session
alter system set undo_tablespace=UT2;
