
set echo on

connect / as sysdba

ALTER DISKGROUP dgroup1 DROP DISK DGROUP1_0004;
