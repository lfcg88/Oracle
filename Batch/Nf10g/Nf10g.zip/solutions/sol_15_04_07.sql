connect / as sysdba

alter tablespace tbsasm offline;
