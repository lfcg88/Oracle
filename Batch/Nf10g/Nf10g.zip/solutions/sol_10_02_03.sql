
-- Second session

@$HOME/labs/lab_10_02_03.sql
