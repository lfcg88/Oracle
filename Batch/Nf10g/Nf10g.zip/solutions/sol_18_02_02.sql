
set echo on

connect hr/hr

select * from names 
order by first_name;
