connect / as sysdba

ALTER TABLESPACE TBSBF RESIZE 10M;
