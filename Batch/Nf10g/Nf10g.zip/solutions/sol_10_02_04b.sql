
-- First session

@$HOME/labs/lab_10_02_04b.sql
