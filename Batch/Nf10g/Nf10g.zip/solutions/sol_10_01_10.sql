
@$HOME/labs/lab_10_01_10.sql
