connect mh/mh

select first_name from vpd.employees;

select last_name from vpd.employees;

select last_name as ln from vpd.employees;

select salary from vpd.employees;
