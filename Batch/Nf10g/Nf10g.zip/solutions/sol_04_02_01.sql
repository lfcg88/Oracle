
connect / as sysdba

shutdown immediate;

startup pfile=$HOME/labs/init_sgalab.ora;
