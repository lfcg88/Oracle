connect / as sysdba

select * from v$recovery_file_dest;

