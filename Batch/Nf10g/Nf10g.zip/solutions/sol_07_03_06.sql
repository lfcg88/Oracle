
@$ORACLE_HOME/rdbms/admin/utlxrw.sql
