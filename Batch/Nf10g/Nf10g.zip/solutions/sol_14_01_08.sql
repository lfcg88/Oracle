connect / as sysdba

drop tablespace tbs_lfszadv including contents and datafiles;

shutdown immediate;

startup;
