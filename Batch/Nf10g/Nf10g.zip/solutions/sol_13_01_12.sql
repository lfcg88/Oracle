
purge table dept2;
