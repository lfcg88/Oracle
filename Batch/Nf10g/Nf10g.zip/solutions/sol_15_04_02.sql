connect / as sysdba

alter tablespace tbsasm offline;

alter tablespace tbsasm online;
