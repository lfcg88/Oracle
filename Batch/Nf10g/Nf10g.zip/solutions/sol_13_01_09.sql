
flashback table FD."&recycle_bin_name" to before drop;

-- flashback table FD.EMP to before drop;
