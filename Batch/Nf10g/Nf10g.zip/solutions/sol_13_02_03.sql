
connect / as sysdba

shutdown immediate;

startup mount;

alter database archivelog;

alter database flashback on;

alter database open;
