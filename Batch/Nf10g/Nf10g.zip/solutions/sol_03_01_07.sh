
ps -ef | grep orcl
