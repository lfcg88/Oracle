connect / as sysdba

shutdown immediate;
