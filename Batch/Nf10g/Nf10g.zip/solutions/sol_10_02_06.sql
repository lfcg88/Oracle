
-- First session

ALTER TABLESPACE "UT2" ADD DATAFILE 'ut2_2.dbf' SIZE 10M;
