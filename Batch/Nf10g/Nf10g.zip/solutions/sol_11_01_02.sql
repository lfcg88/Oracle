connect / as sysdba

ALTER TABLESPACE tbsbf ADD DATAFILE 'tbsbf2.dbf' SIZE 5M;
