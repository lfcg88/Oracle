
drop table s1;
