
connect / as sysdba

drop user dp cascade;
