
more /etc/hosts
