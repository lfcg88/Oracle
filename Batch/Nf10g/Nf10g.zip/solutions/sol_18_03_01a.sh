
sqlplus / as sysdba
