
connect sh/sh

clear break

SELECT time_id, prod_id, quantity_sold qs
FROM   s1;

