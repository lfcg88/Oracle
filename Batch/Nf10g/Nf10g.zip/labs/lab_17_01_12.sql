connect / as sysdba

drop user mh cascade;

drop user jf cascade;

drop user vpd cascade;

drop context vpd_context;
