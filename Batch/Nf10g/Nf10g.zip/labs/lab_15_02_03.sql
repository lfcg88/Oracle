
host dd if=/dev/zero of=/u02/asmdisks/disk4 bs=1024k count=200
