
delete employees1 where department_id=50; 
commit;

delete employees2 where department_id=50; 
commit;

delete employees3 where department_id=50; 
commit;
