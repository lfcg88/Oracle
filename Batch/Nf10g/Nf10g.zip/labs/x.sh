kill -9 19991
