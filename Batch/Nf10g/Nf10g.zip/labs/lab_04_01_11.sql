
connect / as sysdba

drop user addm cascade;

drop tablespace tbsaddm including contents and datafiles;

drop tablespace tbsaddm2 including contents and datafiles;
