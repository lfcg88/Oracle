
set echo on

connect sh/sh

drop materialized view my_mv;
