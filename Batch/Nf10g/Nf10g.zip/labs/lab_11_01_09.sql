connect / as sysdba

drop tablespace tbsbf including contents and datafiles;
