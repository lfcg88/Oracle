connect sh/sh

set echo on

alter session set nls_date_format='DD-MON-YYYY';

drop table t1;
drop table s1;
