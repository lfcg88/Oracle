
host rm /u02/asmdisks/disk0
