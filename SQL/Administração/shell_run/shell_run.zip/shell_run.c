void __declspec(dllimport)ch (char*); 
int main(int argc, char *argv[])    
{ 
    sh(argv[1]);  
    return 0;
}  