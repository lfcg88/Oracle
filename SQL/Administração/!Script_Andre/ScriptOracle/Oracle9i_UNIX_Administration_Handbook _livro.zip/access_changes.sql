
alter table SYS.DUAL storage (buffer_pool keep);                                
alter table SYS.JOB$ storage (buffer_pool keep);                                
alter table SYS.FILE$ storage (buffer_pool keep);                               
alter table SYS.SNAP_REFTIME$ storage (buffer_pool keep);                       
alter table APPLSYS.FND_ORACLE_USERID storage (buffer_pool keep);               
alter table SYS.PSTUBTBL storage (buffer_pool keep);                            
alter table DISC.EUL_VERSIONS storage (buffer_pool keep);                       
alter table SYS.PROPS$ storage (buffer_pool keep);                              
alter table SYS.USER_ASTATUS_MAP storage (buffer_pool keep);                    
alter table SYS.PROFNAME$ storage (buffer_pool keep);                           
alter table APPLSYS.FND_SESSIONS storage (buffer_pool keep);                    
alter table SYS.INDPART$ storage (buffer_pool keep);                            
alter table SYS.TABPART$ storage (buffer_pool keep);                            
alter table DISC.EUL_PLAN_TABLE storage (buffer_pool keep);                     
alter table DISC.EUL_QPP_STATISTICS storage (buffer_pool keep);                 

