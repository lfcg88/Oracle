drop procedure do_explain;
drop table sqltemp;
drop table plan_table;
