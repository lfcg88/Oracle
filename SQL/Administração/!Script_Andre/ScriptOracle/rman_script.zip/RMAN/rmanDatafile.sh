rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
run { allocate channel d1 type disk;
backup datafile '/data/oracle8/TEST2/dataTEST2.dbf'  
filesperset 2  include current controlfile  
format '/data/oracle8/BACKUP/rman_DF_%d.%t.%p.%c.bus';
}
EOF
