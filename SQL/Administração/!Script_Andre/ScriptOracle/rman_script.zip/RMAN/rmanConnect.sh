rman target rman/rman_oracledba@test2 catalog rman/rman_oracledba@test1

