export ORACLE_SID=TEST2
sqlplus /nolog <<EOF
connect / as sysdba
shutdown immediate
startup mount
exit
EOF
rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
run { allocate channel d1 type disk;
# set until time "to_date('2002-01-29:15:16:53','yyyy-mm-dd:hh24:mi:ss')";
restore database; 
recover database;
alter database open resetlogs;
}
EOF
