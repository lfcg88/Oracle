rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
run { allocate channel d1 type disk;
backup incremental level 1  
filesperset 2
format '/data/oracle8/BACKUP/rman_LVL1_%d.%t.%p.%c.bus'
database;
}
EOF
