export NLS_DATE_FORMAT='DD-MON-RRRR HH24:MI:SS'
export ORACLE_SID=TEST2
sqlplus /nolog <<EOF
connect  / as sysdba
alter system switch logfile;
exit
EOF
rmanA.sh
export ORACLE_SID=TEST3
sqlplus /nolog <<EOF
connect sys/oracledba as sysdba
shutdown abort
startup nomount
exit
EOF
rm /data/oracle8/TEST3/*
rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
connect auxiliary sys/oracledba@test3
run {
# set until time "to_date('2002-01-29:15:16:53','yyyy-mm-dd:hh24:mi:ss')";
# set until time "to_date('30-JAN-2002 10:50:00','dd-mon-YYYY HH24:MI:SS')"; 
set until time '31-JAN-2002 10:51:00';
# set until time 'sysdate-1/1000';
# set until scn = 155534;
allocate auxiliary channel d1 type disk;
allocate auxiliary channel d2 type disk;
duplicate target database to test3;
}
EOF
