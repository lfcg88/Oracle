export ORACLE_SID=TEST2
# sqlplus /nolog <<EOF
# connect rman/rman_oracledba as sysdba
# shutdown abort
# startup 
# exit
# EOF
rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
run { allocate channel d1 type disk;
sql 'Alter tablespace data offline';
restore tablespace data;
recover tablespace data;
sql 'Alter tablespace data online';
}
EOF
