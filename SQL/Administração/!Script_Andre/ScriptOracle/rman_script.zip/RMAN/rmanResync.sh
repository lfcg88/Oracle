export ORACLE_SID=TEST2
# This script will resync the catalog.
rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
resync catalog;
# register database;
EOF
