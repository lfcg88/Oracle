rman target rman/rman_oracledba@test2 catalog rman/rman_oracledba@test1 <<EOF
run {
allocate channel d1 type disk;
restore controlfile;
alter database mount;
restore database;
recover database ;
alter database open resetlogs;
}
EOF
