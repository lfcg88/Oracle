rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
run { allocate channel d1 type disk;
backup tablespace "DATA" filesperset 2  
include current controlfile  
format '/data/oracle8/BACKUP/rman_TBS_%d.%t.%p.%c.bus';
}
EOF
