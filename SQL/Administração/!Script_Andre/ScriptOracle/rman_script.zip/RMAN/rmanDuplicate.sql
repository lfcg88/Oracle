set pages 0
set heading off
set lines 250
set trimspool on
set feedback off
spool rmanDuplicate_temp.sh
prompt export NLS_DATE_FORMAT='DD-MON-RRRR HH24:MI:SS'
prompt export ORACLE_SID=TEST2
prompt sqlplus /nolog <<EOF
prompt connect  / as sysdba
prompt alter system switch logfile;;
prompt alter system archive log all;;
prompt exit
prompt EOF
prompt rmanA.sh
prompt export ORACLE_SID=TEST3
prompt sqlplus /nolog <<EOF
prompt connect sys/oracledba as sysdba
prompt shutdown abort
prompt startup nomount
prompt exit
prompt EOF
prompt rm /data/oracle8/TEST3/*
prompt rman <<EOF
prompt connect target rman/rman_oracledba@test2 
prompt connect catalog rman/rman_oracledba@test1
prompt connect auxiliary sys/oracledba@test3
prompt run {
prompt resync catalog;;
prompt allocate auxiliary channel d1 type disk;;
prompt allocate auxiliary channel d2 type disk;;
prompt # set until time "to_date('2002-01-29:15:16:53','yyyy-mm-dd:hh24:mi:ss')";
prompt # set until time "to_date('30-JAN-2002 10:50:00','dd-mon-YYYY HH24:MI:SS')"; 
prompt # set until time '31-JAN-2002 10:51:00';
prompt # set until time 'sysdate-1/96';;
prompt # set until scn = 155534;
select 'set newname for datafile '||chr(39)||file_name||chr(39)||' TO '||chr(39)||replace(file_name,'TEST2','TEST3')||chr(39)||';' from dba_data_files;
prompt sql 'alter system switch logfile';;
prompt duplicate target database to test3;
prompt LOGFILE
prompt '/data/oracle8/TEST3/redoTEST301.log' size 1M,
prompt '/data/oracle8/TEST3/redoTEST302.log' size 1M,
prompt '/data/oracle8/TEST3/redoTEST303.log' size 1M;;
prompt }
prompt EOF
spool off
host chmod 700 rmanDuplicate_temp.sh
