export NLS_DATE_FORMAT='DD-MON-RRRR HH24:MI:SS'
export ORACLE_SID=TEST2
sqlplus /nolog <<EOF
connect  / as sysdba
alter system switch logfile;
alter system archive log all;
exit
EOF
rmanA.sh
export ORACLE_SID=TEST3
sqlplus /nolog <<EOF
connect sys/oracledba as sysdba
shutdown abort
startup nomount
exit
EOF
rm /data/oracle8/TEST3/*
rman <<EOF
connect target rman/rman_oracledba@test2
connect catalog rman/rman_oracledba@test1
connect auxiliary sys/oracledba@test3
run {
resync catalog;
allocate auxiliary channel d1 type disk;
allocate auxiliary channel d2 type disk;
# set until time "to_date('2002-01-29:15:16:53','yyyy-mm-dd:hh24:mi:ss')"
# set until time "to_date('30-JAN-2002 10:50:00','dd-mon-YYYY HH24:MI:SS')"
# set until time '31-JAN-2002 10:51:00'
# set until time 'sysdate-1/96';
# set until scn = 155534
set newname for datafile '/data/oracle8/TEST2/systemTEST2.dbf' TO '/data/oracle8/TEST3/systemTEST3.dbf';
set newname for datafile '/data/oracle8/TEST2/rbsTEST2.dbf' TO '/data/oracle8/TEST3/rbsTEST3.dbf';
set newname for datafile '/data/oracle8/TEST2/tempTEST2.dbf' TO '/data/oracle8/TEST3/tempTEST3.dbf';
set newname for datafile '/data/oracle8/TEST2/dataTEST2.dbf' TO '/data/oracle8/TEST3/dataTEST3.dbf';
sql 'alter system switch logfile';
duplicate target database to test3
LOGFILE
'/data/oracle8/TEST3/redoTEST301.log' size 1M,
'/data/oracle8/TEST3/redoTEST302.log' size 1M,
'/data/oracle8/TEST3/redoTEST303.log' size 1M;
}
EOF
