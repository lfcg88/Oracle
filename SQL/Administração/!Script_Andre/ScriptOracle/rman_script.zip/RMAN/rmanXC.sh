rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
allocate channel for maintenance type disk;
crosscheck backup of database;
delete expired backup of database;
list backup;
EOF
