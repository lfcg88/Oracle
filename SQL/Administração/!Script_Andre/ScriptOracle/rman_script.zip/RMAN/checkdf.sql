col file_name for a40
connect rman/rman_oracledba as sysdba
select df.file_name, d.status
from dba_data_files df,
v$datafile d
where df.file_id=d.file#;
exit;
