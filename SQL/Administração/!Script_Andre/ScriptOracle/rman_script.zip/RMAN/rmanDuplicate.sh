export ORACLE_SID=TEST2
sqlplus /nolog <<EOF
connect / as sysdba
@rmanDuplicate.sql
exit
EOF>>
