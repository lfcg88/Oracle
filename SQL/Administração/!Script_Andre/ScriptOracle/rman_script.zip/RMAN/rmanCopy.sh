rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
run { allocate channel d1 type disk;
copy datafile '/data/oracle8/TEST2/dataTEST2.dbf' 
to '/data/oracle8/BACKUP/dataTEST2.dbf';
copy datafile '/data/oracle8/TEST2/rbsTEST2.dbf' 
to '/data/oracle8/BACKUP/rbsTEST2.dbf';
copy datafile '/data/oracle8/TEST2/tempTEST2.dbf' 
to '/data/oracle8/BACKUP/tempTEST2.dbf';
copy datafile '/data/oracle8/TEST2/systemTEST2.dbf' 
to '/data/oracle8/BACKUP/systemTEST2.dbf';
copy current controlfile to '/data/oracle8/BACKUP/ctrlTEST201.ctl';
}
EOF
