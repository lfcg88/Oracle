rman <<EOF
connect catalog rman/rman_oracledba@test1
connect target sys/oracledba@test2
list backup;
EOF
