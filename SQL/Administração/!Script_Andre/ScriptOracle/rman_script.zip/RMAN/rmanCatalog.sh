rman <<EOF
connect catalog rman/rman_oracledba@test1
create catalog;
EOF
