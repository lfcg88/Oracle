export ORACLE_SID=TEST2
echo 'shutting down TEST2 ABORT'
sqlplus /nolog <<EOF
connect rman/rman_oracledba as sysdba
shutdown abort
exit
EOF
echo 'removing Controlfile' 
rm /data/oracle8/TEST2/*.ctl
echo 'listing the directory to verify Controlfile does not exist'
ls -l /data/oracle8/TEST2
echo 'starting TEST2 in NOMOUNT mode'
sqlplus /nolog <<EOF
connect rman/rman_oracledba as sysdba
startup nomount
exit
EOF
echo 'Restoring Controlfile using RMAN'    
rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
run { allocate channel d1 type disk;
restore controlfile; 
alter database  mount;
alter database  open resetlogs;
}
EOF
