export ORACLE_SID=TEST2
sqlplus /nolog <<EOF
connect / as sysdba
alter system switch logfile;
EXIT
EOF
rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
run { allocate channel d1 type disk 
format '/data/oracle8/BACKUP/rman_ARC_%s_%p_%t.bus';
# backup archivelog until time 'sysdate-1/24' delete input;
backup archivelog from time 'sysdate-1/24'; 
}
EOF
sqlplus /nolog <<EOF
connect / as sysdba
alter system switch logfile;
EXIT
EOF
