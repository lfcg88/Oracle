export ORACLE_SID=TEST2
echo 'shutting down TEST2 ABORT'
echo
sqlplus /nolog <<EOF
connect rman/rman_oracledba as sysdba
shutdown abort
exit
EOF
echo
echo 'removing datafile /data/oracle8/TEST2/dataTEST2.dbf '
echo
rm /data/oracle8/TEST2/dataTEST2.dbf
echo 'listing the directory to verify datafile does not exist'
ls -l /data/oracle8/TEST2
sleep 5
echo
echo 'starting TEST2 in MOUNT mode'
echo
sqlplus /nolog <<EOF
connect rman/rman_oracledba as sysdba
startup mount
alter database datafile '/data/oracle8/TEST2/dataTEST2.dbf' offline;
alter database open;
exit
EOF
echo
echo 'checking the status of datafiles'
echo
sqlplus /nolog @checkdf.sql
sleep 10
echo 'Restoring datafile using RMAN'    
rman <<EOF
connect target rman/rman_oracledba@test2 
connect catalog rman/rman_oracledba@test1
run { allocate channel d1 type disk;
restore datafile '/data/oracle8/TEST2/dataTEST2.dbf';
recover datafile '/data/oracle8/TEST2/dataTEST2.dbf';
}
EOF
sqlplus /nolog <<EOF
connect rman/rman_oracledba as sysdba
alter database datafile '/data/oracle8/TEST2/dataTEST2.dbf' online;
exit
EOF
echo
echo 'checking the status of datafiles'
echo
sqlplus /nolog @checkdf.sql
