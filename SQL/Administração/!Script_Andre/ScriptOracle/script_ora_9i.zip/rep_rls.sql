REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_rls.sql
REM 
REM Version:     1.0
REM
REM Description: Shows Rowlevel Security and Policy Details
REM              
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   04.07.02
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 80

ACCEPT isObjectOwner CHAR PROMPT 'Object Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT isObjectName CHAR PROMPT 'Object Name or Wildcard <%>: ' DEFAULT '%'

@@title "Policies Report"
COL object_owner FOR a12
COL pf_owner FOR a12
COL p_function FOR a40
SELECT object_owner, object_name, policy_name, pf_owner, package||'.'||function AS p_function,
  sel, ins, upd, del, chk_option, enable
FROM dba_policies
WHERE object_owner LIKE UPPER('&isObjectOwner')
AND object_name LIKE UPPER('&isObjectName');
COL object_owner CLEAR
COL pf_owner CLEAR
COL p_function CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Context Report"
SELECT *
FROM dba_context
WHERE package IN (SELECT package
                  FROM dba_policies
                  WHERE object_owner LIKE UPPER('&isObjectOwner')
                  AND object_name LIKE UPPER('&isObjectName'));

SET PAUSE OFF


SET PAGESIZE 24
