REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        ext_next.sql
REM 
REM Version:     1.2
REM
REM Description: Shows all segments unable to allocate a next extent because
REM              of insufficient space in tablespace
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Checks for Max Extents reached added                     USC   03.10.00
REM Checks for LOB, CLUSTER and ROLLBACK segments            USC   29.01.02
REM -------------------------------------------------------------------------

SET SERVEROUTPUT ON SIZE 100000 FORMAT WORD_WRAPPED
SET PAGESIZE 999 FEED OFF

DECLARE
  nObjects PLS_INTEGER := 0;
  
  CURSOR c1 IS
    SELECT ds.owner owner, ds.segment_name segment_name, ds.partition_name partition_name
    FROM dba_segments ds
    WHERE ds.next_extent > ( SELECT MAX(df.bytes)
                             FROM dba_free_space df
                             WHERE df.tablespace_name = ds.tablespace_name)
    UNION
    SELECT ds.owner owner, ds.segment_name segment_name, ds.partition_name partition_name
    FROM dba_segments ds
    WHERE ds.extents >= ds.max_extents - 1
    AND ds.segment_type IN ('TABLE','INDEX','LOBINDEX','LOBSEGMENT','TABLE PARTITION','INDEX PARTITION','ROLLBACK','CLUSTER')
    ORDER BY owner, segment_name, partition_name;

BEGIN

  FOR c1rec IN c1 LOOP
    nObjects := nObjects + 1;
    IF (c1%ROWCOUNT = 1) THEN
      dbms_output.put_line(CHR(10));
      dbms_output.put_line('Next Extent Allocation Problem found!');
      dbms_output.put_line('-------------------------------------');
      dbms_output.put_line(CHR(10));
      dbms_output.put_line(RPAD('OWNER', 10,' ')||' '||
        RPAD('SEGMENT', 30,' ')||' '||
        RPAD('PARTITION', 30,' '));
      dbms_output.put_line(rpad('-', 10, '-')||' '||
        RPAD('-', 30,'-')||' '||
        RPAD('-', 30,'-'));
    END IF;
    dbms_output.put_line(RPAD(c1rec.owner, 10,' ')||' '||
      RPAD(c1rec.segment_name, 30,' ')||' '||
      RPAD(c1rec.partition_name, 30,' '));
  END LOOP;

  IF nObjects = 0 THEN
    dbms_output.put_line(CHR(10));  
    dbms_output.put_line('No Extent Allocation Problems found.');
    dbms_output.put_line('------------------------------------');    
    dbms_output.put_line(CHR(10));      
  END IF;

EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line(SUBSTR(SQLERRM,1,250));
END;
/

SET FEED ON
