REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_sql.sql
REM 
REM Version:     1.0
REM
REM Description: Reports critical SQL statement statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 120

@@title "SQL Statistic Report"
SELECT t1.value "Fetch by rowid", t2.value "Fetch of Chained Row", t3.value "Full Table Scans"
FROM v$sysstat t1, v$sysstat t2, v$sysstat t3
WHERE t1.name = 'table fetch by rowid'
AND t2.name = 'table fetch continued row'
AND t3.name = 'table scans (long tables)';

@@title "No Bind Variables Report"
set linesize 100
COL sql_text FOR a60
SELECT substr(v1.sql_text,1,60) sql_text, count(*)
FROM v$sqlarea v1
GROUP BY substr(v1.sql_text,1,60)
HAVING count(*) > 100;
COL sql_text CLEAR

SET PAGESIZE 24