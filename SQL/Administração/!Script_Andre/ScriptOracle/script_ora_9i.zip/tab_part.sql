REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         tab_part.sql
REM 
REM Version:      2.2
REM
REM Requirements: Oracle9iR2
REM
REM Description:  Shows partitioned table details
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   06.12.00
REM Added Subpartitioning support                            USC   13.06.01
REM Added Compression details                                USC   24.03.03
REM Added Subpartitionkey report                             USC   13.06.03
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 48

ACCEPT sOwnerName CHAR PROMPT 'Table Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT sTableName CHAR PROMPT 'Tablename: ' DEFAULT '-'

@@title "Table Partition Report"
COL owner FOR a10
COL column_name HEAD "PARTITION-KEY" FOR a20 
COL row_movement HEAD "ROW-|MOVEMENT"
COL partition_count HEAD "PARTITIONS"
BREAK ON owner ON table_name ON row_movement ON type ON partition_count
SELECT t1.owner, t1.table_name, t1.row_movement, t2.partitioning_type type, t2.partition_count,
  t3.column_name
FROM dba_tables t1, dba_part_tables t2, dba_part_key_columns t3
WHERE t1.owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
AND t1.partitioned = 'YES'
AND t2.owner = t1.owner
AND t2.table_name = t1.table_name
AND t3.owner = t1.owner
AND t3.name = t1.table_name
ORDER BY t3.column_position ASC;
COL owner CLEAR
COL column_name CLEAR
COL row_movement CLEAR
COL partition_count CLEAR
CLEAR BREAKS

@@title "Table Subpartition Report"
COL owner FOR a10
COL column_name HEAD "SUBPARTITION-KEY" FOR a20 
BREAK ON owner ON table_name ON type
SELECT t1.owner, t1.table_name, t2.subpartitioning_type type, t3.column_name
FROM dba_tables t1, dba_part_tables t2, dba_subpart_key_columns t3
WHERE t1.owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
AND t1.partitioned = 'YES'
AND t2.owner = t1.owner
AND t2.table_name = t1.table_name
AND t3.owner = t1.owner
AND t3.name = t1.table_name
ORDER BY t3.column_position ASC;
COL owner CLEAR
COL column_name CLEAR
CLEAR BREAKS

@@title "Table Partition Default Report"
COL owner FOR a10
COL def_initial FOR a12 HEAD "DEF INITIAL|(BLOCKS)"
COL def_next FOR a12 HEAD "DEF NEXT|(BLOCKS)"
COL def_pct_free HEAD "DEF|PCT_FREE"
COL def_pct_used HEAD "DEF|PCT_USED"
COL def_logging HEAD "LOG-|GING"
COL def_compression FOR a12 HEAD "COMPR-|ESSION"
COL def_buffer_pool HEAD "BUFFER-|POOL"
SELECT t1.owner, t1.table_name, 
  t2.def_initial_extent def_initial, t2.def_next_extent def_next, 
  t2.def_pct_free, t2.def_pct_used,
  t2.def_tablespace_name,
  t2.def_logging, t2.def_compression, t2.def_buffer_pool
FROM dba_tables t1, dba_part_tables t2
WHERE t1.owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
AND t1.partitioned = 'YES'
AND t2.owner = t1.owner
AND t2.table_name = t1.table_name;
COL owner CLEAR
COL def_initial CLEAR
COL def_next CLEAR
COL def_pct_free CLEAR
COL def_pct_used CLEAR
COL def_logging CLEAR
COL def_compression CLEAR
COL def_buffer_pool CLEAR

@@title "Table Partition Detail Report"
COL partition_name FOR a30
COL ranges FOR a50
COL subpartition_count FOR 999 HEAD "SUB|PARTS"
COL composite FOR a5 HEAD "COMP-|OSITE"
COL compression FOR a12 HEAD "COMPRESSION"
COL buffer_pool HEAD "BUFFER-|POOL"
SELECT partition_name, tablespace_name, high_value ranges, subpartition_count, composite, logging, compression, buffer_pool
FROM dba_tab_partitions
WHERE table_owner LIKE UPPER('&sOwnerName')
AND table_name = upper('&sTableName')
ORDER BY partition_position ASC;
COL partition_name CLEAR
COL ranges CLEAR
COL subpartition_count CLEAR
COL composite CLEAR
COL compression CLEAR
COL buffer_pool CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Table Partition Space Usage Report"
COL partition_name FOR a30
COL intial_MB FOR 9999.00 HEAD "INTIAL|(MB)"
COL next_MB FOR 9999.00 HEAD "NEXT|(MB)"
COL extents HEAD "EX-|TENTS" FOR 99999 JUS L 
COL bytes_mb HEAD "SPACE|USAGE(MB)" FOR 999999.00 JUS L
COL part_position NOPRINT
COL subpart_position NOPRINT
BREAK ON partition_name
SELECT t1.partition_name, NULL subpartition_name, t1.tablespace_name, 
  t1.initial_extent/1024/1024 intial_MB, t1.next_extent/1024/1024 next_MB,
  t1.pct_free, t1.pct_used,
  t2.extents, t2.bytes/1024/1024 bytes_mb, t1.partition_position part_position, 1 subpart_position
FROM dba_tab_partitions t1, dba_segments t2
WHERE t1.table_owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
AND t1.table_owner = t2.owner
AND t1.table_name = t2.segment_name
AND t1.partition_name = t2.partition_name
UNION
-- Subpartitioned Table
SELECT t2.partition_name, t2.subpartition_name, t2.tablespace_name, 
  t2.initial_extent/1024/1024 intial_MB, t2.next_extent/1024/1024 next_MB,
  t2.pct_free, t2.pct_used,  
  t3.extents, t3.bytes/1024/1024 bytes_mb, t1.partition_position part_position, t2.subpartition_position subpart_position
FROM dba_tab_partitions t1, dba_tab_subpartitions t2, dba_segments t3
WHERE t1.table_owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
AND t1.table_owner = t2.table_owner
AND t1.table_name = t2.table_name
AND t1.partition_name = t2.partition_name
AND t2.table_owner = t3.owner
AND t2.table_name = t3.segment_name
AND t2.subpartition_name = t3.partition_name
ORDER BY part_position, subpart_position ASC;
COL part_position CLEAR
COL subpart_position CLEAR
COL partition_name CLEAR
COL intial_MB CLEAR
COL next_MB CLEAR
COL bytes_mb CLEAR
COL extents CLEAR
CLEAR BREAKS

SET DOCU OFF 
/*
@@title "Table Partition Storage Report"
COL partition_name FOR a30
COL pct_free HEAD "PCT|FREE" FOR 999 JUS L
COL pct_used HEAD "PCT|USED" FOR 999 JUS L 
COL ini_trans HEAD "INI|TRANS" FOR 999 JUS L
COL max_trans HEAD "MAX|TRANS" FOR 999 JUS L
COL min_extent HEAD "MIN|EXTENTS" FOR 999 JUS L
COL max_extent HEAD "MAX|EXTENTS" JUS L
COL pct_increase HEAD "PCT|INCR" FOR 999 JUS L
COL freelists HEAD "FREE|LISTS" FOR 999 JUS L
COL freelist_groups HEAD "FREELIST|GROUPS" FOR 999 JUS L
BREAK ON partition_name
COL part_position NOPRINT
COL subpart_position NOPRINT
-- Partitioned Table (non subpartitioned)
SELECT t1.partition_name, NULL subpartition_name, t1.tablespace_name, t1.min_extent, t1.max_extent, t1.pct_increase, t1.pct_free, t1.pct_used,
 t1.ini_trans, t1.max_trans, t1.freelists, t1.freelist_groups, t1.partition_position part_position, 0 subpart_position
FROM dba_tab_partitions t1
WHERE t1.table_owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
UNION
-- Subpartitioned Table
SELECT t2.partition_name, t2.subpartition_name, t2.tablespace_name, t2.min_extent, t2.max_extent, t2.pct_increase, t2.pct_free, t2.pct_used,
  t2.ini_trans, t2.max_trans, t2.freelists, t2.freelist_groups, t1.partition_position part_position, t2.subpartition_position subpart_position
FROM dba_tab_partitions t1, dba_tab_subpartitions t2
WHERE t1.table_owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
AND t1.table_owner = t2.table_owner
AND t1.table_name = t2.table_name
AND t1.partition_name = t2.partition_name
ORDER BY part_position, subpart_position ASC;
COL part_position CLEAR
COL subpart_position CLEAR
COL partition_name CLEAR
COL pct_free CLEAR
COL pct_used CLEAR
COL ini_trans CLEAR
COL max_trans CLEAR
COL min_extent CLEAR
COL max_extent CLEAR
COL pct_increase CLEAR
COL freelists CLEAR
COL freelist_groups CLEAR
CLEAR BREAKS
*/
SET DOCU ON 

@@title "Table Statistics Report"
COL partition_name FOR a30
COL last_analyzed FOR a17
COL empty_blocks HEAD "EMPTY|BLOCKS" FOR 999999 JUS L
COL avg_row_len HEAD "AVG|ROW_LEN" FOR 999999 JUS L
COL global_stats FOR a7 HEAD "GLOBAL-|STATS"
COL user_stats FOR a5 HEAD "USER-|STATS"
COL sample_size HEAD "SAMPLE-|SIZE"
COL part_position NOPRINT
COL subpart_position NOPRINT
COL avg_space FOR 99999 HEAD "AVG|SPACE"
BREAK ON partition_name
SELECT t1.partition_name, NULL subpartition_name, t1.last_analyzed, t1.num_rows, t1.blocks, t1.empty_blocks, t1.avg_space, t1.chain_cnt, 
  t1.avg_row_len, t1.sample_size, t1.global_stats, t1.user_stats, t1.partition_position part_position, 0 subpart_position
FROM dba_tab_partitions t1
WHERE t1.table_owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
UNION
SELECT t2.partition_name, t2.subpartition_name, t2.last_analyzed, t2.num_rows, t2.blocks, t2.empty_blocks, t2.avg_space, t2.chain_cnt, 
  t2.avg_row_len, t2.sample_size, t2.global_stats, t2.user_stats, t1.partition_position part_position, t2.subpartition_position subpart_position
FROM dba_tab_partitions t1, dba_tab_subpartitions t2
WHERE t1.table_owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
AND t1.table_owner = t2.table_owner
AND t1.table_name = t2.table_name
AND t1.partition_name = t2.partition_name
ORDER BY part_position, subpart_position ASC;
COL part_position CLEAR
COL subpart_position CLEAR
COL partition_name CLEAR
COL last_analyzed CLEAR
COL avg_row_len CLEAR
COL empty_blocks CLEAR
COL global_stats CLEAR
COL user_stats CLEAR
COL sample_size CLEAR
COL avg_space CLEAR
CLEAR BREAKS

SET PAUSE OFF
