REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        tab_rep.sql
REM 
REM Version:     1.1
REM
REM Description: Shows table details
REM              
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   06.12.00
REM Remove of table_name display and added support for
REM temporary tables                                         USC   20.08.02
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 80

ACCEPT isTableOwner CHAR PROMPT 'Table Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT isTableName CHAR PROMPT 'Table Name: ' DEFAULT '-'

@@title "Table Desc Report"
COL Type FOR a15
COL data_default FOR a20 WRAP
SELECT column_name AS "Name", DECODE(nullable, 'Y', NULL, 
                                               'N', 'NOT NULL') AS "Null?", 
  data_type||DECODE(data_type, 'VARCHAR2', '('||data_length||')',
                               'NUMBER', NVL2(data_precision, '('||data_precision||')', ''))  AS "Type",
  data_default
FROM dba_tab_columns 
WHERE owner LIKE UPPER('&isTableOwner')
AND table_name = UPPER('&isTableName')
ORDER BY column_id;
COL Type CLEAR
COL data_default CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Table Report"
COL owner FOR a12
COL logging HEAD "LOGG-|ING" FOR a5
COL buffer_pool HEAD "BUFFER|POOL" JUS L
COL partitioned HEAD "PARTI-|TIONED" FOR a6 JUS L
COL iot_type HEAD "IOT-|TYPE" FOR a4
COL temporary HEAD "TEMPORARY" FOR a9
COL created FOR a20
COL last_ddl_time FOR a20
SELECT t1.owner, t1.degree, t1.logging, t1.cache, t1.buffer_pool, t1.partitioned, t1.iot_type, t1.temporary, t1.duration,
  t2.created, t2.last_ddl_time
FROM dba_objects t2, dba_tables t1
WHERE t1.owner LIKE UPPER('&isTableOwner')
AND t1.table_name = UPPER('&isTableName')
AND t1.owner = t2.owner
AND t1.table_name = t2.object_name
AND t2.object_type = 'TABLE';
COL logging CLEAR
COL iot_type CLEAR
COL buffer_pool CLEAR
COL partitioned CLEAR
COL created CLEAR
COL temporary CLEAR
COL last_ddl_time CLEAR
COL owner CLEAR

SET PAUSE OFF

@@title "Table Index Report"
COL owner FOR a12
COL column_name FOR a32
COL partitioned FOR a6 HEAD "PARTI-|TIONED"
BREAK ON owner ON index_name ON partitioned ON index_type ON uniqueness ON status
SELECT i.owner owner, i.index_name index_name, i.partitioned partitioned, i.index_type index_type, i.uniqueness uniqueness, 
  i.status status, c.column_name
FROM dba_ind_columns c, dba_indexes i
WHERE i.table_name = UPPER('&isTableName')
AND i.table_owner LIKE UPPER('&isTableOwner')
AND i.owner = c.index_owner
AND i.index_name = c.index_name
AND i.table_owner = c.table_owner
AND i.table_name = c.table_name
ORDER BY 1,2,c.column_position ASC;
CLEAR BREAKS
COL owner CLEAR
COL column_name CLEAR
COL partitioned CLEAR

@@title "Table Storage Report"
COL pct_free HEAD "PCT|FREE" FOR 999 JUS L
COL pct_used HEAD "PCT|USED" FOR 999 JUS L 
COL ini_trans HEAD "INI|TRANS" FOR 999 JUS L
COL max_trans HEAD "MAX|TRANS" FOR 999 JUS L
COL initial_extent FOR 9999.00 HEAD "INTIAL (MB)"
COL next_extent FOR 9999.00 HEAD "NEXT (MB)"
COL min_extents HEAD "MIN|EXTENTS" FOR 999 JUS L
COL max_extents HEAD "MAX|EXTENTS" JUS L
COL pct_increase HEAD "PCT|INCR" FOR 999 JUS L
COL freelists HEAD "FREE|LISTS" FOR 999 JUS L
COL freelist_groups HEAD "FREELIST|GROUPS" FOR 999 JUS L
COL extents HEAD "EX-|TENTS" FOR 99999 JUS L 
COL bytes_mb HEAD "SPACE|USAGE(MB)" FOR 999999.00 JUS L
SELECT t1.tablespace_name, t1.initial_extent/1024/1024 initial_extent, t1.next_extent/1024/1024 next_extent, 
  t2.extents, t2.bytes_mb,
  t1.min_extents, t1.max_extents, t1.pct_increase, t1.freelists, t1.freelist_groups,
  t1.pct_free, t1.pct_used, t1.ini_trans, t1.max_trans
FROM dba_tables t1, (SELECT SUM(extents) extents, SUM(bytes/1024/1024) bytes_mb
                     FROM dba_segments
                     WHERE owner LIKE UPPER('&isTableOwner')
                     AND segment_name = UPPER('&isTableName')) t2
WHERE t1.owner LIKE UPPER('&isTableOwner')
AND t1.table_name = UPPER('&isTableName');
COL pct_free CLEAR
COL pct_used CLEAR
COL ini_trans CLEAR
COL max_trans CLEAR
COL initial_extent CLEAR
COL next_extent CLEAR
COL min_extents CLEAR
COL max_extents CLEAR
COL pct_increase CLEAR
COL freelists CLEAR
COL freelist_groups CLEAR
COL bytes_mb CLEAR
COL extents CLEAR

@@title "Table Statistics Report"
COL last_analyzed FOR a20
COL empty_blocks HEAD "EMPTY|BLOCKS" FOR 999999 JUS L
COL avg_row_len HEAD "AVG|ROW_LEN" FOR 999999 JUS L
COL global_stats FOR a7 HEAD "GLOBAL-|STATS"
COL user_stats FOR a5 HEAD "USER-|STATS"
SELECT t1.last_analyzed, t1.num_rows, t1.blocks, t1.empty_blocks, t1.avg_space, t1.chain_cnt, 
  t1.avg_row_len, t1.sample_size, t1.global_stats, t1.user_stats
FROM dba_tables t1
WHERE t1.owner LIKE UPPER('&isTableOwner')
AND t1.table_name = UPPER('&isTableName');
COL last_analyzed CLEAR
COL avg_row_len CLEAR
COL empty_blocks CLEAR
COL global_stats CLEAR
COL user_stats CLEAR

SET PAGESIZE 24
