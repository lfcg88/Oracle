REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        reset.sql
REM 
REM Version:     1.0
REM
REM Description: Resets SQLPlus settings to startup defaults
REM              
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   11.11.03
REM -------------------------------------------------------------------------

SET TERMOUT OFF
@@sqlplus_settings
CLEAR BREAKS
CLEAR COLUMNS
CLEAR COMPUTES
SET TERMOUT ON

CLEAR SCREEN

@@login
