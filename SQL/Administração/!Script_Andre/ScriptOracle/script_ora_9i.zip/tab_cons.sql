REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        tab_cons.sql
REM 
REM Version:     1.1
REM
REM Description: Shows table constraints
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Table Owner search by wildcard added                     USC   17.11.03
REM -------------------------------------------------------------------------

SET ECHO OFF VERIFY OFF LINESIZE 160 PAGESIZE 48 LONG 80

ACCEPT sOwnerName CHAR PROMPT 'Table Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT sTableName CHAR PROMPT 'Tablename: ' DEFAULT '-'

@@title "Table Constraints Report"
COL owner FOR a10
COL validated FOR a15
BREAK ON owner
SELECT f.owner, f.constraint_name, f.constraint_type, f.delete_rule, f.status, f.deferrable, f.deferred,
  f.validated, f.bad, f.rely, f.last_change
FROM dba_constraints f
WHERE f.owner LIKE UPPER('&sOwnerName')
AND f.table_name = UPPER('&sTableName')
ORDER BY f.owner, f.constraint_name;
CLEAR BREAKS
COL owner CLEAR
COL validated CLEAR

@@title "Table PK,FK Constraint Columns Report"
COL owner FOR a10
COL column_name FOR a20
BREAK ON owner ON constraint_name ON constraint_type
SELECT t1.owner, t1.constraint_name, t1.constraint_type, t2.column_name
FROM dba_constraints t1, dba_cons_columns t2
WHERE t1.owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
AND t1.constraint_type IN ('P','R')
AND t1.owner = t2.owner
AND t1.constraint_name = t2.constraint_name
AND t1.table_name = t2.table_name
ORDER BY t1.owner, t1.constraint_name, t2.position;
CLEAR BREAKS
COL owner CLEAR
COL column_name CLEAR


@@title "Table Ceck Constraint Columns Report"
COL owner FOR a10
COL column_name FOR a20
BREAK ON owner
SELECT t1.owner, t1.constraint_name, t2.column_name, t1.search_condition
FROM dba_constraints t1, dba_cons_columns t2
WHERE t1.owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sTableName')
AND t1.constraint_type = 'C'
AND t1.owner = t2.owner
AND t1.constraint_name = t2.constraint_name
AND t1.table_name = t2.table_name
ORDER BY t1.owner, t1.constraint_name;
CLEAR BREAKS
COL owner CLEAR
COL column_name CLEAR

PROMPT HINT: For UK and PK index information see tab_rep.sql

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Table FK to PK Relationship Report"
COL fk_owner FOR a10
COL fk_name FOR a30
COL pk_owner FOR a10
COL pk_name FOR a30
COL pk_table FOR a30
COL column_name FOR a20
BREAK ON fk_owner ON fk_name ON pk_owner ON pk_table ON pk_name
SELECT f.owner fk_owner, f.constraint_name fk_name,  
  p.owner pk_owner, p.table_name pk_table, p.constraint_name pk_name, pc.column_name 
FROM dba_constraints f, dba_constraints p, dba_cons_columns pc
WHERE f.owner LIKE UPPER('&sOwnerName')
AND f.table_name = UPPER('&sTableName')
AND f.constraint_type = 'R'
AND f.r_owner = p.owner (+)
AND f.r_constraint_name = p.constraint_name (+)
AND p.owner = pc.owner
AND p.table_name = pc.table_name
AND p.constraint_name = pc.constraint_name
ORDER BY f.owner, f.constraint_name, p.table_name, p.constraint_name;
CLEAR BREAKS
COL fk_owner CLEAR
COL fk_name CLEAR
COL pk_owner CLEAR
COL pk_name CLEAR
COL pk_table CLEAR
COL column_name CLEAR

@@title "Table PK to FK Relationship Report"
COL pk_owner FOR a10
COL pk_name FOR a30
COL column_name FOR a20
COL fk_owner FOR a10
COL fk_table FOR a30
COL fk_name FOR a30
BREAK ON pk_owner ON pk_name ON fk_owner ON fk_table ON fk_name
SELECT p.owner pk_owner, p.constraint_name pk_name, 
  f.owner fk_owner, f.table_name fk_table, f.constraint_name fk_name, fc.column_name, f.delete_rule
FROM dba_constraints p, dba_cons_columns fc, dba_constraints f
WHERE p.owner LIKE UPPER('&sOwnerName')
AND p.table_name = UPPER('&sTableName')
AND p.constraint_type = 'P'
AND p.owner = f.r_owner
AND p.constraint_name = f.r_constraint_name
AND f.constraint_type = 'R'
AND f.owner = fc.owner
AND f.table_name = fc.table_name
AND f.constraint_name = fc.constraint_name
ORDER BY p.owner, p.constraint_name, f.owner, f.table_name, f.constraint_name, fc.position;
CLEAR BREAKS
COL pk_owner CLEAR
COL pk_name CLEAR
COL column_name CLEAR
COL fk_owner CLEAR
COL fk_table CLEAR
COL fk_name CLEAR

SET PAUSE OFF
