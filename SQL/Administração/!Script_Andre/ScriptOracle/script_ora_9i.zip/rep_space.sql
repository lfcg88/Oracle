REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM 
REM File:         rep_space.sql
REM 
REM Version:      1.2
REM
REM Requirements: Privilege 'analyze any'
REM
REM Description:  Shows allocated/used space and extents of tables and
REM               indices
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Renamed from lobjspace to rep_space                      USC   16.10.03
REM Added FREE_BLOCKS calculation to show HWM and            USC   07.11.03
REM ASSM support
REM -------------------------------------------------------------------------

SET ECHO OFF VERIFY OFF LINESIZE 160
SET SERVEROUTPUT ON SIZE 1000000

ACCEPT isSegment_Owner CHAR PROMPT 'Segment Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT isSegment_Name CHAR PROMPT 'Segment Name or Wildcard <%>: ' DEFAULT '%'
ACCEPT isTablespace_Name CHAR PROMPT 'Tablespace Name or Wildcard <%>: ' DEFAULT '%'

DECLARE
  n_total_blocks NUMBER := 0;
  n_sumtotal_blocks NUMBER := 0;
  n_total_bytes NUMBER := 0;
  n_sumtotal_bytes NUMBER := 0;
  n_unused_blocks NUMBER := 0;
  n_sumunused_blocks NUMBER := 0;
  n_unused_bytes NUMBER := 0;
  n_sumunused_bytes NUMBER := 0;
  n_last_used_extent_file_id NUMBER := 0;
  n_last_used_extent_block_id NUMBER := 0;
  n_last_used_block NUMBER := 0;
  n_free_blocks NUMBER := 0;
  n_free_bytes NUMBER := 0;
  n_instance NUMBER := 0;
  n_sumfree_bytes NUMBER := 0;
  n_unformatted_blocks NUMBER := 0;
  n_unformatted_bytes NUMBER := 0;
  n_fs1_blocks NUMBER := 0;
  n_fs1_bytes NUMBER := 0;
  n_fs2_blocks NUMBER := 0;
  n_fs2_bytes NUMBER := 0;
  n_fs3_blocks NUMBER := 0;
  n_fs3_bytes NUMBER := 0;
  n_fs4_blocks NUMBER := 0;
  n_fs4_bytes NUMBER := 0;
  n_full_blocks NUMBER := 0;
  n_full_bytes NUMBER := 0;
  
  CURSOR c1 IS
    SELECT t0.owner, t0.segment_name, t0.segment_type, t0.extents, t0.tablespace_name, t0.partition_name,
      DECODE(t0.segment_type, 'TABLE PARTITION', t0.segment_name||'.'||t0.partition_name,
                              'INDEX PARTITION', t0.segment_name||'.'||t0.partition_name,
                                                 t0.segment_name) AS obj_name,
      t1.block_size, t1.segment_space_management
    FROM dba_segments t0, dba_tablespaces t1
    WHERE t0.owner LIKE UPPER('&isSegment_Owner')
    AND t0.segment_name LIKE UPPER('&isSegment_Name')
    AND t0.segment_type IN ('TABLE', 'TABLE PARTITION', 'INDEX', 'INDEX PARTITION')
    AND t0.tablespace_name LIKE UPPER('&isTablespace_Name')
    AND t0.tablespace_name = t1.tablespace_name
    ORDER BY t0.owner,t0.segment_name,t0.partition_name;
BEGIN
  SELECT value INTO n_instance FROM v$parameter WHERE name = 'instance_number';
  
  DBMS_OUTPUT.PUT_LINE(CHR(10));
  DBMS_OUTPUT.PUT_LINE('Analyzed Object                                             '||' '||
    'Type            '||' '||
    'Bytes (MB)'||' '||
    'Unused(MB)'||' '||
    'Free (MB) '||' '||
    '%ua'||' '||
    '%fr'||' '||
    'Extents'||' '||
    'Tab. Space');
  DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------'||' '||
    '----------------'||' ' ||
    '----------'||' '||
    '----------'||' '||
    '----------'||' '||
    '---'||' '||
    '---'||' '||
    '-------'||' '||
    '------------------------------');
  FOR c1rec IN c1 LOOP
    DBMS_SPACE.UNUSED_SPACE(c1rec.owner, c1rec.segment_name, c1rec.segment_type,
      n_total_blocks, n_total_bytes,
      n_unused_blocks, n_unused_bytes,
      n_last_used_extent_file_id, n_last_used_extent_block_id, n_last_used_block,
      c1rec.partition_name);
    IF c1rec.segment_space_management = 'MANUAL' THEN
      DBMS_SPACE.FREE_BLOCKS (c1rec.owner, c1rec.segment_name, c1rec.segment_type, 
        n_instance, n_free_blocks, NULL, c1rec.partition_name);
      n_free_bytes := n_free_blocks*c1rec.block_size;
    ELSE
      DBMS_SPACE.SPACE_USAGE(c1rec.owner, c1rec.segment_name, c1rec.segment_type,
        n_unformatted_blocks, n_unformatted_bytes,
        n_fs1_blocks, n_fs1_bytes,
        n_fs2_blocks, n_fs2_bytes,
        n_fs3_blocks, n_fs3_bytes,
        n_fs4_blocks, n_fs4_bytes,
        n_full_blocks, n_full_bytes,
        c1rec.partition_name);
      n_free_bytes := (n_fs1_bytes*0.25) + (n_fs2_bytes*0.5) + (n_fs3_bytes*0.75) + n_fs4_bytes;
    END IF;
    DBMS_OUTPUT.PUT_LINE(RPAD(SUBSTR(c1rec.owner||'.'||c1rec.obj_name,1,60),60,' ')||' '||
      RPAD(c1rec.segment_type,16,' ')||' '||
      RPAD(TO_CHAR(ROUND(n_total_bytes/1024/1024,2)),10,' ')||' '||
      RPAD(TO_CHAR(ROUND(n_unused_bytes/1024/1024,2)),10,' ')||' '||
      RPAD(TO_CHAR(ROUND(n_free_bytes/1024/1024,2)),10,' ')||' '||      
      RPAD(TO_CHAR(TRUNC(n_unused_bytes/n_total_bytes*100)),3,' ')||' '||
      RPAD(TO_CHAR(TRUNC(n_free_bytes/n_total_bytes*100)),3,' ')||' '||
      RPAD(TO_CHAR(c1rec.extents),7,' ')||' '||
      RPAD(c1rec.tablespace_name,30,' '));
    n_sumtotal_blocks := n_sumtotal_blocks +  n_total_blocks;
    n_sumtotal_bytes := n_sumtotal_bytes + n_total_bytes;
    n_sumunused_blocks := n_sumunused_blocks + n_unused_blocks;
    n_sumunused_bytes := n_sumunused_bytes + n_unused_bytes;
    n_sumfree_bytes := n_sumfree_bytes + n_free_bytes;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE('------------------------------------------------------------'||' '||
    '                '||' '||
    '----------'||' '||
    '----------'||' '||
    '----------');
  DBMS_OUTPUT.PUT_LINE(RPAD('Total:',60,' ')||' '||
    '                '||' '||
    RPAD(TO_CHAR(ROUND(n_sumtotal_bytes/1024/1024,2)),10,' ')||' '||
    RPAD(TO_CHAR(ROUND(n_sumunused_bytes/1024/1024,2)),10,' ')||' '||
    RPAD(TO_CHAR(ROUND(n_sumfree_bytes/1024/1024,2)),10,' '));
EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE(SUBSTR(SQLERRM, 1, 250));
END;
/

