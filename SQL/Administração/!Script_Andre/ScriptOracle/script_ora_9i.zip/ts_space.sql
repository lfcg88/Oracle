REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        ts_space.sql
REM 
REM Version:     1.0
REM
REM Description: Shows free extents (>100MB) per tablespace and overall
REM              information per tablespace
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM -------------------------------------------------------------------------

SET LINESIZE 120

@@title "Free Extents in Permanent Tablespaces > 100MB"
BREAK ON "Tablespace"
select tablespace_name "Tablespace", 
  round(bytes/1024/1024,2) "Extents > 100 MB"
from dba_free_space
where tablespace_name not in ('SYSTEM', 'RBS', 'TEMP')
and bytes > 100*1024*1024
order by tablespace_name, round(bytes/1024/1024,2);
CLEAR BREAKS

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@rep_ts

SET PAUSE OFF
