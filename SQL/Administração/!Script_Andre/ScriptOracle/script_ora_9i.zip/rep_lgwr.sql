REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_lgwr.sql
REM
REM Version:      1.1
REM
REM Requirements: Oracle9i
REM
REM Description:  Reports Redo Log statistics
REM               See also Metalink Doc ID: 147471.1 "Tuning the Redolog 
REM               Buffer Cache and Resolving Redo Latch Contention"
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Renamed from rep_redo.sql to rep_lgwr.sql and reporting  USC   22.01.04
REM of latch contenttion added 
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 120

@@title "Redo Log File Report"
SELECT group#, thread#, sequence#, TRUNC(bytes/1024/1024) AS bytes_mb, members, archived, status, first_change#, first_time
FROM v$log;

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Redo Log Buffer Report"
REM
REM 'redo buffer allocation retries' should be low,
REM otherwise we face redo log buffer contention (increase LOG_BUFFER)
REM
REM 'redo log space requests' should be low, otherwise checkpointing or archiving process should be imporved
REM
COL chkpts_completed HEAD "Checkpoints|completed"
COL chkpts_started HEAD "Checkpoints|started"
COL block_write FOR 9999900 HEAD "Blocks|per Write"
SELECT t5.value chkpts_completed, t6.value chkpts_started, t7.value/DECODE(t8.value,0,1,t8.value) block_write,
  t1.value "Entries",
  ROUND(t2.value/1024/1024,2) "MB written", t3.value "LGWR Waits", t4.value "User Waits",
  ROUND((1 - (t4.value/t1.value))*100,2) "Redo Nowait Ratio(%)"
FROM v$sysstat t1, v$sysstat t2, v$sysstat t3,
  v$sysstat t4, v$sysstat t5, v$sysstat t6,
  v$sysstat t7, v$sysstat t8
WHERE t1.name = 'redo entries'
AND t2.name = 'redo size'
AND t3.name = 'redo log space requests'
AND t4.name = 'redo buffer allocation retries'
AND t5.name = 'background checkpoints completed'
AND t6.name = 'background checkpoints started'
AND t7.name = 'redo blocks written'
AND t8.name = 'redo writes';
COL chkpts_completed CLEAR
COL chkpts_started CLEAR
COL block_write CLEAR

@@title "Redo System Statistics Report"
SELECT name, value
FROM v$sysstat
WHERE class = 2;

@@title "Redo System Event Report"
REM
REM High 'log buffer space' values are indicators for increaseing 'LOG_BUFFER'
REM
SELECT event, total_waits, total_timeouts, TRUNC(time_waited/100) AS Seconds
FROM v$system_event
WHERE event LIKE 'log%';

@@title "Redo Latch Performance Report"
REM
REM if pct_miss or pct_imiss exceeds 1% then follow the recommendations in the given order:
REM 1. redo allocation latch contention: increase LOG_PARALLELISM
REM 2. redo copy latch contention: increase _LOG_SIMULTANEOUS_COPIES
REM
COL name FOR a30
COL pct_miss FOR 99.9
COL pct_imiss FOR 99.9
SELECT t1.name, t2.gets, t2.misses, t2.misses*100/DECODE(gets, 0, 1, gets) AS pct_miss, 
  t2.sleeps, t2.immediate_misses, t2.immediate_misses*100/DECODE(immediate_gets, 0, 1, immediate_gets) AS pct_imiss,
  t2.spin_gets, t2.wait_time
FROM v$latchname t1, v$latch t2
WHERE t1.name IN ('redo allocation', 'redo copy', 'redo writing')
AND t1.latch# = t2.latch#;
COL name CLEAR
COL pct_miss CLEAR
COL pct_imiss CLEAR

SET PAGESIZE 24 PAUSE OFF
