REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_dbi.sql
REM 
REM Version:     1.0
REM
REM Description: Reports integrity problems like invalid and/or disabled
REM              objects
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM -------------------------------------------------------------------------

SET LINESIZE 120

@@title "Invalid Objects"
COL Object FOR a30
SELECT owner, object_name AS Object, object_type
FROM dba_objects
WHERE status <> 'VALID'
UNION
SELECT owner, index_name AS Object, index_type
FROM dba_indexes
WHERE status <> 'VALID';
COL Object CLEAR

@@title "Disabled Objects" 
SELECT owner, trigger_name, trigger_type
FROM dba_triggers
WHERE status <> 'ENABLED'
UNION
SELECT owner, constraint_name, constraint_type
FROM dba_constraints
WHERE status <> 'ENABLED';

SET ECHO ON
