REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         explplan.sql
REM 
REM Version:      2.0
REM
REM Requirements: Oracle9i, 9.2.0.2
REM
REM Description:  Shows explain plan of specified SQL Statement without
REM               executing it against the DB
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Cost,cardinality and bytes statistics, 
REM Partitioning support added and output reformatted        USC   04.10.00
REM Display of explain plan taken from 
REM $ORACLE_HOME\rdbms\admin\utlxplp.sql                     USC   21.11.00
REM Usage of dbms_xplan, 
REM see $ORACLE_HOME\rdbms\admin\utlxplp.sql                 USC   03.07.03
REM -------------------------------------------------------------------------

SET LINESIZE 180

EXPLAIN PLAN
SET statement_id = 'EXP_USC'
FOR
SELECT /*+ ORDERED */ 
                     SUBSTR(t1.owner,1,20) AS owner, SUBSTR(t1.name,1,40) AS jcs_job, SUBSTR(t1.prog_name,1,20) AS prog_name,
                     ROUND((SYSDATE - t1.run_start) * 24, 1) AS run_time_h, t1.job_id                   
                   FROM jcs_job_stats t1, jcs_job_stats t2  
                   WHERE t1.snap_time = (SELECT MAX(t3.snap_time)
                                         FROM jcs_snapshot t3)
                   AND t1.owner LIKE '%'
                   AND t1.status = 'RUNNING'
                   AND ROUND((SYSDATE - t1.run_start) * 24, 1) > 2
                   AND t1.job_id = t2.parent_job_id (+)
                   AND t1.snap_id = t2.snap_id (+)
                   AND t1.snap_time = t2.snap_time (+)
                   AND t2.job_id IS NULL;


                         
SET ECHO OFF FEEDBACK OFF

SELECT * FROM TABLE(dbms_xplan.display('plan_table', 'EXP_USC', 'all'));

DELETE FROM plan_table WHERE statement_id = 'EXP_USC';
COMMIT;

SET FEEDBACK ON


