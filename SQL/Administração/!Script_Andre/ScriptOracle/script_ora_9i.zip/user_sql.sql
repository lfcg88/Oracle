REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         user_sql.sql
REM 
REM Version:      1.3
REM
REM Requirements: Oracle9i
REM
REM Description:  Shows SQL statements executed by a user
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   07.04.03
REM Using v$sql instead of v$sqlarea because it's faster     USC   20.05.03
REM Change elapsed_time/1000 to elapsed_time/1000000         USC   09.07.03
REM PQ Session SQL added                                     USC   12.11.03
REM Adjusted where clause DECODE(v0.sql_address,'00'         USC   16.11.03
REM Using v$sqlarea again to avoid lots of duplicates        USC   18.11.03
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 60

ACCEPT sUserName CHAR PROMPT 'Username or Wildcard <%>: ' DEFAULT '%'
ACCEPT sSid CHAR PROMPT 'Session ID or Wildcard <%>: ' DEFAULT '%'
ACCEPT sActive CHAR PROMPT 'Status or Wildcard <a%>: ' DEFAULT 'a%'

@@title "Session SQL Report"
COL sql_text FOR a90 WORD_WRAP
COL username FOR a10
COL executions FOR 9999999 heading "EXEC."
COL elapsed FOR 9999999 HEAD "ELAPSED|[SEC.]"
BREAK ON username ON sid ON sql_text
SELECT NVL(v0.username,v0.type) username, v0.sid sid, v1.sql_text, v0.status, v1.executions, v1.rows_processed, 
  v1.elapsed_time/1000000/DECODE(v1.executions,0,1) AS elapsed
FROM v$session v0, v$sqlarea v1
WHERE v0.username LIKE UPPER('&sUserName')
AND v0.sid LIKE '&sSid'
AND v0.status LIKE UPPER('&sActive')
AND DECODE(v0.sql_hash_value,0,v0.prev_hash_value,v0.sql_hash_value) = v1.hash_value
AND DECODE(v0.sql_address,'00',v0.prev_sql_addr,v0.sql_address) = v1.address
UNION
SELECT NVL(v0.username,v0.type) username, v0.sid sid, v1.sql_text, v0.status, v1.executions, v1.rows_processed, 
  v1.elapsed_time/1000000/DECODE(v1.executions,0,1) AS elapsed
FROM v$session v0, v$sqlarea v1
WHERE v0.sid IN (SELECT sid
                 FROM v$px_session
                 WHERE qcsid IN (SELECT sid
                                 FROM v$session
                                 WHERE username LIKE UPPER('&sUserName')
                                 AND sid LIKE '&sSid'
                                 AND v0.status LIKE UPPER('&sActive')))
AND DECODE(v0.sql_hash_value,0,v0.prev_hash_value,v0.sql_hash_value) = v1.hash_value
AND DECODE(v0.sql_address,'00',v0.prev_sql_addr,v0.sql_address) = v1.address
ORDER BY 1,2;
CLEAR BREAKS
COL sql_text CLEAR
COL username CLEAR
COL executions CLEAR
COL elapsed CLEAR




