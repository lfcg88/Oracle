REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_resu.sql
REM 
REM Version:      1.0
REM
REM Requirements: Oracle9i
REM
REM Description:  Shows details of running resumable transactions
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   26.02.02
REM -------------------------------------------------------------------------

SET LINESIZE 160

@@title "Suspended Transaction Event Statistics"
SELECT event, total_waits, total_timeouts, time_waited 
FROM v$system_event 
WHERE event = 'statement suspended, wait error to be cleared';

@@title "Suspended Transaction Timing Report"
COL username FOR a15
COL session_id FOR 99999 HEAD "SID"
COL start_time FOR a19
COL suspend_time FOR a19
COL abort_time FOR a19
COL resume_time FOR a19
SELECT t2.username, t1.session_id, t1.status, t1.timeout,
  TO_CHAR(TO_DATE(t1.start_time,'MM/DD/YY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS') start_time,
  TO_CHAR(TO_DATE(t1.suspend_time,'MM/DD/YY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS') suspend_time,
  TO_CHAR(TO_DATE(t1.suspend_time,'MM/DD/YY HH24:MI:SS')+(timeout/24/60/60),'DD-MM-YYYY HH24:MI:SS') abort_time,
  TO_CHAR(TO_DATE(t1.resume_time,'MM/DD/YY HH24:MI:SS'),'DD-MM-YYYY HH24:MI:SS') resume_time
FROM dba_resumable t1, dba_users t2
WHERE t1.status <> 'NORMAL'
AND t1.user_id = t2.user_id (+);
COL username CLEAR
COL session_id CLEAR
COL start_time CLEAR
COL suspend_time CLEAR
COL abort_time CLEAR
COL resume_time CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Suspended Transaction SQL Report"
COL username FOR a15
COL session_id FOR 99999 HEAD "SID"
COL error_msg FOR a60
COL sql_text FOR a60
SELECT t2.username, t1.session_id, t1.error_msg, t1.sql_text
FROM dba_resumable t1, dba_users t2
WHERE t1.status <> 'NORMAL'
AND t1.user_id = t2.user_id (+);
COL username CLEAR
COL session_id CLEAR
COL error_msg CLEAR
COL sql_text CLEAR

SET PAUSE OFF

PROMPT
PROMPT Use the following code to handle suspended transactions:
PROMPT
PROMPT SET SERVEROUTPUT ON
PROMPT
PROMPT -- To change the timeout:
PROMPT EXEC dbms_resumable.set_session_timeout(<sid>,<timeout_in_seconds>);
PROMPT
PROMPT -- To abort a suspended transaction (DOESN'T WORK WITH 9.0.1.0.0):
PROMPT EXEC dbms_resumable.abort(<sid>);
PROMPT 
PROMPT -- or set the timout to 1 second
PROMPT EXEC dbms_resumable.set_session_timeout(<sid>,1);
PROMPT


