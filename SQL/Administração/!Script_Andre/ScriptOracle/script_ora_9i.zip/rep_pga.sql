REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_pga.sql
REM 
REM Version:      2.0
REM
REM Requirements: Oracle9iR2
REM
REM Description:  Reports PGA Statistics
REM               Check parameters: pga_aggregate_target, statistics_level,
REM               workarea_size_policy
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   05.03.02
REM Restructured and optimized for Release 2                 USC   13.09.02
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 24

@@title "PGA Statistics"
SELECT name, value 
FROM V$PGASTAT;

@@title "PGA Setting Advice"
REM
REM The minimum setting for pga_aggregate_target is where estd_overalloc_count is 0 
REM
SELECT ROUND(pga_target_for_estimate/1024/1024) target_mb,
  estd_pga_cache_hit_percentage cache_hit_perc,
  estd_overalloc_count
FROM v$pga_target_advice;

@@title "PGA Optimal Usage Statistics"
SELECT name profile, cnt, decode(total, 0, 0, round(cnt*100/total)) percentage
FROM (SELECT name, value cnt, (sum(value) over ()) total
      FROM v$sysstat 
      WHERE name like 'workarea exec%');

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Top 10 PGA Memory Usage"
COL optimal_executions FOR 999999 HEAD "OPT.|EXEC."
COL onepass_executions FOR 999999 HEAD "ONEPASS|EXEC."
COL multipasses_executions FOR 999999 HEAD "MULTIPASS|EXEC."
COL est_opt FOR 999999999999 HEAD "EST. OPT.| SIZE (MB)"
COL est_one FOR 999999999999 HEAD "EST. ONEPASS| SIZE (MB)"
COL memory_used FOR 999999999999 HEAD "MEMORY| USED (MB)"
SELECT *
FROM (SELECT t2.sid, t2.server, t1.operation_type, t1.policy,
         t1.optimal_executions, t1.onepass_executions, t1.multipasses_executions,
         t1.estimated_optimal_size/1024/1024 est_opt, 
         t1.estimated_onepass_size/1024/1024 est_one,
         t1.last_memory_used/1024/1024 memory_used
      FROM v$sql_workarea t1, v$session t2
      WHERE t1.address = t2.sql_address (+)
      AND t1.hash_value = t2.sql_hash_value (+)
      ORDER BY t1.estimated_optimal_size DESC)
WHERE ROWNUM <= 10;
COL optimal_executions CLEAR
COL onepass_executions CLEAR
COL multipasses_executions CLEAR
COL est_opt CLEAR
COL est_one CLEAR
COL memory_used CLEAR

@@title "Top 10 Process PGA Memory Usage (MB)"
COL program FOR a20
SELECT *
FROM (SELECT t2.sid, t2.username, t1.program, TRUNC(t1.pga_used_mem/1024/1024) pga_used_mem, 
        TRUNC(t1.pga_alloc_mem/1024/1024) pga_alloc_mem, 
        TRUNC(t1.pga_max_mem/1024/1024) pga_max_mem
      FROM v$process t1, v$session t2
      WHERE t1.addr = t2.paddr
      ORDER BY t1.pga_used_mem DESC)
WHERE ROWNUM < 10;
COL program CLEAR

@@title "Active Workareas (MB)"
SELECT TO_NUMBER(DECODE(sid, 65535, NULL, sid)) sid,
  operation_type operation,
  TRUNC(work_area_size/1024/1024) wsize, 
  TRUNC(expected_size/1024/1024) esize,
  TRUNC(actual_mem_used/1024/1024) "ACT MEM", 
  TRUNC(max_mem_used/1024/1024) "MAX MEM", 
  number_passes pass
FROM v$sql_workarea_active
ORDER BY 1,2;

SET PAUSE OFF
