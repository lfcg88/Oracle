REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        ext_dist.sql
REM 
REM Version:     1.0
REM
REM Description: Shows extent distribution of objects
REM              
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   06.12.00
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 80

ACCEPT isObjectOwner CHAR PROMPT 'Object Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT isObjectName CHAR PROMPT 'Object Name: ' DEFAULT '-'

@@title "Extents per Tablespace Statistics"
COL segment_name FOR a30
BREAK ON owner ON segment_name ON segment_type ON partition_name
SELECT t1.owner, t1.segment_name, t1.segment_type, t1.partition_name, t1.tablespace_name, COUNT(*) extents
FROM dba_extents t1
WHERE t1.owner LIKE UPPER('&isObjectOwner')
AND t1.segment_name = DECODE('&isObjectName', '-', t1.segment_name, UPPER('&isObjectName'))
GROUP BY t1.owner, t1.segment_name, t1.segment_type, t1.partition_name, t1.tablespace_name;
COL segment_name CLEAR
CLEAR BREAKS

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Extents per Datafile Statistics"
COL segment_name FOR a30
COL file_name FOR a60
COL owner FOR a10
BREAK ON owner ON segment_name ON partition_name 
SELECT t1.owner, t1.segment_name, t1.partition_name, t2.file_name, COUNT(*) extents
FROM dba_extents t1, dba_data_files t2
WHERE t1.owner LIKE UPPER('&isObjectOwner')
AND t1.segment_name = DECODE('&isObjectName', '-', t1.segment_name, UPPER('&isObjectName'))
AND t1.file_id = t2.file_id
GROUP BY t1.owner, t1.segment_name, t1.partition_name, t2.file_name;
COL segment_name CLEAR
COL file_name CLEAR
COL owner CLEAR
CLEAR BREAKS

SET PAUSE OFF
