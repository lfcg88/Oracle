REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         sql_pga.sql
REM 
REM Version:      1.0
REM
REM Requirements: Oracle9i
REM
REM Description:  Shows automatic PGA memory usage during execution plan steps
REM 
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   17.11.03
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 160 VERIFY OFF

ACCEPT sSid CHAR PROMPT 'Session ID: ' DEFAULT '-1'

@@title "Cached SQL (Automatic Management) PGA Memory Usage"
COL operation FOR a50
COL name FOR a30
COL o_1_m FOR a5 HEAD "O/1/M"
SELECT t1.operation, t1.name,
  t1.input_mb,
  TRUNC(t2.last_memory_used/1024) AS last_mem_kb,
  TRUNC(t2.estimated_optimal_size/1024) AS opt_mem_kb, 
  TRUNC(t2.estimated_onepass_size/1024) AS onepass_mem_kb, 
  DECODE(t2.optimal_executions, null, null, 
           t2.optimal_executions||'/'||t2.onepass_executions||'/'||t2.multipasses_executions) AS o_1_m
FROM
 (SELECT /*+ NO_MERGE */ address, hash_value, id, position, child_number, TRUNC(bytes/1024/1024) AS input_mb,
     LPAD(' ',depth)||operation||DECODE(options, null,'',' '||options) AS operation,
     DECODE(SUBSTR(object_name, 1, 7), 'SYS_LE_', null, object_name) AS name
  FROM (SELECT DISTINCT
          address,
          hash_value,
          child_number,
          operation,
          options,
          object_node,
          object#,
          object_owner,
          object_name,
          optimizer,
          id,
          parent_id,
          depth,
          position,
          search_columns,
          cost,
          cardinality,
          bytes,
          other_tag,
          partition_start,
          partition_stop,
          partition_id,
          other,    
          distribution,
          cpu_cost,         
          io_cost,      
          temp_space
          -- The attributes ACCESS_PREDICATES, FILTER_PREDICATES
          -- cannot be captured because of ORA-03113: end-of-file on communication channel !?!
        FROM v$sql_plan
        WHERE (address, hash_value) = (SELECT DECODE(sql_address, '00', prev_sql_addr, sql_address), 
                                         DECODE(sql_hash_value, 0, prev_hash_value, sql_hash_value)
                                       FROM v$session
                                       WHERE sid = DECODE(TO_NUMBER('&sSid'), -1, -1, TO_NUMBER('&sSid'))))
  ORDER BY level, id) t1, v$sql_workarea t2
WHERE t1.hash_value = t2.hash_value(+) 
AND t1.address = t2.address(+) 
AND t1.id = t2.operation_id(+)
AND t1.child_number = t2.child_number (+)
ORDER BY t1.id, t1.position;
COL o_1_m CLEAR
COL operation CLEAR
COL name CLEAR



