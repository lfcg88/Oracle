REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        lobjdep.sql
REM 
REM Version:     1.0
REM
REM Description: 
REM              
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM -------------------------------------------------------------------------

SET LINESIZE 120

ACCEPT isOwner CHAR PROMPT 'Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT isName CHAR PROMPT 'Name or Wildcard <%>: ' DEFAULT '%'

@@title "Dependend Objects Report"
SELECT owner, name, type
FROM dba_dependencies
WHERE referenced_owner LIKE UPPER('&isOwner')
AND referenced_name LIKE UPPER('&isName')
ORDER BY owner, name;
