REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_dbwr.sql
REM  
REM Version:      1.2
REM
REM Requirements: Oracle9iR2, select_catalog_role, select any dictionary
REM
REM Description:  Reports DBWR statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM avg queue length                                         USC   13.12.03
REM Adjusted to 9i DBWR behaviour (buffer chache stats)      USC   21.01.04
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 160

ACCEPT isDetailed CHAR PROMPT 'Details <n>: ' DEFAULT 'n'

@@title "Cache Buffer Latch Performance Report"
COL name FOR a30
COL pct_miss FOR 99.9
COL pct_imiss FOR 99.9
SELECT t1.name, t2.gets, t2.misses, t2.misses*100/DECODE(gets, 0, 1, gets) AS pct_miss, 
  t2.sleeps, t2.immediate_misses, t2.immediate_misses*100/DECODE(immediate_gets, 0, 1, immediate_gets) AS pct_imiss,
  t2.spin_gets, t2.wait_time
FROM v$latchname t1, v$latch t2
WHERE t1.name IN ('cache buffers chains', 'cache buffers lru chain')
AND t1.latch# = t2.latch#;
COL name CLEAR
COL pct_miss CLEAR
COL pct_imiss CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Cache Buffer DBWR Performance Report"
COL name FOR a8
SELECT t1.name, t1.block_size, t1.buffers, t2.dbwr_num,
  t2.fbwait, t2.wcwait, t2.bbwait, t2.fbinsp, 
  t2.dbinsp, t2.dbbchg, t2.dbbget, t2.buf_got, t2.sum_scn, 
  t2.pread, t2.pwrite
FROM v$buffer_pool t1, x$kcbwds t2
WHERE t1.lo_setid <= t2.set_id
AND t1.hi_setid >= t2.set_id;
COL name CLEAR

@@title "Free Buffer Waits Report"
COL event FOR a30
SELECT * 
FROM v$system_event
WHERE event = 'free buffer waits';
COL event CLEAR

@@title "DBWR System Statistics Report"
REM if queue length increases, DBWR has problems to keep up with load 
SELECT name, value
FROM v$sysstat
WHERE class = 8
AND name like 'DBWR%'
OR name IN ('free buffer requested', 'free buffer inspected', 
'dirty buffers inspected', 'summed dirty queue length', 'write requests');

@@title "Cache Buffer Latch Children Performance Report"
COL name FOR a30
COL pct_miss FOR 99.9
COL pct_imiss FOR 99.9
SELECT t1.name, t2.addr, t2.gets, t2.misses, t2.misses*100/DECODE(gets, 0, 1, gets) AS pct_miss, 
  t2.sleeps, t2.immediate_misses, t2.immediate_misses*100/DECODE(immediate_gets, 0, 1, immediate_gets) AS pct_imiss,
  t2.spin_gets, t2.wait_time
FROM v$latchname t1, v$latch_children t2
WHERE 'y' = '&isDetailed'
AND t1.name IN ('cache buffers chains', 'cache buffers lru chain')
AND t1.latch# = t2.latch#
AND t2.immediate_gets > 0
AND (t2.misses*100/DECODE(gets, 0, 1, gets) > 5
     OR t2.immediate_misses*100/DECODE(immediate_gets, 0, 1, immediate_gets) > 5);
COL name CLEAR
COL pct_miss CLEAR
COL pct_imiss CLEAR

REM
REM Use the following query if there is a specific cache buffers chains child latch that 
REM has many more GETS, MISSES, and SLEEPS when compared with the other child latches, 
REM then this is the contended for child latch.
REM
REM X$BH.TCH is a touch count for the buffer. A high value for X$BH.TCH indicates a hot block.
REM 
/*
SELECT file#, dbablk, class, state, tch, obj, SUBSTR(name, 1,25) AS obj_name
FROM x$bh, obj$
WHERE hladdr='<latch_addr>'
AND obj=obj$.dataobj#(+)
*/
SET PAUSE OFF
