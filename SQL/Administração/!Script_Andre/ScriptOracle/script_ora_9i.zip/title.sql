REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        title.sql
REM 
REM Version:     1.0
REM
REM Description: Prints an header similar to TTITLE
REM              
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   26.06.01
REM -------------------------------------------------------------------------

SET DOCU OFF
/*
REM
REM TTITLE  doesn't print a header when a SQL query has no result set, so it's no option
REM When using SET PAUSE ON, the method below, has the drawback, that you have to confirm too often.
REM
SET TERMOUT OFF
DEFINE linesize = 140
COL sHeader NEW_VALUE sHeader
SELECT TO_CHAR(sysdate, 'DD.MM.YYYY HH24:MI:SS')||' '||
  RPAD('_',ROUND((&linesize - LENGTH(TO_CHAR(sysdate, 'DD.MM.YYYY HH24:MI:SS')) - LENGTH('&1') - LENGTH(global_name)) / 2), '_')||' '||
  '&1'||' '||
  RPAD('_',(&linesize - LENGTH(TO_CHAR(sysdate, 'DD.MM.YYYY HH24:MI:SS')) - LENGTH('&1') - LENGTH(global_name)) / 2, '_')||' '||
  global_name AS sHeader
FROM global_name;
COL sHeader CLEAR
SET TERMOUT ON
PROMPT
PROMPT &sHeader
PROMPT
UNDEF sHeader
UNDEF linesize

REM
REM The following solution isn't very sophisticated, but works
REM
PROMPT
PROMPT ________________________________________ &1
PROMPT

REM
REM The following solution does the job best
REM
*/

DEFINE linesize = 100
SET SERVEROUTPUT ON FEED OFF VERIFY OFF

PROMPT
DECLARE
  sHeader VARCHAR2(1000);
BEGIN
  SELECT TO_CHAR(sysdate, 'DD.MM.YYYY HH24:MI:SS')||' '||
    RPAD('_',ROUND((&linesize - LENGTH(TO_CHAR(sysdate, 'DD.MM.YYYY HH24:MI:SS')) - LENGTH('&1') - LENGTH(global_name)) / 2), '_')||' '||
    '&1'||' '||
    RPAD('_',(&linesize - LENGTH(TO_CHAR(sysdate, 'DD.MM.YYYY HH24:MI:SS')) - LENGTH('&1') - LENGTH(global_name)) / 2, '_')||' '||
    global_name INTO sHeader
  FROM global_name;
  dbms_output.put_line(sHeader);
END;
/
PROMPT
UNDEF linesize

SET FEED ON ECHO OFF
