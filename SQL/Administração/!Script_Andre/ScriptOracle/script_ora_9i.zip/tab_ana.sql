REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        tab_ana.sql
REM 
REM Version:     1.1, Oracle 8.1.7
REM
REM Description: Analyzes a table with dbms_stats package
REM              (recommended by Oracle, especially when using partitioning)
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   05.12.00
REM Other parameters are now prompted                         USC   13.09.02
REM -------------------------------------------------------------------------

SET SERVEROUTPUT ON FEED OFF VERIFY OFF

ACCEPT isTableOwner CHAR PROMPT 'Table Owner: ' DEFAULT '-'
ACCEPT isTableName CHAR PROMPT 'Table Name: ' DEFAULT '-'
ACCEPT isPartName CHAR PROMPT 'Partition Name <NULL>: ' DEFAULT 'NULL'
ACCEPT isDegree CHAR PROMPT 'Parallel Degree <NULL>: ' DEFAULT 'NULL'
ACCEPT isCascade CHAR PROMPT 'Cascading Indexes <Y>: ' DEFAULT 'Y'

PROMPT
PROMPT Analyzing Table &isTableOwner..&isTableName ...

DECLARE
  sTableOwner dba_tables.owner%TYPE := UPPER('&isTableOwner');
  sTableName dba_tables.table_name%TYPE := UPPER('&isTableName');
  sPartName dba_tab_partitions.partition_name%TYPE := UPPER('&isPartName');
  sDegree VARCHAR2(2) := &isDegree;
BEGIN
  IF sPartName = 'NULL' THEN
    sPartName := NULL;
  END IF;
  dbms_stats.gather_table_stats
  ( ownname => sTableOwner, 
    tabname => sTableName,
    partname => sPartName, 
    estimate_percent => 60, 
    block_sample => FALSE,
    method_opt => 'FOR ALL INDEXED COLUMNS SIZE 1', -- Other values: FOR ALL [INDEXED | HIDDEN] COLUMNS [SIZE integer]
                                                                  -- FOR COLUMNS [SIZE integer] column|attribute 
                                                                  -- [,column|attribute ...]
    degree => sDegree,
    granularity => 'DEFAULT', -- (GLOBAL and PARTITION level stats), Other values: SUBPARTITION, PARTITION, GLOBAL, ALL
    cascade => FALSE, -- Gather Index Stats also
    stattab => NULL,
    statid => NULL,
    statown => NULL);
   IF sPartName IS NOT NULL THEN
     dbms_output.put_line('Table '||sTableOwner||'.'||sTableName||' Partition '||sPartName||' analyzed.');
   ELSE
     dbms_output.put_line('Table '||sTableOwner||'.'||sTableName||' analyzed.');
   END IF;
EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line(SQLERRM);
END;
/

DECLARE
  sTableOwner dba_tables.owner%TYPE := UPPER('&isTableOwner');
  sTableName dba_tables.table_name%TYPE := UPPER('&isTableName');
  sCascade CHAR(1) := UPPER('&isCascade');
BEGIN
  IF sCascade = 'Y' THEN
    FOR c1Rec IN (SELECT index_name
                  FROM dba_indexes
                  WHERE table_owner = sTableOwner
                  AND table_name = sTableName) LOOP
      dbms_stats.gather_index_stats
      ( ownname => sTableOwner, 
        indname => c1Rec.index_name, 
        partname => NULL,
        estimate_percent => NULL,
        stattab => NULL, 
        statid => NULL,
        statown => NULL);
      dbms_output.put_line('Index '||sTableOwner||'.'||c1Rec.index_name||' analyzed.');
    END LOOP;
  END IF;
EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line(SQLERRM);
END;
/

SET FEED ON
