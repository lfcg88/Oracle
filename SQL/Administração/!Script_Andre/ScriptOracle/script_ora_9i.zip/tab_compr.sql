


REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         tab_compr.sql
REM 
REM Version:      1.0
REM
REM Requirements: Oracle9i, 9.2.0.2 to 9.2.0.4
REM
REM Description:  Shows wether a table is compressed
REM               dba_tables dictionary view doesn't show this information
REM              
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   24.03.03
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 80

ACCEPT isTableOwner CHAR PROMPT 'Table Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT isTableName CHAR PROMPT 'Table Name: ' DEFAULT '-'

@@title "Table Compression Report"
COL table_name FOR a32
SELECT v1.owner, v1.object_name AS table_name, 
  DECODE(BITAND(s.spare1, 2048), 2048, 'ENABLED', 'DISABLED') AS compression
FROM dba_objects v1, sys.obj$ o, sys.tab$ t, sys.seg$ s
WHERE v1.owner LIKE UPPER('&isTableOwner')
AND v1.object_name = UPPER('&isTableName')
AND v1.object_type = 'TABLE'
AND v1.object_id = o.obj#
AND o.obj# = t.obj#
AND t.file# = s.file#
AND t.block# = s.block#
AND t.ts# = s.ts#;
COL table_name CLEAR
