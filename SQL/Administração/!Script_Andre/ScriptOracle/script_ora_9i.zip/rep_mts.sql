REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_mts.sql
REM 
REM Version:      1.0
REM
REM Requirements: Oracle9i
REM
REM Description:  Reports Shared Server configuration statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   05.03.02
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 120

@@title "Actual MTS Parameters"
COL name FOR a30
COL value FOR a80
SELECT name, value
FROM v$parameter
WHERE name IN ('max_shared_servers', 'shared_server_sessions', 'shared_servers',
  'max_dispatchers', 'dispatchers',
  'circuits', 'local_listener');
COL name CLEAR
COL value CLEAR

@@title "Max. Number of Server-Processes"
REM
REM Prior to Oracle9i v$mts was used
REM
SELECT * 
FROM v$shared_server_monitor;

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Dispatcher Contention"
REM
REM If necessary also look at v$dispatcher_rate view
REM
COL Protocol FOR a70
SELECT name "NAME", network "Protocol", 
  owned, status "STATUS", round((busy/(busy + idle)) * 100,2) "%TIME BUSY"               
FROM v$dispatcher
ORDER BY (busy/(busy + idle)) * 100 DESC;
COL Protocol CLEAR

@@title "Waits of Dispatchers"
COL Protocol FOR a70
SELECT name, network "Protocol", 
   DECODE(SUM(TOTALQ),0,'No Requests',
   ROUND(SUM(WAIT)/SUM(TOTALQ),2)) "AVG Waits (1/100 s)"
FROM v$dispatcher d, v$queue q
WHERE q.type = 'DISPATCHER'
AND d.paddr = q.paddr
GROUP BY name, network;
COL Protocol CLEAR

@@title "Shared Server Contention"
SELECT t1.name "NAME", t1.status, t1.paddr, t1.requests,                                    
  ROUND((t1.busy/(t1.busy + t1.idle)) * 100,2) "%TIME BUSY" 
FROM v$shared_server t1
ORDER BY t1.name, (t1.busy/(t1.busy + t1.idle)) * 100 DESC;

SET PAUSE OFF

@@title "Waits of Shared-Server"
SELECT DECODE(TOTALQ,0,'not activ', ROUND(WAIT/TOTALQ,2)) "AVG Waits (1/100 s)"
FROM v$queue
WHERE type = 'COMMON';

@@title "Nbr. Processes actually waiting for a shared server"
SELECT queued
FROM v$queue
WHERE type = 'COMMON';

SET PAGESIZE 24
