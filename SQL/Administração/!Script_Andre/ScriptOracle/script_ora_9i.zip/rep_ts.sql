REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_ts.sql
REM 
REM Version:      2.0
REM
REM Requirements: Oracle9i
REM
REM Description:  Reports space usage information per tablespace
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Support for LMTs und temporary tablespaces               USC   17.12.00
REM Remove of v$temp_extent_map                              USC   06.11.01
REM Query parameter tablespace added                         USC   09.10.02
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 160

ACCEPT isTablespace CHAR PROMPT 'Tablespace Name or Wildcard <%>: ' DEFAULT '%'

@@title "Tablespace Overview"
COL initial_mb FOR 999999.99
COL next_mb FOR 999999.99
COL min_mb FOR 999999.99
COL extent_management FOR a10 HEAD "EXTENT-|MANAGEMENT"
COL allocation_type FOR a11 HEAD "ALLOCATION-|TYPE"
COL segment_space_management FOR a10 HEAD "SEGMENT|SPACE|MANAGEMENT"
COL block_size FOR 999999 HEAD "BLOCK-|SIZE"
SELECT tablespace_name, block_size, initial_extent/1024/1024 initial_mb, next_extent/1024/1024 next_mb, min_extlen/1024/1024  min_mb,
  contents, extent_management, allocation_type, segment_space_management, status, logging,
  max_extents, pct_increase
FROM dba_tablespaces
WHERE tablespace_name LIKE UPPER('&isTablespace')  
ORDER BY tablespace_name;
COL initial_mb CLEAR
COL next_mb CLEAR
COL min_mb CLEAR
COL extent_management CLEAR
COL allocation_type CLEAR
COL segment_space_management CLEAR
COL block_size CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Permanent Tablespace Space Overview"
COL tablespace FOR a30
COL size_mb HEAD "Size (MB)"
COL free_mb HEAD "Free (MB)"
COL dummy NOPRINT
COMPUTE SUM OF size_mb ON dummy
COMPUTE SUM OF free_mb ON dummy
BREAK ON dummy
SELECT NULL dummy, t0.tablespace_name "Tablespace",
  ROUND(t2.sum_bytes,2) AS size_mb,
  ROUND(NVL(t1.free_bytes/1024/1024,0),2) free_mb,
  ROUND(NVL(t1.min_bytes/1024/1024,0),2) "Min. Free (MB)",
  ROUND(NVL(t1.avg_bytes/1024/1024,0),2) "Avg. Free (MB)",
  ROUND(NVL(t1.max_bytes/1024/1024,0),2) "Max. Free (MB)",
  NVL(t1.free_ext,0) "Free extents",
  NVL(t3.used,0) "Used extents"
FROM dba_tablespaces t0, (SELECT tablespace_name, SUM(bytes) free_bytes,
                            MIN(bytes) min_bytes,
                            AVG(bytes) avg_bytes,
                            MAX(bytes) max_bytes,
                            COUNT(*) free_ext
                          FROM dba_free_space
                          GROUP BY tablespace_name) t1, 
                         (SELECT tablespace_name, SUM(bytes)/1024/1024 sum_bytes
                          FROM dba_data_files
                          GROUP BY tablespace_name) t2,
                         (SELECT tablespace_name, COUNT(*) used
                          FROM dba_extents
                          GROUP BY tablespace_name) t3
WHERE t0.tablespace_name LIKE UPPER('&isTablespace')                          
AND t0.tablespace_name = t1.tablespace_name (+)
AND t0.tablespace_name = t2.tablespace_name
AND t0.tablespace_name = t3.tablespace_name (+)
ORDER BY t0.tablespace_name;
COL tablespace CLEAR
COL dummy CLEAR
COL size_mb CLEAR
COL free_mb CLEAR

@@title "Temporary Tablespace Space Overview"
COL tablespace FOR a30
COL size_mb HEAD "Size (MB)"
COL free_mb HEAD "Free (MB)"
COL alloc_mb HEAD "Allocated (MB)"
COL used_mb HEAD "Currently|Used (MB)"
COL ext_used HEAD  "Currently|Used extents"
COL dummy NOPRINT
COMPUTE SUM OF size_mb ON dummy
COMPUTE SUM OF free_mb ON dummy
COMPUTE SUM OF alloc_mb ON dummy
COMPUTE SUM OF used_mb ON dummy
BREAK ON dummy
SELECT NULL dummy, t0.tablespace_name "Tablespace",
  ROUND(t2.sum_bytes,2) AS size_mb,
  ROUND(t1.bytes_free/1024/1024,2) free_mb,
  ROUND(t1.bytes_alloc/1024/1024,2) alloc_mb,
  ROUND(t3.bytes_used/1024/1024,2) used_mb,
  t3.ext_used
FROM dba_tablespaces t0, (SELECT tablespace_name, SUM(bytes_free) bytes_free, SUM(bytes_used) bytes_alloc
                          FROM v$temp_space_header
                          GROUP BY tablespace_name) t1, 
                         (SELECT tablespace_name, SUM(bytes)/1024/1024 sum_bytes
                          FROM dba_temp_files
                          GROUP BY tablespace_name) t2,
                         (SELECT tablespace_name, SUM(bytes_used) bytes_used, SUM(extents_used) ext_used
                          FROM v$temp_extent_pool
                          GROUP BY tablespace_name) t3
WHERE t0.tablespace_name LIKE UPPER('&isTablespace')
AND t0.contents = 'TEMPORARY'
AND t0.tablespace_name = t1.tablespace_name (+)
AND t0.tablespace_name = t2.tablespace_name
AND t0.tablespace_name = t3.tablespace_name (+)
ORDER BY t0.tablespace_name;
COL tablespace CLEAR
COL dummy CLEAR
COL size_mb CLEAR
COL free_mb CLEAR
COL alloc_mb CLEAR
COL used_mb CLEAR
COL ext_used CLEAR

SET PAUSE OFF PAGESIZE 24 VERIFY ON






