WHENEVER SQLERROR EXIT ROLLBACK
SET SERVEROUTPUT ON SIZE 1000000
SET LINESIZE 300 TRIMSPOOL ON ECHO OFF VERIFY OFF

ACCEPT isTablespace CHAR PROMPT 'Tablespace Name or Wildcard <%>: ' DEFAULT '%'

CREATE TABLE clone_tbs AS SELECT * FROM dba_tablespaces;
CREATE TABLE clone_dbf AS 
SELECT * FROM dba_data_files
UNION
SELECT * FROM dba_temp_files;

DECLARE
  bFirstDF  BOOLEAN := TRUE;
  nReduce   NUMBER := 0.1;
  sPathTerm CHAR(1) := '/';
  sPath     VARCHAR2(128) := 'd:\oracle_data\DEV1\';
  sDDL      VARCHAR2(4000);
BEGIN
  IF sPath IS NOT NULL THEN
    UPDATE clone_dbf SET file_name = sPath||SUBSTR(file_name, INSTR(file_name, sPathTerm,-1,1)+1, LENGTH(file_name)-INSTR(file_name, sPathTerm,-1,1));
  END IF;

  FOR cTS IN (SELECT tablespace_name, initial_extent, next_extent, max_extents, pct_increase, min_extlen, 
                contents, extent_management, allocation_type
              FROM clone_tbs
              WHERE tablespace_name <> 'SYSTEM'
              AND tablespace_name LIKE UPPER('&isTablespace')) LOOP
    bFirstDF := TRUE;
    FOR cDF IN (SELECT file_name, bytes
                FROM clone_dbf
                WHERE tablespace_name = cTS.tablespace_name
                ORDER BY file_id ASC) LOOP
      IF bFirstDF THEN
        dbms_output.put_line('REM');
        dbms_output.put_line('REM Tablespace: '||LOWER(cTS.tablespace_name));
        dbms_output.put_line('REM');
        IF cTS.extent_management = 'LOCAL' AND cTS.contents = 'TEMPORARY' THEN
          dbms_output.put_line('CREATE TEMPORARY TABLESPACE '||LOWER(cTS.tablespace_name)||
            ' TEMPFILE '''||LOWER(cDF.file_name)||''' SIZE '||ROUND(cDF.bytes*nReduce));        
        ELSE
          dbms_output.put_line('CREATE TABLESPACE '||LOWER(cTS.tablespace_name)||
            ' DATAFILE '''||LOWER(cDF.file_name)||''' SIZE '||ROUND(cDF.bytes*nReduce));
        END IF;
        sDDL := ' EXTENT MANAGEMENT '||cTS.extent_management;        
        IF cTS.extent_management = 'LOCAL' THEN
          IF cTS.allocation_type = 'UNIFORM' THEN
            sDDL := sDDL ||' UNIFORM SIZE '||ROUND(cTS.initial_extent*nReduce)||';';
          ELSE 
            sDDL := sDDL ||' AUTOALLOCATE;';          
          END IF;
        ELSE
          sDDL := sDDL ||' DEFAULT STORAGE (INITIAL '||ROUND(cTS.initial_extent*nReduce)||' NEXT '||ROUND(cTS.next_extent*nReduce);
          IF cTS.max_extents IS NOT NULL THEN
            sDDL := sDDL || ' MAXEXTENTS '||cTS.max_extents;
          END IF;
          sDDL := sDDL ||' PCTINCREASE '||cTS.pct_increase||')';               
          IF cTS.min_extlen > 0 THEN
            sDDL := sDDL ||' MINIMUM EXTENT '||cTS.min_extlen;
          END IF;
          IF cTS.contents = 'TEMPORARY' THEN
            sDDL := sDDL ||' TEMPORARY;';
          ELSE
            sDDL := sDDL ||';';
          END IF;
        END IF;
        dbms_output.put_line(sDDL);
        bFirstDF := FALSE;
      ELSE
        IF cTS.extent_management = 'LOCAL' AND cTS.contents = 'TEMPORARY' THEN      
          dbms_output.put_line('ALTER TABLESPACE '||LOWER(cTS.tablespace_name)||
            ' ADD TEMPFILE '''||LOWER(cDF.file_name)||''' SIZE '||ROUND(cDF.bytes*nReduce)||';');
        ELSE
          dbms_output.put_line('ALTER TABLESPACE '||LOWER(cTS.tablespace_name)||
            ' ADD DATAFILE '''||LOWER(cDF.file_name)||''' SIZE '||ROUND(cDF.bytes*nReduce)||';');
        END IF;
      END IF;
    END LOOP;
  END LOOP;
END;
/

DROP TABLE clone_tbs;
DROP TABLE clone_dbf;
