REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_locks.sql
REM 
REM Version:     1.5
REM
REM Description: Shows locks and blocking locks
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Added dba_lock_internal report to detect                 USC   02.05.02
REM library cache pin locks
REM Renamed from locks.sql to rep_locks.sql and tuning       USC   11.06.02
REM of Internal Locks report
REM FROM clause changed and ORDERED hint implemented to      USC   08.05.03
REM increase performance (in 1st and 2nd statement)
REM Internal Lock Report only shows exclusive locks held     USC   16.07.03
REM and requested
REM Bug in query "Blocking Object Locks Report" solved
REM dba_waiters and dba_blockers added                       USC   20.11.03                                        
REM -------------------------------------------------------------------------

SET LINESIZE 160

@@title "Waiting Sessions"
COL mode_held FOR a20
COL mode_requested FOR a20
SELECT waiting_session, holding_session, lock_type, mode_held, mode_requested
FROM dba_waiters;
COL mode_held CLEAR
COL mode_requested CLEAR

@@title "Blocking Sessions"
SELECT * FROM dba_blockers;

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Locks Report"
COL locker FOR a15
COL object_name FOR a40
COL mode_held FOR a10
SELECT /*+ ORDERED */ s_locker.username locker, DECODE(l_locker.type, 'TM', o.object_name, NULL) AS object_name, 
  s_locker.sid locker_sid, s_locker.serial# serial#, l_locker.ctime locker_time,
  DECODE(l_locker.type, 'MR', 'Media Recovery',
                        'RT', 'Redo Thread',
                        'UN', 'User Name',
                        'TX', 'Transaction',
                        'TM', 'DML',
                        'UL', 'PL/SQL User Lock',
                        'DX', 'Distributed Xaction',
                        'CF', 'Control File',
                        'IS', 'Instance State',
                        'FS', 'File Set',
                        'IR', 'Instance Recovery',
                        'ST', 'Disk Space Transaction',
                        'TS', 'Temp Segment',
                        'IV', 'Library Cache Invalidation',
                        'LS', 'Log Start or Switch',
                        'RW', 'Row Wait',
                        'SQ', 'Sequence Number',
                        'TE', 'Extend Table',
                        'TT', 'Temp Table', l_locker.type) lock_type,
  DECODE(l_locker.lmode, 0, 'None',
                         1, 'Null',
                         2, 'Row-S (SS)',
                         3, 'Row-X (SX)',
                         4, 'Share',
                         5, 'S/Row-X (SSX)',
                         6, 'Exclusive', TO_CHAR(l_locker.lmode)) mode_held  
FROM v$lock l_locker, dba_objects o, v$session s_locker
WHERE l_locker.sid IN (SELECT sid 
                       FROM v$lock)
AND s_locker.sid = l_locker.sid
AND l_locker.id1 = o.object_id
AND l_locker.id1 IS NOT NULL
AND s_locker.username IS NOT NULL
ORDER BY 2;
COL locker CLEAR
COL object_name CLEAR
COL mode_held CLEAR

@@title "Blocking Object Locks Report"
REM
REM If blocking "Row-X locks" are reported it doesn't necessarily mean that
REM the lock is on the same row
REM 
COL object_name FOR a30
COL mode_held FOR a10
SELECT /*+ ORDERED */ l_locker.sid locker_sid, s_locker.serial# locker_serial#, l_waiter.sid waiter_sid, v1.object_name, 
  DECODE(l_locker.type, 'MR', 'Media Recovery',
                        'RT', 'Redo Thread',
                        'UN', 'User Name',
                        'TX', 'Transaction',
                        'TM', 'DML',
                        'UL', 'PL/SQL User Lock',
                        'DX', 'Distributed Xaction',
                        'CF', 'Control File',
                        'IS', 'Instance State',
                        'FS', 'File Set',
                        'IR', 'Instance Recovery',
                        'ST', 'Disk Space Transaction',
                        'TS', 'Temp Segment',
                        'IV', 'Library Cache Invalidation',
                        'LS', 'Log Start or Switch',
                        'RW', 'Row Wait',
                        'SQ', 'Sequence Number',
                        'TE', 'Extend Table',
                        'TT', 'Temp Table', l_locker.type) lock_type,
  DECODE(l_locker.lmode, 0, 'None',
                         1, 'Null',
                         2, 'Row-S (SS)',
                         3, 'Row-X (SX)',
                         4, 'Share',
                         5, 'S/Row-X (SSX)',
                         6, 'Exclusive', TO_CHAR(l_locker.lmode)) mode_held
FROM v$lock l_locker, v$lock l_waiter, dba_objects v1, v$session s_locker
WHERE l_locker.sid IN (SELECT sid
                       FROM v$lock
                       WHERE block = 1)
AND l_locker.addr != l_waiter.addr
AND l_locker.id1 = l_waiter.id1
AND l_locker.id2 = l_waiter.id2
AND l_locker.id1 = v1.object_id
AND l_locker.lmode > 0
AND l_locker.lmode <> 4
AND l_waiter.lmode > 0
AND l_locker.sid = s_locker.sid;
COL object_name CLEAR
COL mode_held CLEAR

@@title "Internal Blocking Locks Report"
COL waiter_mode FOR a15
COL locker_mode FOR a15
COL lock_type FOR a30
COL lock_id1 FOR a30
SELECT /*+ ORDERED */ l_locker.session_id locker_sid, v1.serial#, l_locker.lock_type, l_locker.mode_held locker_mode, l_locker.lock_id1,
  l_waiter.session_id waiter_sid, l_waiter.mode_requested waiter_mode, l_waiter.lock_id1
FROM dba_lock_internal l_waiter, dba_lock_internal l_locker, v$session v1
WHERE l_waiter.lock_id1 = l_locker.lock_id1
-- AND l_waiter.mode_requested = 'Exclusive'
-- AND l_waiter.lock_id2 = l_locker.lock_id2
AND l_locker.session_id <> l_waiter.session_id
AND l_locker.mode_held = 'Exclusive'
AND l_locker.session_id = v1.sid;
COL waiter_mode CLEAR
COL locker_mode CLEAR
COL lock_type CLEAR
COL lock_id1 CLEAR

SET PAUSE OFF
