REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        hidden.sql
REM 
REM Version:     1.0
REM
REM Description: Shows hidden init.ora parameters
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   06.11.03
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 160

ACCEPT sSearch CHAR PROMPT 'Search String or Wildcard <%>: ' DEFAULT '%'

@@title "Hidden undocumented init.ora parameters"
COL ksppinm FOR a40
COL value FOR a40
SELECT x1.ksppinm, NVL(x2.ksppstvl, 'NULL') AS value, x1.ksppdesc
FROM sys.x$ksppi x1, sys.x$ksppcv x2
WHERE x1.ksppinm LIKE '\_%' ESCAPE '\'
AND x1.indx = x2.indx
AND UPPER(x1.ksppinm||x1.ksppdesc) LIKE UPPER('&sSearch')
ORDER BY x1.ksppinm;
COL ksppinm CLEAR
COL value CLEAR

SET PAGESIZE 24
