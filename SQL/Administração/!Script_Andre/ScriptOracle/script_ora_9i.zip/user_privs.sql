REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        user_privs.sql
REM 
REM Version:     1.4
REM
REM Description: Shows roles and privileges granted to a user or role
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Display of profile informations added   	             USC   07.01.02
REM Rename of user_privs.sql to user_rep.sql,                USC   10.01.02
REM profile info added                                       
REM default_role in Role Report added                        USC   14.06.02
REM -------------------------------------------------------------------------

SET LINESIZE 160

ACCEPT sUserName CHAR PROMPT 'Username or Wildcard <%>: ' DEFAULT '%'
ACCEPT isTableName CHAR PROMPT 'Table Name or Wildcard <%>: ' DEFAULT '%'

@@title "Role Report"
COL admin_option FOR a12
COL default_role FOR a12
SELECT grantee, granted_role, admin_option, default_role
FROM dba_role_privs
WHERE grantee LIKE UPPER('&sUserName')
ORDER BY grantee, granted_role;
COL admin_option CLEAR
COL default_role CLEAR

@@title "System Privilege Report"
SELECT grantee, privilege, admin_option
FROM dba_sys_privs
WHERE grantee LIKE UPPER('&sUserName')
ORDER BY grantee, privilege;

@@title "Quota Report"
SELECT username, tablespace_name, bytes/1024/1024 "Used", max_bytes/1024/1024 "Max"
FROM dba_ts_quotas
WHERE username LIKE UPPER('&sUserName')
ORDER BY username, tablespace_name;

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Password Profile Status"
COL expiry_date FOR a21
COL lock_date FOR a21
SELECT username, profile, account_status, 
  TO_CHAR(expiry_date, 'DD-MM-YYYY HH24:MI:SS') expiry_date, 
  TO_CHAR(lock_date, 'DD-MM-YYYY HH24:MI:SS') lock_date
FROM dba_users
WHERE username LIKE UPPER('&sUserName')
ORDER BY username;
COL expiry_date CLEAR
COL lock_date CLEAR

@@title "Profile Report"
BREAK ON username ON profile
SELECT t1.username, t2.profile, t2.resource_name, t2.limit
FROM dba_users t1, dba_profiles t2
WHERE t1.username LIKE UPPER('&sUserName')
AND t1.profile = t2.profile
ORDER BY t1.username, t2.profile, t2.resource_name;
CLEAR BREAKS

@@title "Object Privilege Report"
SELECT grantee, owner||'.'||table_name "Object", privilege
FROM dba_tab_privs
WHERE grantee LIKE UPPER('&sUserName')
AND table_name LIKE UPPER('&isTableName')
ORDER BY grantee, privilege, owner||'.'||table_name;

SET PAUSE OFF
