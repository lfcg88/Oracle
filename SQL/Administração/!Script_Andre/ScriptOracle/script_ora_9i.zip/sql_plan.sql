REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         sql_plan.sql
REM 
REM Version:      1.2
REM
REM Requirements: Oracle9i
REM
REM Description:  Shows explain plan of SQL of an active session
REM
REM Display of explain plan taken from $ORACLE_HOME\rdbms\admin\utlxplp.sql
REM 
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   20.08.01
REM FROM (SELECT DISTINCT * FROM v$sql_plan) to avoid        USC   08.05.03
REM multiple rows of parallel queries
REM Removed sql_address = address in where clauses           USC   16.11.03
REM Complete rewrite using DBMS_XPLAN.DISPLAY, 
REM see sql_pga.sql for PGA usage statistics                 USC   17.11.03
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 160 VERIFY OFF

ACCEPT sSid CHAR PROMPT 'Session ID: ' DEFAULT '-1'

INSERT INTO plan_table
 (statement_id,
  timestamp,
  remarks,
  operation,
  options,
  object_node,
  object_owner,
  object_name,
  object_instance,
  object_type,
  optimizer,
  search_columns,
  id,
  parent_id,
  position,
  cost,
  cardinality,
  bytes,
  other_tag,
  partition_start,
  partition_stop,
  partition_id,
  other,
  distribution,
  cpu_cost,
  io_cost,
  temp_space,
  access_predicates,
  filter_predicates)
SELECT
 'EXP_USC',
  SYSDATE,
  NULL,
  operation,
  options,
  object_node,
  object_owner,
  object_name,
  NULL,
  NULL,
  optimizer,
  search_columns,
  id,
  parent_id,
  position,
  cost,
  cardinality,
  bytes,
  other_tag,
  partition_start,
  partition_stop,
  partition_id,
  other,
  distribution,
  cpu_cost,
  io_cost,
  temp_space,
  access_predicates,
  filter_predicates
FROM (SELECT DISTINCT
        address,
        hash_value,
        child_number,
        operation,
        options,
        object_node,
        object#,
        object_owner,
        object_name,
        optimizer,
        id,
        parent_id,
        depth,
        position,
        search_columns,
        cost,
        cardinality,
        bytes,
        other_tag,
        partition_start,
        partition_stop,
        partition_id,
        other,    
        distribution,
        cpu_cost,         
        io_cost,      
        temp_space,
        NULL AS access_predicates,
        NULL AS filter_predicates
        -- The attributes ACCESS_PREDICATES, FILTER_PREDICATES
        -- cannot be captured because of ORA-03113: end-of-file on communication channel and massiv library cache latch waits!?!        
      FROM v$sql_plan)
WHERE (address, hash_value) = (SELECT DECODE(sql_address, '00', prev_sql_addr, sql_address), 
                                 DECODE(sql_hash_value, 0, prev_hash_value, sql_hash_value)
                               FROM v$session
                               WHERE sid = DECODE(TO_NUMBER('&sSid'), -1, -1, TO_NUMBER('&sSid')));

SET ECHO OFF FEEDBACK OFF

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY('plan_table', 'EXP_USC', 'all'));

DELETE FROM plan_table WHERE statement_id = 'EXP_USC';
COMMIT;

SET FEEDBACK ON

