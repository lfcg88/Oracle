REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        ind_part.sql
REM 
REM Version:     1.3
REM
REM Description: Shows partitioned index details
REM              
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   06.12.00
REM Added Subpartitioning support                            USC   13.06.01
REM Added dba_part_key_columns information                   USC   12.12.01
REM DEF_xxx columns of dba_part_indexes added                USC   04.03.02
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 80 DOCU OFF

ACCEPT isIndexOwner CHAR PROMPT 'Index Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT isIndexName CHAR PROMPT 'Index Name: ' DEFAULT '-'

@@title "Index Partition Report"
COL owner FOR a12
COL partition_count HEAD "PARTITIONS"
COL column_name HEAD "PARTITION-KEY" FOR a20
COL def_initial_extent HEAD "DEF_-|INITIAL_-|EXTENT" FOR a9
COL def_next_extent HEAD "DEF_-|NEXT_-|EXTENT" FOR a9
BREAK ON owner ON index_name ON type ON partition_count
SELECT p.owner, p.index_name, p.partitioning_type ||' ('||p.locality||' '||p.alignment||')' type,
  p.partition_count, pc.column_name, p.def_tablespace_name, p.def_initial_extent, p.def_next_extent
FROM dba_part_indexes p, dba_part_key_columns pc
WHERE p.owner LIKE UPPER('&isIndexOwner')
AND p.index_name = UPPER('&isIndexName')
AND p.owner = pc.owner
AND p.index_name = pc.name
-- The following SQL LIKE fragment is necessary, seems to be a bug in Oracle
AND pc.object_type LIKE 'INDEX%'
ORDER BY 1,2;
CLEAR BREAKS
COL owner CLEAR
COL partition_count CLEAR
COL column_name CLEAR
COL def_initial_extent CLEAR
COL def_next_extent CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Index Partition Detail Report"
COL partition_name FOR a30
COL ranges FOR a50
COL subpartition_count FOR 999 HEAD "SUB|PARTS"
COL composite FOR a5 HEAD "COMP-|OSITE"
COL buffer_pool HEAD "BUFFER-|POOL"
SELECT ip.partition_name, ip.tablespace_name, ip.high_value ranges, ip.subpartition_count, status, composite, logging, buffer_pool
FROM dba_ind_partitions ip
WHERE ip.index_owner LIKE UPPER('&isIndexOwner')
AND ip.index_name = UPPER('&isIndexName')
ORDER BY ip.partition_position;
COL partition_name CLEAR
COL ranges CLEAR
COL subpartition_count CLEAR
COL composite CLEAR
COL buffer_pool CLEAR

@@title "Index Partition Space Usage Report"
COL partition_name FOR a30
COL intial_MB FOR 9999.00 HEAD "INTIAL|(MB)"
COL next_MB FOR 9999.00 HEAD "NEXT|(MB)"
COL extents HEAD "EX-|TENTS" FOR 999 JUS L 
COL bytes_mb HEAD "SPACE|USAGE(MB)" FOR 999999.00 JUS L
COL part_position NOPRINT
COL subpart_position NOPRINT
BREAK ON partition_name
SELECT t1.partition_name, NULL subpartition_name, t1.tablespace_name, t1.initial_extent/1024/1024 intial_MB, t1.next_extent/1024/1024 next_MB,
  t2.extents, t2.bytes/1024/1024 bytes_mb, t1.status, t1.partition_position part_position, 1 subpart_position
FROM dba_ind_partitions t1, dba_segments t2
WHERE t1.index_owner LIKE UPPER('&isIndexOwner')
AND t1.index_name = UPPER('&isIndexName')
AND t1.index_owner = t2.owner
AND t1.index_name = t2.segment_name
AND t1.partition_name = t2.partition_name
UNION
SELECT t2.partition_name, t2.subpartition_name, t2.tablespace_name, t2.initial_extent/1024/1024 intial_MB, t2.next_extent/1024/1024 next_MB,
  t3.extents, t3.bytes/1024/1024 bytes_mb, t2.status, t1.partition_position part_position, t2.subpartition_position subpart_position
FROM dba_ind_partitions t1, dba_ind_subpartitions t2, dba_segments t3
WHERE t1.index_owner LIKE UPPER('&isIndexOwner')
AND t1.index_name = UPPER('&isIndexName')
AND t1.index_owner = t2.index_owner
AND t1.index_name = t2.index_name
AND t1.partition_name = t2.partition_name
AND t2.index_owner = t3.owner
AND t2.index_name = t3.segment_name
AND t2.subpartition_name = t3.partition_name
ORDER BY part_position, subpart_position ASC;
CLEAR BREAKS
COL part_position CLEAR
COL subpart_position CLEAR
COL partition_name CLEAR
COL intial_MB CLEAR
COL next_MB CLEAR
COL bytes_mb CLEAR
COL extents CLEAR

/*
@@title "Index Partition Storage Report"
COL partition_name FOR a30
COL pct_free HEAD "PCT|FREE" FOR 999 JUS L
COL pct_used HEAD "PCT|USED" FOR 999 JUS L 
COL ini_trans HEAD "INI|TRANS" FOR 999 JUS L
COL max_trans HEAD "MAX|TRANS" FOR 999 JUS L
COL min_extent HEAD "MIN|EXTENTS" FOR 999 JUS L
COL max_extent HEAD "MAX|EXTENTS" JUS L
COL pct_increase HEAD "PCT|INCR" FOR 999 JUS L
COL freelists HEAD "FREE|LISTS" FOR 999 JUS L
COL freelist_groups HEAD "FREELIST|GROUPS" FOR 999 JUS L
COL part_position NOPRINT
COL subpart_position NOPRINT
BREAK ON partition_name
SELECT t1.partition_name, NULL subpartition_name, t1.tablespace_name, t1.min_extent, t1.max_extent, t1.pct_increase, t1.freelists, t1.freelist_groups,
  t1.pct_free, t1.ini_trans, t1.max_trans, t1.partition_position part_position, 0 subpart_position
FROM dba_ind_partitions t1
WHERE t1.index_owner LIKE UPPER('&isIndexOwner')
AND t1.index_name = UPPER('&isIndexName')
UNION
SELECT t2.partition_name, t2.subpartition_name, t2.tablespace_name, t2.min_extent, t2.max_extent, t2.pct_increase, t2.freelists, t2.freelist_groups,
  t2.pct_free, t2.ini_trans, t2.max_trans, t1.partition_position part_position, t2.subpartition_position subpart_position
FROM dba_ind_partitions t1, dba_ind_subpartitions t2
WHERE t1.index_owner LIKE UPPER('&isIndexOwner')
AND t1.index_name = UPPER('&isIndexName')
AND t1.index_owner = t2.index_owner
AND t1.index_name = t2.index_name
AND t1.partition_name = t2.partition_name
ORDER BY part_position, subpart_position ASC;
CLEAR BREAKS
COL part_position CLEAR
COL subpart_position CLEAR
COL partition_name CLEAR
COL pct_free CLEAR
COL pct_used CLEAR
COL ini_trans CLEAR
COL max_trans CLEAR
COL min_extent CLEAR
COL max_extent CLEAR
COL pct_increase CLEAR
COL freelists CLEAR
COL freelist_groups CLEAR
*/

@@title "Index Partition Statistics Report"
COL partition_name FOR a30
COL global_stats FOR a7 HEAD "GLOBAL-|STATS"
COL user_stats FOR a5 HEAD "USER-|STATS"
COL last_analyzed FOR a20
COL sample_size FOR 9999999 HEAD "SAMPLE-|SIZE"
COL part_position NOPRINT
COL subpart_position NOPRINT
BREAK ON partition_name
SELECT t1.partition_name, NULL subpartition_name, t1.last_analyzed, t1.distinct_keys, t1.num_rows, 
  t1.sample_size, t1.global_stats, t1.user_stats, t1.partition_position part_position, 0 subpart_position
FROM dba_ind_partitions t1
WHERE t1.index_owner LIKE UPPER('&isIndexOwner')
AND t1.index_name = UPPER('&isIndexName')
UNION
SELECT t2.partition_name, t2.subpartition_name, t2.last_analyzed, t2.distinct_keys, t2.num_rows, 
  t2.sample_size, t2.global_stats, t2.user_stats, t1.partition_position part_position, t2.subpartition_position subpart_position
FROM dba_ind_partitions t1, dba_ind_subpartitions t2
WHERE t1.index_owner LIKE UPPER('&isIndexOwner')
AND t1.index_name = UPPER('&isIndexName')
AND t1.index_owner = t2.index_owner
AND t1.index_name = t2.index_name
AND t1.partition_name = t2.partition_name
ORDER BY part_position, subpart_position ASC;
CLEAR BREAKS
COL part_position CLEAR
COL subpart_position CLEAR
COL sample_size CLEAR
COL partition_name CLEAR
COL global_stats CLEAR
COL user_stats CLEAR
COL last_analyzed CLEAR

SET PAUSE OFF PAGESIZE 24 DOCU ON
