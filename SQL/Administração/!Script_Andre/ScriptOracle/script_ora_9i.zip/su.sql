REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        su.sql
REM 
REM Version:     1.0
REM
REM Description: Connects to an user, who's password is unknown.
REM              Requires ALTER USER and SELECT ON DBA_USERS privilege
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                        28.05.01
REM -------------------------------------------------------------------------

ACCEPT sUserName CHAR PROMPT 'Username: ' DEFAULT '-'
ACCEPT sTNS CHAR PROMPT 'Host String: ' DEFAULT '-'

SET FEED OFF TERMOUT OFF VERIFY OFF HEAD OFF
COL nl NEWLINE

SPOOL su.tmp

SELECT 'ALTER USER '||UPPER('&sUserName')||' IDENTIFIED BY '||UPPER('&sUserName')||'xx;' nl,
  'CONNECT '||UPPER('&sUserName')||'/'||UPPER('&sUserName')||'xx'||DECODE('&sTNS','-',';','@'||'&sTNS;') nl,
  'ALTER USER '||UPPER('&sUserName')||' IDENTIFIED BY VALUES '''||u.password||''';' nl
FROM sys.dba_users u
WHERE u.username = UPPER('&sUserName')
AND u.username <> USER;

SPOOL OFF

@su.tmp

REM
REM Replace 'del' with 'rm' if working under UNIX
REM
HOST del su.tmp

SET TERMOUT ON

SELECT 'Connected as '||USER||' on '||global_name||'.'
FROM global_name;

SET FEED ON HEAD ON
