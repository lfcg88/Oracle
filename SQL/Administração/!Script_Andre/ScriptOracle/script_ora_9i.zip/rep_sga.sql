REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_sga.sql
REM 
REM Version:      1.1
REM
REM Requirements: Oracle9i
REM
REM Description:  Reports SGA statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Added "Buffer Pool LRU Latch Contention Report"          USC   06.11.03
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 160

@@title "SGA Size Report"
COL dummy NOPRINT
COL size_MB FOR 999999.00
COMPUTE SUM OF size_mb ON dummy
BREAK ON dummy
SELECT null dummy, name, value/1024/1024 AS Size_mb
FROM v$sga;
CLEAR BREAKS
COL dummy CLEAR
COL size_mb CLEAR

@@title "SGA Pool Report"
COL init_size FOR a20
SELECT v1.pool, v2.value init_size, v1.bytes free
FROM v$sgastat v1, (SELECT 'shared pool' name, value
                    FROM v$parameter
                    WHERE name = 'shared_pool_size') v2
WHERE v1.name = 'free memory'
AND v1.pool = v2.name
UNION
SELECT v1.pool, v2.value init_size, v1.bytes free
FROM v$sgastat v1, (SELECT 'large pool' name, value
                    FROM v$parameter
                    WHERE name = 'large_pool_size') v2
WHERE v1.name = 'free memory'
AND v1.pool = v2.name
UNION
SELECT v1.pool, v2.value init_size, v1.bytes free
FROM v$sgastat v1, (SELECT 'java pool' name, value
                    FROM v$parameter
                    WHERE name = 'java_pool_size') v2
WHERE v1.name = 'free memory'
AND v1.pool = v2.name;
COL init_size CLEAR

@@title "PGA Settings Report"
COL name FOR a30
COL value FOR a30
SELECT name, value
FROM v$parameter
WHERE name like '%_area_size'
OR name = 'pga_aggregate_target'
ORDER BY name;
COL name CLEAR
COL value CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Buffer Pool Report"
COL size_mb FOR 99999.00
SELECT id, name, block_size, buffers, buffers*block_size/1024/1024 size_mb, set_count lru_latches,
  current_size, target_size, prev_size
FROM v$buffer_pool
ORDER BY id, name, block_size;
COL size_mb CLEAR

SET PAUSE OFF

@@title "Overall Block Buffer Hit Ratio Report"
SELECT pr.value physical_reads, bg.value db_block_gets, cg.value consistent_gets, prd.value phys_reads_direct, prdl.value phys_reads_direct_lob,
  ROUND((1-(pr.value-prd.value-prdl.value)/(bg.value+cg.value-prd.value-prdl.value))*100,2) "Hit Ratio"
FROM v$sysstat pr, v$sysstat bg, v$sysstat cg, v$sysstat prd, v$sysstat prdl
WHERE pr.name = 'physical reads'
AND bg.name = 'db block gets'
AND cg.name = 'consistent gets'
AND prd.name = 'physical reads direct'
AND prdl.name = 'physical reads direct (lob)';

@@title "Block Buffer Pool Hit Ratio Report"
COL init_size FOR 999999.00
SELECT v1.name, v1.block_size, v2.physical_reads, v2.db_block_gets, v2.consistent_gets, 
  ROUND((1-(v2.physical_reads/DECODE(v2.db_block_gets+v2.consistent_gets,0,1,v2.db_block_gets+v2.consistent_gets)))*100,2) "Hit Ratio"
FROM v$buffer_pool v1, v$buffer_pool_statistics v2
WHERE v1.id = v2.id
AND v1.name = v2.name
ORDER BY v1.name, v1.block_size;
COL init_size CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Buffer Pool LRU Latch Contention Report"
COL name FOR a7
COL child# FOR 999
COL wait_hit HEAD "Wait|Hit Ratio" JUS C
COL no_wait_hit HEAD "No Wait|Hit Ratio" JUS C
BREAK ON id ON name ON buffers
SELECT t1.id, t1.name, t1.buffers, t2.child#, t2.gets, t2.misses, 
  round((1-(t2.misses/decode(t2.gets,0,1,t2.gets)))*100,2) wait_hit, 
  t2.immediate_gets, t2.immediate_misses, 
  round((1-(t2.immediate_misses/decode(t2.immediate_gets,0,1,t2.immediate_gets)))*100,2) no_wait_hit
FROM v$latch_children t2, v$buffer_pool t1
WHERE t2.child# >= t1.lo_setid
AND t2.child# <= hi_setid
AND t2.name = 'cache buffers lru chain'
AND t1.buffers > 0
ORDER BY t1.id, t1.name, t2.child#;
CLEAR BREAKS
COL name CLEAR
COL child# CLEAR
COL wait_hit CLEAR
COL no_wait_hit CLEAR

@@title "Dictionary Cache Hit Ratio Report"
SELECT ROUND((1-(SUM(getmisses)/SUM(gets)))*100,2) "Hit Ratio"
FROM v$rowcache;

SET PAUSE OFF

@@title "Library Cache Hit Ratio Report"
SELECT ROUND(SUM(gethits)/SUM(gets)*100,2) "Hit Ratio", ROUND(SUM(pinhits)/SUM(pins) * 100,2) "Pin Hit Ratio",
  ROUND(SUM(reloads)/SUM(pins)*100,2) "Miss Ratio", SUM(reloads) "Reloads"
FROM v$librarycache;

@@title "Redo Buffer Hit Ratio Report"
SELECT ROUND((1 - (t2.value/t1.value))*100,2) "Redo Nowait Ratio(%)"
FROM v$sysstat t1, v$sysstat t2
WHERE t1.name = 'redo entries'
AND t2.name = 'redo buffer allocation retries';

@@title "Sort Area Efficency Report"
SELECT ROUND((SUM(DECODE(name, 'sorts (memory)', value, 0))
  / (SUM(DECODE(name, 'sorts (memory)', value, 0))
  + SUM(DECODE(name, 'sorts (disk)', value, 0))))*100,2) "Hit Ratio"
FROM v$sysstat;

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Dictionary Cache Details"
COL hit_ratio FOR 999.9
SELECT parameter, SUM(gets), SUM(getmisses), SUM(gets-getmisses)/SUM(gets)*100 hit_ratio, SUM(modifications)
FROM v$rowcache
WHERE gets > 0
GROUP BY parameter;
COL hit_ratio CLEAR

@@title "Block Buffer Pool Setting Advice"
SELECT name, block_size, size_for_estimate, estd_physical_read_factor, estd_physical_reads
FROM v$db_cache_advice
WHERE advice_status = 'ON';

@@title "Shared Pool Setting Advice"
SELECT shared_pool_size_for_estimate, estd_lc_size, estd_lc_time_saved_factor, estd_lc_memory_object_hits
FROM v$shared_pool_advice;

SET PAGESIZE 24 PAUSE OFF



