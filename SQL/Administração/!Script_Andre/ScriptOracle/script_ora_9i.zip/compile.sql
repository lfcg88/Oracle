REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        compile.sql
REM 
REM Version:     1.1
REM
REM Description: Shows all invalid objects and creates a spool file for
REM              recompiling the invalid objects
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Column dummy to get a better compilation sequence        USC   15.05.02
REM -------------------------------------------------------------------------

SET TRIMSPOOL ON LINESIZE 200

ACCEPT sOwnerName CHAR PROMPT 'Owner or Wildcard <%>: ' DEFAULT '%'

@@title "Number of invalid objects per user"
SELECT owner, count(*)
FROM dba_objects
WHERE status <> 'VALID'
GROUP BY owner;

@@title "Unhandled invalid objects (compile manually!)"
SELECT owner, object_name, object_type
FROM dba_objects
WHERE status <> 'VALID'
AND owner LIKE UPPER('&sOwnerName')
AND object_type NOT IN ('VIEW', 'TRIGGER', 'PROCEDURE', 'FUNCTION', 'PACKAGE', 'PACKAGE BODY');

SET HEAD OFF PAGESIZE 0 FEED OFF

PROMPT REM 
PROMPT REM The following statements could be run by c:\temp\inv_obj.sql
PROMPT REM
PROMPT

COL owner NOPRINT
COL object_type NOPRINT

SPOOL c:\temp\inv_obj.sql

COL dummy NOPRINT
SELECT 1 dummy, owner, object_type, 'alter view '||owner||'.'||object_name||' compile;'
FROM dba_objects
WHERE status <> 'VALID'
AND owner LIKE UPPER('&sOwnerName')
AND object_type = 'VIEW'
UNION
SELECT 2 dummy, owner, object_type, 'alter trigger '||owner||'.'||object_name||' compile;'
FROM dba_objects
WHERE status <> 'VALID'
AND owner LIKE UPPER('&sOwnerName')
AND object_type = 'TRIGGER'
UNION
SELECT 3 dummy, owner, object_type, 'alter procedure '||owner||'.'||object_name||' compile;'
FROM dba_objects
WHERE status <> 'VALID'
AND owner LIKE UPPER('&sOwnerName')
AND object_type = 'PROCEDURE'
UNION
SELECT 4 dummy, owner, object_type, 'alter function '||owner||'.'||object_name||' compile;'
FROM dba_objects
WHERE status <> 'VALID'
AND owner LIKE UPPER('&sOwnerName')
AND object_type = 'FUNCTION'
UNION
SELECT 5 dummy, owner, object_type, 'alter package '||owner||'.'||object_name||' compile;'
FROM dba_objects
WHERE status <> 'VALID'
AND owner LIKE UPPER('&sOwnerName')
AND object_type = 'PACKAGE'
UNION
SELECT 6 dummy, owner, object_type, 'alter package '||owner||'.'||object_name||' compile body;'
FROM dba_objects
WHERE status <> 'VALID'
AND owner LIKE UPPER('&sOwnerName')
AND object_type = 'PACKAGE BODY'
ORDER BY dummy ASC, owner;
COL dummy CLEAR

SPOOL OFF

COL owner CLEAR
COL object_type CLEAR

PROMPT
PROMPT REM
PROMPT REM RUN c:\temp\inv_obj.sql TO COMPILE INVALID OBJECTS
PROMPT REM
PROMPT

SET FEED ON HEAD ON TRIMSPOOL OFF PAGESIZE 48
