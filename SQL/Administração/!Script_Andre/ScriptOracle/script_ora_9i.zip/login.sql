REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        login.sql
REM 
REM Version:     1.1
REM
REM Description: Creates SQL Plus login header and SQL> prompt
REM              Copy it to $ORACLE_HOME/bin
REM
REM Privileges:  granted role SELECT_CATALOG_ROLE or$
REM              select privileges on v_$session, v_$process and v_$instance
REM              and private or public synonyms
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                        10.01.00
REM Added hostname into SQL prompt                                 13.07.01
REM Storage of SQLPlus settings                              USC   11.11.03
REM -------------------------------------------------------------------------

SET NUMWIDTH 9
SET LINESIZE 100
SET PAGESIZE 48
SET ARRAYSIZE 10

SELECT SUBSTR(p.username||' as '||s.username||' at '||g.global_name,1,50) "Who am I ?",
  s.sid "SID",
  p.spid "PID",
  s.server "Server"
FROM v$session s, v$process p, global_name g
WHERE s.paddr = p.addr
AND s.audsid = USERENV('sessionid');

SET TERMOUT OFF ECHO OFF

COL global_name NEW_VALUE global_name
SELECT LOWER(s.username||'@'||substr(global_name,1,instr(global_name,'.')-1)||'.'||v.host_name) global_name
FROM  global_name, v$session s, v$instance v
WHERE s.audsid = USERENV('sessionid');

STORE SET sqlplus_settings REPLACE

SET TERMOUT ON
SET SQLPROMPT "&global_name._SQL> "
COL global_name CLEAR

SET FEED ON
