REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        user_waits.sql
REM 
REM Version:     1.3
REM
REM Description: Shows wait statistics of a given  session id (SID)
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   15.10.01
REM Additional attributes added like wait_time, etc.         USC   06.11.03
REM Additional PROMPTS added                                 USC   18.11.03
REM -------------------------------------------------------------------------

SET VERIFY OFF LINESIZE 160

ACCEPT sSid CHAR PROMPT 'Session ID or Wildcard <%>: ' DEFAULT '%'
ACCEPT sEvent CHAR PROMPT 'Event Name or Wildcard <%>: ' DEFAULT '%'

COL event FOR a40
SELECT sid, seq#, event, wait_time, seconds_in_wait, state, p1, p2, p3
FROM v$session_wait
WHERE sid LIKE '&sSid'
AND event LIKE '&sEvent'
UNION 
SELECT sid, seq#, event, wait_time, seconds_in_wait, state, p1, p2, p3
FROM v$session_wait
WHERE sid IN (SELECT sid
              FROM v$px_session
              WHERE qcsid LIKE '&sSid')
AND event LIKE '&sEvent';
REM COL event CLEAR