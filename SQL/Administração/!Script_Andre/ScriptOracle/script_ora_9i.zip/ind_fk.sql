REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        ind_fk.sql
REM 
REM Version:     1.0
REM
REM Description: Shows FK constraints with no index
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   17.11.03
REM -------------------------------------------------------------------------

SET ECHO OFF VERIFY OFF LINESIZE 160 PAGESIZE 48 LONG 80

ACCEPT sOwnerName CHAR PROMPT 'Table Owner or Wildcard <%>: ' DEFAULT '%'

@@title "FK Constraints with no index"
COL owner FOR a10
COL column_name FOR a20
BREAK ON owner ON constraint_name ON constraint_type
SELECT t1.owner, t1.constraint_name, t1.constraint_type, t2.column_name
FROM dba_constraints t1, dba_cons_columns t2
WHERE t1.owner LIKE UPPER('&sOwnerName')
AND t1.constraint_type = 'R'
AND t1.owner = t2.owner
AND t1.constraint_name = t2.constraint_name
AND t1.table_name = t2.table_name
AND NOT EXISTS (SELECT 1
                FROM dba_ind_columns t3
                WHERE t3.table_owner = t1.owner
                AND t3.index_owner = t1.owner
                AND t3.column_name = t2.column_name
                AND t3.column_position = t2.position)
ORDER BY t1.owner, t1.constraint_name, t2.position;
CLEAR BREAKS
COL owner CLEAR
COL column_name CLEAR
