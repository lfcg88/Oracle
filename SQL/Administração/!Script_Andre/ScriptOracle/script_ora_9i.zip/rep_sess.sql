
REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_sess.sql
REM 
REM Version:      1.0
REM
REM Requirements: Oracle9i
REM
REM Description:  Shows session details
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   03.11.03
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 999

ACCEPT sUserName CHAR PROMPT 'Username or Wildcard <%>: ' DEFAULT '%'
ACCEPT sActive CHAR PROMPT 'Status or Wildcard <a%>: ' DEFAULT 'a%'
ACCEPT sSearch CHAR PROMPT 'Search String (program||client_info||action) or Wildcard <%>: ' DEFAULT '%'

@@title "Session Report"
COL username FOR a14
COL sid_serial FOR a10
COL spid FOR a6
COL status FOR a10
COL program FOR a25 TRUNCATED
COL action FOR a20 TRUNCATED
COL client_info FOR a20 TRUNCATED
COL osuser FOR a10 TRUNCATED
COL lockwait FOR a4 HEAD "LOCK|WAIT"
COL command FOR a7 HEAD "COMMAND"
SELECT v0.username, v0.sid||','||v0.serial# AS sid_serial, v1.spid, v0.status, v0.osuser, 
  TO_CHAR(v0.logon_time, 'DD-MM-YY HH24:MI:SS') AS logon_time,
  NVL2(v0.lockwait, 'WAIT', NULL) AS lockwait,
  CASE
    WHEN v0.command = 2 THEN
      'INS'
    WHEN v0.command = 3 THEN
      'SEL'
    WHEN v0.command = 6 THEN
      'UPD'
    WHEN v0.command = 7 THEN
      'DEL'
    WHEN v0.command = 47 THEN
      'PLSQL'
    WHEN v0.command = 27 THEN
      'NOOP'
    WHEN v0.command IN (1,4,5) OR 
      v0.command BETWEEN 8 AND 26 OR
      v0.command BETWEEN 28 AND 46 OR
      v0.command BETWEEN 48 AND 99 THEN
      'DDL('||v0.command||')'
    ELSE
      '?('||v0.command||')'
  END AS command,
  v0.program, v0.client_info, v0.action
FROM v$session v0, v$process v1
WHERE v0.username LIKE UPPER('&sUserName')
AND NVL(v0.status, '-') LIKE UPPER('&sActive')
AND NVL(UPPER(v0.program||v0.client_info||v0.action), '-') LIKE UPPER('&sSearch')
AND v0.paddr = v1.addr (+)
ORDER BY v0.status DESC, v0.username, v0.program;
/*
COL username CLEAR
COL sid_serial CLEAR
COL spid CLEAR
COL status CLEAR
COL program CLEAR
COL action CLEAR
COL client_info CLEAR
COL osuser CLEAR
COL lockwait CLEAR
COL command CLEAR
*/

SET DOCU OFF
/*
REM
REM Command Values:
REM
1: CREATE TABLE

2: INSERT

3: SELECT

4: CREATE CLUSTER

5: ALTER CLUSTER

6: UPDATE

7: DELETE

8: DROP CLUSTER

9: CREATE INDEX

10: DROP INDEX

11: ALTER INDEX

12: DROP TABLE

13: CREATE SEQUENCE

14: ALTER SEQUENCE

15: ALTER TABLE

16: DROP SEQUENCE

17: GRANT

18: REVOKE

19: CREATE SYNONYM

20: DROP SYNONYM

21: CREATE VIEW

22: DROP VIEW

23: VALIDATE INDEX

24: CREATE PROCEDURE

25: ALTER PROCEDURE

26: LOCK TABLE

27: NO OPERATION

28: RENAME

29: COMMENT

30: AUDIT

31: NOAUDIT

32: CREATE DATABASE LINK

33: DROP DATABASE LINK

34: CREATE DATABASE

35: ALTER DATABASE

36: CREATE ROLLBACK SEGMENT

37: ALTER ROLLBACK SEGMENT

38: DROP ROLLBACK SEGMENT

39: CREATE TABLESPACE

40: ALTER TABLESPACE

41: DROP TABLESPACE

42: ALTER SESSION

43: ALTER USE

44: COMMIT

45: ROLLBACK

46: SAVEPOINT

47: PL/SQL EXECUTE

48: SET TRANSACTION

49: ALTER SYSTEM SWITCH LOG

50: EXPLAIN

51: CREATE USER

25: CREATE ROLE

53: DROP USER

54: DROP ROLE

55: SET ROLE

56: CREATE SCHEMA

57: CREATE CONTROL FILE

58: ALTER TRACING

59: CREATE TRIGGER

60: ALTER TRIGGER

61: DROP TRIGGER

62: ANALYZE TABLE

63: ANALYZE INDEX

64: ANALYZE CLUSTER

65: CREATE PROFILE

66: DROP PROFILE

67: ALTER PROFILE

68: DROP PROCEDURE

69: DROP PROCEDURE

70: ALTER RESOURCE COST

71: CREATE SNAPSHOT LOG

72: ALTER SNAPSHOT LOG

73: DROP SNAPSHOT LOG

74: CREATE SNAPSHOT

75: ALTER SNAPSHOT

76: DROP SNAPSHOT

79: ALTER ROLE

85: TRUNCATE TABLE

86: TRUNCATE COUSTER

88: ALTER VIEW

91: CREATE FUNCTION

92: ALTER FUNCTION

93: DROP FUNCTION

94: CREATE PACKAGE

95: ALTER PACKAGE

96: DROP PACKAGE

97: CREATE PACKAGE BODY

98: ALTER PACKAGE BODY

99: DROP PACKAGE BODY
*/
SET DOCU ON
