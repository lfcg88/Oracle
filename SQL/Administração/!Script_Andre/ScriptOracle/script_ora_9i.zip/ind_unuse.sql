REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        ind_unuseable.sql
REM 
REM Version:     1.0
REM
REM Description: Shows unuseable indexes and DDL commands to rebuild them
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                        05.07.01
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 48

@@title "Non-Paritioned Invalid Indexes"
COL owner FOR a10
BREAK ON owner
SELECT owner, index_name, index_type, uniqueness, num_rows, last_analyzed, status
FROM dba_indexes
WHERE status <> 'VALID'
AND partitioned = 'NO';
CLEAR BREAKS
COL owner CLEAR

@@title "Syntax to rebuild Non-Paritioned Invalid Indexes"
SELECT 'ALTER INDEX '||owner||'.'||index_name||' rebuild;' AS "Syntax to rebuild"
FROM dba_indexes
WHERE status <> 'VALID'
AND partitioned = 'NO';

@@title "Partitioned Unuseable Indexes"
COL index_owner FOR a10
BREAK ON index_owner ON index_name ON partition_name
SELECT index_owner, index_name, partition_name, NULL AS subpartition_name, num_rows, last_analyzed, status
FROM dba_ind_partitions
WHERE status NOT IN ('USABLE', 'N/A')
UNION
SELECT index_owner, index_name, partition_name, subpartition_name, num_rows, last_analyzed, status
FROM dba_ind_subpartitions
WHERE status <> 'USABLE';
CLEAR BREAKS
COL index_owner CLEAR

@@title "Syntax to rebuild Partitioned Unuseable Indexes"
SELECT 'ALTER INDEX '||index_owner||'.'||index_name||' REBUILD PARTITION '||partition_name||';' AS "Syntax to rebuild"
FROM dba_ind_partitions
WHERE status NOT IN ('USABLE', 'N/A')
UNION
SELECT 'ALTER INDEX '||index_owner||'.'||index_name||' REBUILD SUBPARTITION '||subpartition_name||';' AS "Syntax to rebuild"
FROM dba_ind_subpartitions
WHERE status <> 'USABLE';

@@title "Unusable Function Based Indexes"
COL owner FOR a10
BREAK ON owner
SELECT owner, index_name, index_type, partitioned, uniqueness, num_rows, last_analyzed, status
FROM dba_indexes
WHERE funcidx_status <> 'ENABLED';
CLEAR BREAKS
COL owner CLEAR