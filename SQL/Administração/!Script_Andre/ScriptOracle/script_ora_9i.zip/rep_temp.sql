REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_sort.sql
REM 
REM Version:     1.2
REM
REM Description: Reports TEMP tablespace usage information
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Support for LMTs und temporary tablespaces               USC   17.12.00
REM username added                                           USC   06.06.03
REM v$sort_usage replaced by v$tempseg_usage                 USC   19.01.04
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 160

@@title "Temp Tablespace Usage Report"
SELECT v1.tablespace_name tablespace_name, v3.sum_bytes AS "Size (MB)",
  v1.current_users AS "Active Users", 
  ROUND(v1.used_blocks*v2.bsize/1024/1024,2) AS "Used (MB)", 
  ROUND(v1.free_blocks*v2.bsize/1024/1024,2) AS "Reuseable (MB)",
  v3.sum_bytes-ROUND(v1.free_blocks*v2.bsize/1024/1024,2) AS "Free (MB)",
  round(v1.max_blocks*v2.bsize/1024/1024,2) AS "Highwater usage (MB)"
FROM v$sort_segment v1, (SELECT value bsize
			 FROM v$system_parameter 
                         WHERE name = 'db_block_size') v2,
                        (SELECT tablespace_name, SUM(bytes)/1024/1024 sum_bytes
                         FROM dba_data_files
                         GROUP BY tablespace_name) v3
WHERE v1.tablespace_name = v3.tablespace_name
UNION
-- Oracle8i Syntax to support locally managed temporary tablespaces
SELECT v1.tablespace_name tablespace_name, v3.sum_bytes AS "Size (MB)",
  v1.current_users AS "Active Users",
  ROUND(v1.used_blocks*v2.bsize/1024/1024,2) AS "Used (MB)",
  ROUND(v1.free_blocks*v2.bsize/1024/1024,2) AS "Reuseable (MB)",
  v3.sum_bytes-ROUND(v1.used_blocks*v2.bsize/1024/1024,2) AS "Free (MB)",
  ROUND(v1.max_blocks*v2.bsize/1024/1024,2) AS "Highwater usage (MB)"
FROM v$sort_segment v1, (SELECT value bsize
                         FROM v$system_parameter
                         WHERE name = 'db_block_size') v2,
                        (SELECT tablespace_name, SUM(bytes)/1024/1024 sum_bytes
                         FROM dba_temp_files
                         GROUP BY tablespace_name) v3
WHERE v1.tablespace_name = v3.tablespace_name
ORDER BY tablespace_name desc;

@@title "Sort Usage"
SELECT t1.sid, t1.username, t2.tablespace, t2.extents, round(t2.blocks*t3.value/1024/1024,2) "Used (MB)"
FROM v$session t1, v$tempseg_usage t2, (SELECT value
                                        FROM v$parameter
                                        WHERE name = 'db_block_size') t3
WHERE t1.saddr = t2.session_addr;
