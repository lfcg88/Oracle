REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_stat.sql
REM 
REM Version:     1.1
REM
REM Description: Reports system statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   23.10.01
REM v$system_event added                                     USC   26.02.02
REM -------------------------------------------------------------------------

SET LINESIZE 160

@@title "System Statistics Report"
SELECT name, value 
FROM v$sysstat 
WHERE value <> 0 
ORDER BY value ASC;

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "System Events Report"
SELECT event, total_waits, total_timeouts, time_waited, average_wait 
FROM v$system_event
ORDER BY time_waited ASC;

SET PAUSE OFF
