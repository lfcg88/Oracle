alter session set nls_date_format = 'DD-MM-YY HH24:MI:SS';
