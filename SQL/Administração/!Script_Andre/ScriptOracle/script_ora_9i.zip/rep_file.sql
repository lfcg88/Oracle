REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_file.sql
REM 
REM Version:     1.4
REM
REM Description: Reports datafile balancing and timing statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   01.10.01
REM Selection on tablespace name possible, file size added   USC   21.03.03
REM phyrds and phywrts added                                 USC   02.12.03
REM Temporary tablespace support added                       USC   09.12.03
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 160

ACCEPT isTablespace CHAR PROMPT 'Tablespace Name or Wildcard <%>: ' DEFAULT '%'

@@title "Disk Balancing Report"

SET PAUSE ON PAUSE "Hit <RETURN>..."

COL readtim FOR 999999 HEAD "READTIM|[s]"
COL writetim FOR 999999 HEAD "WRITETIM|[s]"
COL avgiotim FOR 999999 HEAD "AVGIOTIM|[s]"
COL maxiowtm FOR 999999 HEAD "MAXIOWTM|[s]"
COL maxiortm FOR 999999 HEAD "MAXIORTM|[s]"
COL file_name FOR a50
BREAK ON tablespace_name
SELECT /*+ ORDERED */ v1.tablespace_name, v1.file_name, v1.bytes/1024/1024 AS size_mb, 
  v2.phyrds, v2.phywrts, 
  v2.readtim/100 AS readtim, 
  v2.writetim/100 AS writetim, 
  v2.avgiotim/100 AS avgiotim, 
  v2.maxiowtm/100 AS maxiowtm, 
  v2.maxiortm/100 AS maxiortm
FROM dba_data_files v1, v$filestat v2
WHERE v1.file_id = v2.file#
AND v1.tablespace_name LIKE UPPER('&isTablespace')
UNION ALL
SELECT /*+ ORDERED */ v1.tablespace_name, v1.file_name, v1.bytes/1024/1024 AS size_mb, 
  v2.phyrds, v2.phywrts, 
  v2.readtim/100 AS readtim, 
  v2.writetim/100 AS writetim, 
  v2.avgiotim/100 AS avgiotim, 
  v2.maxiowtm/100 AS maxiowtm, 
  v2.maxiortm/100 AS maxiortm
FROM dba_temp_files v1, v$filestat v2
WHERE v1.file_id = v2.file#
AND v1.tablespace_name LIKE UPPER('&isTablespace')
ORDER BY tablespace_name;
CLEAR BREAKS
COL readtim CLEAR
COL writetim CLEAR
COL avgiotim CLEAR 
COL maxiowtm CLEAR
COL maxiortm CLEAR
COL file_name clear

SET PAUSE OFF
