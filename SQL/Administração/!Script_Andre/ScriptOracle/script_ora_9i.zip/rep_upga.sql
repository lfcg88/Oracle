REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_upga.sql
REM 
REM Version:      1.0
REM
REM Requirements: Oracle9iR2
REM
REM Description:  Reports UGA and Manual PGA Memory Management Statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   12.05.03
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 24 NUMWIDTH 16

@@title "PGA Statistics"
SELECT name, value 
FROM v$pgastat;

@@title "UGA PGA System Statistics"
SELECT v1.name, v0.value
FROM v$sysstat v0, v$statname v1
WHERE v0.statistic# = v1.statistic#
AND v1.name IN ('session uga memory', 'session uga memory max', 'session pga memory', 'session pga memory max');

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Top 10 PGA Memory Usage"
COL name FOR a30
SELECT *
FROM (SELECT v0.sid, v1.name, v0.value
      FROM v$sesstat v0, v$statname v1
      WHERE v0.statistic# = v1.statistic#
      AND v1.name = 'session pga memory max'
      ORDER BY v0.value DESC)
WHERE ROWNUM <= 10;
COL name CLEAR

@@title "Top 10 UGA Memory Usage"
COL name FOR a30
SELECT *
FROM (SELECT v0.sid, v1.name, v0.value
      FROM v$sesstat v0, v$statname v1
      WHERE v0.statistic# = v1.statistic#
      AND v1.name = 'session uga memory max'
      ORDER BY v0.value DESC)
WHERE ROWNUM <= 10;
COL name CLEAR

@@title "Top 10 Process PGA Memory Usage (MB)"
COL program FOR a40
SELECT *
FROM (SELECT t2.sid, t2.username, t1.program, TRUNC(t1.pga_used_mem/1024/1024) pga_used_mem, 
        TRUNC(t1.pga_alloc_mem/1024/1024) pga_alloc_mem, 
        TRUNC(t1.pga_max_mem/1024/1024) pga_max_mem
      FROM v$process t1, v$session t2
      WHERE t1.addr = t2.paddr
      ORDER BY t1.pga_used_mem DESC)
WHERE ROWNUM < 10;
COL program CLEAR

SET PAUSE OFF NUMWIDTH 10
