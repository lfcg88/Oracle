REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_segio.sql
REM 
REM Version:      1.2
REM
REM Requirements: Oracle9iR2
REM
REM Description:  Reports Segment Statistics (I/O)
REM               Check init.ora parameter: statistics_level
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   13.09.02
REM Removed v$segstat_name because more statistics are       USC   05.11.03
REM sampled than displayed in this view
REM renamed to rep_segio.sql and dba_tab_modifications added USC   19.11.03
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 24

ACCEPT sOwnerName CHAR PROMPT 'Object Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT sObjectName CHAR PROMPT 'Objectname: ' DEFAULT '-'

@@title "Top 10 Hot IO Segments"
COL owner FOR a15
COL statistic_name FOR a30
BREAK ON owner ON object_name ON subobject_name ON tablespace_name
SELECT *
FROM (SELECT t1.owner, t1.object_name, t1.subobject_name, t1.tablespace_name, t1.statistic_name, t1.value
      FROM v$segment_statistics t1
      WHERE t1.owner NOT IN ('SYS','SYSTEM')
      AND t1.value <> 0
      ORDER BY t1.value DESC)
WHERE ROWNUM <= 10;
COL statistic_name CLEAR
COL owner CLEAR
CLEAR BREAKS

@@title "Top 10 Hot DML Segments"
BREAK ON table_owner ON table_name
SELECT *
FROM (SELECT t1.table_owner, t1.table_name, NVL(t1.partition_name, t1.subpartition_name) AS partition_name, t1.inserts, t1.updates, t1.deletes,
        t1.timestamp, t1.truncated
      FROM sys.dba_tab_modifications t1
      WHERE t1.table_owner NOT IN ('SYS','SYSTEM')
      AND t1.inserts + t1.updates + t1.deletes <> 0
      ORDER BY t1.inserts + t1.updates + t1.deletes DESC)
WHERE ROWNUM <= 10;
CLEAR BREAKS

@@title "Segment IO Statistics"
COL owner FOR a15
COL statistic_name FOR a30
BREAK ON owner ON object_name ON subobject_name ON tablespace_name
SELECT t1.owner, t1.object_name, t1.subobject_name, t1.tablespace_name, t1.statistic_name, t1.value
FROM v$segment_statistics t1
WHERE t1.owner LIKE UPPER('&sOwnerName')
AND t1.object_name = UPPER('&sObjectName')
AND t1.value <> 0
ORDER BY t1.owner, t1.object_name;
COL statistic_name CLEAR
COL owner CLEAR
CLEAR BREAKS

@@title "Segment DML Statistics"
BREAK ON table_owner ON table_name
SELECT t1.table_owner, t1.table_name, NVL(t1.partition_name, t1.subpartition_name) AS partition_name, t1.inserts, t1.updates, t1.deletes, 
  t1.timestamp, t1.truncated
FROM sys.dba_tab_modifications t1
WHERE t1.table_owner LIKE UPPER('&sOwnerName')
AND t1.table_name = UPPER('&sObjectName')
AND t1.inserts + t1.updates + t1.deletes <> 0
ORDER BY t1.table_owner, t1.table_name;
CLEAR BREAKS
