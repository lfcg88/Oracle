REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_pq.sql
REM 
REM Version:     1.2, Oracle 9i
REM
REM Description: Reports Parallel Query Statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Query Coordinator Stats added and PQ Server SQL 
REM commented out                                            USC   28.11.00
REM Selection support for QC SID added and output reformated USC   21.06.01
REM v$sqlarea replaced by v$sql for performance reasons      USC   04.06.03
REM Using v$sqlarea again to avoid lots of duplicates        USC   18.11.03
REM Added username in "Parallel Query Server Set Report"     USC   12.12.03
REM -------------------------------------------------------------------------

REM
REM select sid from v$session where audsid = userenv('sessionid');
REM

SET LINESIZE 140 PAGESIZE 80

ACCEPT sSid CHAR PROMPT 'Query Coordinator Session ID or Wildcard <%>: ' DEFAULT '%'

@@title "Parallel Query System Statistics"
SELECT *
FROM v$px_process_sysstat;

@@title "Parallel Query Server Set Report"
BREAK ON qcsid ON username
SELECT v0.qcsid, v1.username, v0.server_group, v0.server_set, v0.degree, v0.req_degree
FROM (SELECT DISTINCT qcsid, server_group, server_set, degree, req_degree 
      FROM v$px_session
      WHERE server_group IS NOT NULL
      AND qcsid LIKE '&sSid') v0, v$session v1
WHERE v0.qcsid = v1.sid;
CLEAR BREAKS

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Parallel Query Coordinator SQL Report"
COL sql_text FOR a80
BREAK ON sid
SELECT v2.sid, v3.sql_text, v3.rows_processed, v3.disk_reads, v1.pqs_alloc
FROM (SELECT qcsid, count(*) - 1 pqs_alloc
      FROM v$px_session
      GROUP BY qcsid) v1, v$session v2, v$sqlarea v3
WHERE v2.sid LIKE '&sSid'
AND v2.sid = v1.qcsid
AND v2.sql_address = v3.address
AND v2.sql_hash_value = v3.hash_value;
CLEAR BREAKS
COL sql_text CLEAR

SET DOCU OFF
/*
@@title "Parallel Query Server SQL Report"
COL sql_text FOR a60
SELECT v4.qcsid, v1.sid, v1.server_name, v3.sql_text, v3.rows_processed, v3.disk_reads
FROM v$px_session v4, v$sqlarea v3, v$session v2, v$px_process v1
WHERE v1.sid = DECODE(TO_NUMBER('&sSid'), -1, v1.sid, TO_NUMBER('&sSid'))
AND v1.sid = v2.sid
AND v2.sql_address = v3.address
AND v2.sql_hash_value = v3.hash_value
AND v1.sid = v4.sid
AND v1.serial# = v4.serial#
ORDER BY v4.qcsid, v1.server_name;
COL sql_text CLEAR
*/
SET DOCU ON

@@title "Parallel Query Coordinator Statistics"
COL name FOR a40
BREAK ON sid
SELECT v1.sid, v2.name, v1.value
FROM v$sesstat v1, v$statname v2
WHERE v1.sid IN (SELECT DISTINCT qcsid
                 FROM v$px_session
                 WHERE qcsid LIKE '&sSid')
AND v1.statistic# = v2.statistic#
AND v2.class IN (2, 8, 32, 64)
AND (v2.name LIKE 'table%' OR
     v2.name LIKE 'index%' OR
     v2.name LIKE 'sorts%' OR
     v2.name LIKE 'parallel%' OR
     v2.name LIKE 'DML%' OR
     v2.name LIKE 'DDL%' OR
     v2.name LIKE 'consistent%' OR
     v2.name LIKE 'db block%' OR
     v2.name LIKE 'redo%')
ORDER BY v1.sid, v2.class, v2.name;
CLEAR BREAKS
COL name CLEAR

@@title "Parallel Query Server Statistics"
COL name FOR a40
BREAK ON qcsid ON sid ON server_name
SELECT v1.qcsid, v1.sid, v0.server_name, v2.name, v1.value
FROM v$px_process v0, v$px_sesstat v1, v$statname v2
WHERE v1.qcsid LIKE '&sSid'
AND v1.sid = v0.sid
AND v1.statistic# = v2.statistic#
AND v2.class IN (8, 32, 64)
AND (v2.name = 'table scan rows gotten' OR
     v2.name like 'sorts%' OR
     v2.name like 'consistent%' OR
     v2.name like 'db block%')
AND v1.value <> 0
ORDER BY v1.qcsid, v1.server_group, v1.server_set, v1.sid, v0.server_name, v2.class, v2.name;
COL name CLEAR
CLEAR BREAKS

SET PAUSE OFF PAGESIZE 24
