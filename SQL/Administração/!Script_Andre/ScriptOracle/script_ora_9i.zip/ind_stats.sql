REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        ind_stats.sql
REM 
REM Version:     1.0
REM
REM Description: Computes index stats and stores them in a history table
REM              for reporting
REM              ATTENTION: Table Locks are produced because of
REM                         ANALYZE INDEX ... VALIDATE STRUCTURE
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM -------------------------------------------------------------------------

DECLARE
  nExists number;
BEGIN
  SELECT 1 
  INTO nExists
  FROM user_tables
  WHERE table_name = 'HIST_INDEX_STATS';
EXCEPTION
  WHEN NO_DATA_FOUND THEN
    dbms_utility.exec_ddl_statement(
      'CREATE TABLE hist_index_stats 
       AS
       SELECT sysdate stats_date, t2.owner, t2.bytes, t2.extents, t1.*
       FROM dba_segments t2, index_stats t1
       WHERE t1.name = t2.segment_name
       AND 1=2');
END;
/

DECLARE
  CURSOR cInd IS
    SELECT owner, index_name, partitioned
    FROM dba_indexes
    WHERE owner NOT IN ('SYS', 'SYSTEM')
    AND table_owner = owner;
    
  CURSOR cIndPart(sOwner dba_ind_partitions.index_owner%TYPE, 
                  sIndex dba_ind_partitions.index_name%TYPE) IS
    SELECT partition_name
    FROM dba_ind_partitions
    WHERE index_owner = sOwner
    AND index_name = sIndex;

BEGIN
  FOR cRecInd IN cInd LOOP
    IF cRecInd.partitioned = 'YES' THEN
      FOR cRecIndPart IN cIndPart(cRecInd.owner, cRecInd.index_name) LOOP
        dbms_utility.exec_ddl_statement(
          'ANALYZE INDEX '||cRecInd.owner||'.'||cRecInd.index_name||
          ' PARTITION ('||cRecIndPart.partition_name||')'||' VALIDATE STRUCTURE');      
        INSERT INTO hist_index_stats
        SELECT sysdate, t2.owner, t2.bytes, t2.extents, t1.*
        FROM dba_segments t2, index_stats t1
        WHERE t2.owner = cRecInd.owner
        AND t2.segment_name = cRecInd.index_name
        AND t2.partition_name = cRecIndPart.partition_name
        AND t1.name = cRecInd.index_name
        AND t1.partition_name = cRecIndPart.partition_name;
        COMMIT;
      END LOOP;
    ELSE
      dbms_utility.exec_ddl_statement(
        'ANALYZE INDEX '||cRecInd.owner||'.'||cRecInd.index_name||' VALIDATE STRUCTURE');
      INSERT INTO hist_index_stats
      SELECT sysdate, t2.owner, t2.bytes, t2.extents, t1.*
      FROM dba_segments t2, index_stats t1
      WHERE t2.owner = cRecInd.owner
      AND t2.segment_name = cRecInd.index_name
      AND t1.name = cRecInd.index_name
      AND t2.owner = cRecInd.owner;
      COMMIT;
    END IF;
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    dbms_output.put_line(SUBSTR(SQLERRM, 1, 250));
    ROLLBACK;
END;
/
