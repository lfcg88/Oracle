REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        ind_rep.sql
REM 
REM Version:     1.1
REM
REM Description: Shows index details
REM              
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   06.12.00
REM c.descend added                                          USC   12.01.04
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 80

ACCEPT isIndexOwner CHAR PROMPT 'Index Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT isIndexName CHAR PROMPT 'Index Name: ' DEFAULT '-'

@@title "Index Desc Report"
COL owner FOR a12
COL column_name FOR a32
BREAK ON owner ON index_name ON table_name ON index_type ON uniqueness
SELECT i.owner owner, i.index_name index_name, i.table_name, i.index_type index_type, i.uniqueness uniqueness, c.column_name, c.descend
FROM dba_ind_columns c, dba_indexes i
WHERE i.owner LIKE UPPER('&isIndexOwner')
AND i.index_name = UPPER('&isIndexName')
AND i.owner = c.index_owner
AND i.index_name = c.index_name
ORDER BY 1,2,c.column_position ASC;
CLEAR BREAKS
COL owner CLEAR
COL column_name CLEAR

@@title "Index Report"
COL owner FOR a12
COL column_name FOR a32
COL buffer_pool HEAD "BUFFER|POOL" JUS L
COL partitioned HEAD "PARTI-|TIONED" FOR a6 JUS L
COL created FOR a20
COL last_ddl_time FOR a20
COL degree FOR a6
COL compression FOR a8 HEAD "COMPR-|ESSION"
COL logging FOR a7 HEAD "LOGGING"
SELECT i.owner owner, i.index_name index_name, i.degree, i.compression, i.logging, i.buffer_pool, i.partitioned, 
  i.status status, t2.created, t2.last_ddl_time
FROM dba_objects t2, dba_indexes i
WHERE i.owner LIKE UPPER('&isIndexOwner')
AND i.index_name = UPPER('&isIndexName')
AND i.owner = t2.owner
AND i.index_name = t2.object_name
AND t2.object_type = 'INDEX';
COL owner CLEAR
COL buffer_pool CLEAR
COL column_name CLEAR
COL partitioned CLEAR
COL created CLEAR
COL last_ddl_time CLEAR
COL degree CLEAR
COL compression CLEAR
COL logging CLEAR

@@title "Index Storage Report"
COL pct_free HEAD "PCT|FREE" FOR 999 JUS L
COL pct_used HEAD "PCT|USED" FOR 999 JUS L 
COL ini_trans HEAD "INI|TRANS" FOR 999 JUS L
COL max_trans HEAD "MAX|TRANS" FOR 999 JUS L
COL initial_extent FOR 9999.00 HEAD "INTIAL|(MB)"
COL next_extent FOR 9999.00 HEAD "NEXT|(MB)"
COL min_extents HEAD "MIN|EXTENTS" FOR 9999999 JUS L
COL max_extents HEAD "MAX|EXTENTS" JUS L
COL pct_increase HEAD "PCT|INCR" FOR 999 JUS L
COL freelists HEAD "FREE|LISTS" FOR 999 JUS L
COL freelist_groups HEAD "FREELIST|GROUPS" FOR 999 JUS L
COL extents HEAD "EX-|TENTS" FOR 999 JUS L 
COL bytes_mb HEAD "SPACE|USAGE(MB)" FOR 999999.00 JUS L
SELECT t1.tablespace_name, t1.initial_extent/1024/1024 initial_extent, t1.next_extent/1024/1024 next_extent,
  t2.extents, t2.bytes_mb,
  t1.min_extents, t1.max_extents, t1.pct_increase, t1.freelists, t1.freelist_groups,
  t1.pct_free, t1.ini_trans, t1.max_trans
FROM dba_indexes t1, (SELECT SUM(extents) extents, SUM(bytes/1024/1024) bytes_mb
                      FROM dba_segments
                      WHERE owner LIKE UPPER('&isIndexOwner')
                      AND segment_name = UPPER('&isIndexName')) t2
WHERE t1.owner LIKE UPPER('&isIndexOwner')
AND t1.index_name = UPPER('&isIndexName');
COL pct_free CLEAR
COL pct_used CLEAR
COL ini_trans CLEAR
COL max_trans CLEAR
COL initial_extent CLEAR
COL next_extent CLEAR
COL min_extents CLEAR
COL max_extents CLEAR
COL pct_increase CLEAR
COL freelists CLEAR
COL freelist_groups CLEAR
COL bytes_mb CLEAR
COL extents CLEAR

@@title "Index Statistics Report"
COL owner FOR a12
COL global_stats FOR a7 HEAD "GLOBAL-|STATS"
COL user_stats FOR a5 HEAD "USER-|STATS"
COL last_analyzed FOR a20
SELECT t1.owner owner, t1.index_name, t1.last_analyzed, t1.distinct_keys, t1.num_rows ,t1.sample_size, 
  t1.global_stats, t1.user_stats
FROM dba_indexes t1
WHERE t1.owner LIKE UPPER('&isIndexOwner')
AND t1.index_name = UPPER('&isIndexName');
COL owner CLEAR
COL global_stats CLEAR
COL user_stats CLEAR
COL last_analyzed CLEAR

SET PAUSE OFF PAGESIZE 24
