REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_rbs.sql
REM 
REM Version:     1.1
REM
REM Description: Shows rollback segment usage by users
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Added additional infos from v$transaction                USC   25.01.01
REM -------------------------------------------------------------------------

SET LINESIZE 140

SET ECHO OFF

@@title "Rollback-Segments In Use Report"
SELECT v3.username, v3.sid, v2.name AS RS_NAME, v4.aveactive AS avg_size, v1.start_time, v1.used_urec, v1.used_ublk
FROM v$rollname v2, v$session v3, v$transaction v1, v$rollstat v4
WHERE v1.xidusn = v2.usn
AND v1.addr = v3.taddr
AND v2.usn = v4.usn;



