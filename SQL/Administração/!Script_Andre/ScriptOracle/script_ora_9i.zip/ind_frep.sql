REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        indf_rep.sql
REM 
REM Version:     1.1
REM
REM Description: Shows function based index details
REM              
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   19.09.01
REM c.descend added                                          USC   12.01.04
REM -------------------------------------------------------------------------
SET LINESIZE 160 PAGESIZE 80

ACCEPT isIndexOwner CHAR PROMPT 'Index Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT isIndexName CHAR PROMPT 'Index Name: ' DEFAULT '-'

@@title "Function Based Index Desc Report"
COL owner FOR a12
COL column_name FOR a32
COL column_expression FOR a50
BREAK ON owner ON index_name ON index_type
SELECT i.owner owner, i.index_name index_name, i.index_type index_type, c.column_name, c.descend,
 e.column_expression
FROM dba_ind_columns c, dba_ind_expressions e, dba_indexes i
WHERE i.owner LIKE UPPER('&isIndexOwner')
AND i.index_name = UPPER('&isIndexName')
AND i.owner = c.index_owner
AND i.index_name = c.index_name
AND c.index_owner = e.index_owner
AND c.index_name = e.index_name
AND c.column_position = e.column_position
ORDER BY 1,2,c.column_position ASC;
CLEAR BREAKS
COL owner CLEAR
COL column_name CLEAR
COL column_expression CLEAR

SET PAGESIZE 24
