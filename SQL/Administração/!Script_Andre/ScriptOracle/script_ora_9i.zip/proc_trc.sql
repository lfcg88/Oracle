REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         proc_trc.sql
REM 
REM Version:      1.5
REM
REM Requirements: Oracle9i
REM
REM Description:  Shows statistics and trace information about a given
REM               DB process
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Switch von v$sqlarea to v$sql (performance)              USC   13.06.03
REM Change elapsed_time/1000 to elapsed_time/1000000         USC   09.07.03
REM Added "Session Memory Usage Info"                        USC   13.11.03
REM Adjusted where clause DECODE(v0.sql_address,'00'         USC   16.11.03
REM Using v$sqlarea again to avoid lots of duplicates        USC   18.11.03
REM v$sort_usage replaced by v$tempseg_usage                 USC   19.01.04
REM -------------------------------------------------------------------------

SET LINESIZE 160

ACCEPT sPid CHAR PROMPT 'Process ID: ' DEFAULT '-1'

@@title "Process Info"
COL username FOR a20
COL sid_serial FOR a10
COL osuser FOR a15
COL terminal FOR a15
COL program FOR a30
COL pdml_status FOR a8 HEAD "PDML"
COL pddl_status FOR a8 HEAD "PDDL"
SELECT t1.username, t1.sid||','||t1.serial# AS sid_serial, t2.spid, t1.osuser, t1.program, t1.terminal, t1.server, t1.status, 
  t1.pdml_status, t1.pddl_status, TO_CHAR(t1.logon_time, 'DD-MM-YY HH24:MI') AS logged_on
FROM v$session t1, v$process t2
WHERE t2.spid = to_number('&sPid')
AND t1.paddr = t2.addr (+);
COL username CLEAR
COL sid_serial CLEAR
COL program CLEAR
COL osuser CLEAR
COL terminal CLEAR
COL pdml_status CLEAR
COL pddl_status CLEAR

@@title "Session Lock Wait Info"
COL object_name FOR a30
SELECT t1.sid, t3.object_name, t2.type
FROM dba_objects t3, v$lock t2, v$session t1
WHERE t1.paddr IN (SELECT addr
                   FROM v$process
                   WHERE spid = TO_NUMBER('&sPid'))
AND t1.lockwait IS NOT NULL
AND t1.lockwait = t2.kaddr
AND t2.id1 = t3.object_id;

@@title "Session Wait Info"
COL event FOR a30
COL p1text FOR a10
COL p2text FOR a10
COL p3text FOR a10
COL sec_wait FOR 99999990 HEAD "SECONDS|IN WAIT"
SELECT t1.sid, t2.event event, t2.wait_time, t2.seconds_in_wait sec_wait, t2.state, 
  t2.p1text p1text, t2.p1, t2.p2text p2text, t2.p2, t2.p3text p3text, t2.p3
FROM v$session_wait t2, v$session t1
WHERE t1.paddr IN (SELECT addr
                   FROM v$process
                   WHERE spid = TO_NUMBER('&sPid'))
AND t1.sid = t2.sid (+);
COL event CLEAR
COL p1text CLEAR
COL p2text CLEAR
COL p3text CLEAR
COL sec_wait CLEAR

@@title "Session IO Info"
SELECT t1.sid, t2.block_gets, t2.consistent_gets, t2.physical_reads, t2.block_changes, 
  t2.consistent_changes
FROM v$sess_io t2, v$session t1
WHERE t1.paddr IN (SELECT addr
                   FROM v$process
                   WHERE spid = TO_NUMBER('&sPid'))
AND t1.sid = t2.sid (+);

@@title "Session Sort Usage Info"
SELECT t1.sid, t2.tablespace, t2.extents, round(t2.blocks*t3.value/1024/1024,2) "Used (MB)"
FROM v$session t1, v$v$tempseg_usage t2, (SELECT value
                                          FROM v$parameter
                                          WHERE name = 'db_block_size') t3
WHERE t1.paddr IN (SELECT addr
                   FROM v$process
                   WHERE spid = TO_NUMBER('&sPid'))
AND t1.saddr = t2.session_addr;

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Session Memory Usage Info"
SELECT v0.sid, 
  TRUNC(v1.value/1024/1024) AS max_pga_mb, 
  TRUNC(v3.value/1024/1024) AS max_uga_mb,
  TRUNC(v5.pga_used_mem/1024/1024) pga_used_mem_mb, 
  TRUNC(v5.pga_alloc_mem/1024/1024) pga_alloc_mem_mb, 
  TRUNC(v5.pga_max_mem/1024/1024) pga_max_mem_mb
FROM v$session v0, v$sesstat v1, v$statname v2, v$sesstat v3, v$statname v4, v$process v5
WHERE v0.paddr IN (SELECT addr
                   FROM v$process
                   WHERE spid = TO_NUMBER('&sPid'))
AND v0.sid = v1.sid
AND v1.statistic# = v2.statistic#
AND v2.name = 'session pga memory max'
AND v0.sid = v3.sid
AND v3.statistic# = v4.statistic#
AND v4.name = 'session uga memory max'
AND v0.paddr = v5.addr;

@@title "Session Optimal PGA Usage Statistics"
SELECT t2.sid, t1.name, t2.value
FROM v$statname t1, v$sesstat t2, v$session t3
WHERE t1.name LIKE 'workarea exec%'
AND t1.statistic# = t2.statistic#
AND t3.sid = t2.sid
AND t3.paddr IN (SELECT addr
                 FROM v$process
                 WHERE spid = TO_NUMBER('&sPid'))
ORDER BY t2.sid;

@@title "Session Workarea Statistics"
SELECT TO_NUMBER(DECODE(t1.sid, 65535, NULL, t1.sid)) AS sid,
  t1.operation_type operation,
  TRUNC(t1.work_area_size/1024) AS wsize_kb, 
  TRUNC(t1.expected_size/1024) AS esize_kb,
  TRUNC(t1.actual_mem_used/1024) AS act_mem_kb, 
  TRUNC(t1.max_mem_used/1024) AS max_mem_kb, 
  t1.number_passes AS pass
FROM v$sql_workarea_active t1, v$session t2
WHERE t2.paddr IN (SELECT addr
                   FROM v$process
                   WHERE spid = TO_NUMBER('&sPid'))
AND t2.sid = t1.sid
ORDER BY 1,2;

@@title "Session Statistics Info"
SELECT t1.sid, t3.name, t2.value
FROM v$statname t3, v$sesstat t2, v$session t1
WHERE t1.paddr IN (SELECT addr
                   FROM v$process
                   WHERE spid = TO_NUMBER('&sPid'))
AND t1.sid = t2.sid
AND t2.statistic# = t3.statistic#
AND t3.class IN (2, 8, 32, 64)
AND (t3.name LIKE 'table%' OR
     t3.name LIKE 'index%' OR
     t3.name LIKE 'sorts%' OR
     t3.name LIKE 'parallel%' OR
     t3.name LIKE 'DML%' OR
     t3.name LIKE 'DDL%' OR
     t3.name LIKE 'consistent%' OR
     t3.name LIKE 'db block%' OR
     t3.name LIKE 'redo%')
AND t2.value <> 0
ORDER BY t1.sid, t3.name;

@@title "Session Events Info"
SELECT t2.*
FROM v$session_event t2, v$session t1
WHERE t1.paddr IN (select addr
                   from v$process
                   where spid = TO_NUMBER('&sPid'))
AND t1.sid = t2.sid
ORDER BY t2.total_waits ASC;

@@title "Object Access Info"
COL object FOR a40
SELECT t1.sid, t2.object, t2.type
FROM v$access t2, v$session t1
WHERE t1.paddr IN (SELECT addr
                   FROM v$process
                   WHERE spid = TO_NUMBER('&sPid'))
AND t1.sid = t2.sid
AND t2.type IN ('TABLE', 'PROCEDURE', 'PACKAGE', 'VIEW')
AND t2.owner NOT IN ('SYS', 'SYSTEM');
COL object CLEAR

@@title "SQL Statement Info"
COL sql_text FOR a60
COL name FOR a20
SELECT t1.sid, t2.sql_text sql_text, t2.first_load_time, t2.rows_processed, 
  TRUNC(t2.elapsed_time/1000000/DECODE(t2.executions,0,1)) AS elapsed_sec, t3.used_ublk, t3.used_urec, t4.name AS name
FROM v$rollname t4, v$transaction t3, v$sqlarea t2, v$session t1
WHERE t1.paddr IN (SELECT addr
                   FROM v$process
                   WHERE spid = TO_NUMBER('&sPid'))
AND DECODE(t1.sql_hash_value,0,t1.prev_hash_value,t1.sql_hash_value) = t2.hash_value (+)
AND DECODE(t1.sql_address,'00',t1.prev_sql_addr,t1.sql_address) = t2.address (+)
AND t1.taddr = t3.addr (+)
AND t3.xidusn = t4.usn (+);
COL sql_text CLEAR
COL name CLEAR

@@title "Open Cursors Info"
COL sql_text FOR a60
COL name FOR a20
SELECT t1.sid, t2.sql_text sql_text, t3.start_time, t3.used_ublk, t3.used_urec, t3.log_io, t3.phy_io, t4.name name
FROM v$rollname t4, v$transaction t3, v$open_cursor t2, v$session t1
WHERE t1.paddr IN (SELECT addr
                   FROM v$process
                   WHERE spid = TO_NUMBER('&sPid'))
AND DECODE(t1.sql_hash_value,0,t1.prev_hash_value,t1.sql_hash_value) = t2.hash_value (+)
AND DECODE(t1.sql_address,'00',t1.prev_sql_addr,t1.sql_address) = t2.address (+)
AND t1.taddr = t3.addr (+)
AND t3.xidusn = t4.usn (+);
COL sql_text CLEAR
COL name CLEAR

SET PAUSE OFF









