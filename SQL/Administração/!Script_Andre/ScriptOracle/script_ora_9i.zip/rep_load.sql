REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_load.sql
REM 
REM Version:     1.2
REM
REM Description: Reports with several I/O, memory and CPU statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Used SGA memory statistics added                         USC   15.10.02
REM Outer join in "Largest Disk Read Statements Report"      
REM and TOP10 in "Largest User IOs" and "Largest Sort Usage" 
REM removed "Largest Physical Reads" and other optimizations USC   17.11.03
REM v$sort_usage replaced by v$tempseg_usage                 USC   19.01.04
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 140

@@title "Parallel Query Server Statistics Report"
SELECT *
FROM v$pq_sysstat
WHERE statistic LIKE 'Server%';

@@title "System IO"
SELECT cg.value+bg.value "Buffer Reads", pr.value "Disk Reads", bc.value+cc.value "Buffer Writes", pw.value "Disk Writes"
FROM v$sysstat cg, v$sysstat bg, v$sysstat pr, v$sysstat pw, v$sysstat bc, v$sysstat cc
WHERE cg.name = 'consistent gets'
AND bg.name = 'db block gets'
AND pr.name = 'physical reads'
AND pw.name = 'physical writes'
AND bc.name = 'db block changes'
AND cc.name = 'consistent changes';

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Largest CPU Usage Report"
SELECT *
FROM (SELECT v1.sid, v1.value AS "CPU"
      FROM v$sesstat v1, v$statname v2
      WHERE v2.name = 'CPU used by this session'
      AND v2.statistic# = v1.statistic#
      ORDER BY v1.value DESC)
WHERE ROWNUM < 11;

@@title "Largest Disk Read Statements Report"
COL sql_text FOR a80
SELECT *
FROM (SELECT v2.sid, v1.sql_text sql_text, v1.disk_reads, v1.executions, v1.rows_processed
      FROM v$sqlarea v1, v$session v2
      WHERE DECODE(v2.sql_address (+),'00',v2.prev_sql_addr(+),v2.sql_address(+)) = v1.address
      AND DECODE(v2.sql_hash_value(+),0,v2.prev_hash_value(+),v2.sql_hash_value(+)) = v1.hash_value
      ORDER BY v1.disk_reads DESC)
WHERE ROWNUM < 11;
COL sql_text CLEAR

@@title "Largest Undo Report"
COL sql_text FOR a50
COL name FOR a30
SELECT *
FROM (SELECT t1.sid, t3.used_ublk, t3.used_urec, t3.log_io, t3.phy_io, t4.name name
      FROM v$rollname t4, v$transaction t3,  v$session t1
      WHERE t1.taddr IS NOT NULL
      AND t1.taddr = t3.addr
      AND t3.xidusn = t4.usn (+)
      ORDER BY t3.phy_io DESC)
WHERE ROWNUM < 11;
COL sql_text CLEAR
COL name CLEAR

@@title "Largest User IOs"
SELECT sid, block_gets, consistent_gets, physical_reads, block_changes, consistent_changes
FROM (SELECT v2.*, v2.block_gets+v2.consistent_gets+v2.block_changes+v2.consistent_changes+v2.physical_reads AS sum_io
      FROM v$session v1, v$sess_io v2
      WHERE v1.status = 'ACTIVE'
      AND v1.sid = v2.sid
      AND v1.username IS NOT NULL
      ORDER BY v2.block_gets+v2.consistent_gets+v2.block_changes+v2.consistent_changes+v2.physical_reads DESC)
WHERE ROWNUM < 11;

@@title "Largest Sort Usage"
SELECT *
FROM (SELECT t1.sid, t2.tablespace, t2.extents, ROUND(t2.blocks*t3.value/1024/1024,2) AS used_mb
      FROM v$session t1, v$tempseg_usage t2, (SELECT value
                                              FROM v$parameter
                                              WHERE name = 'db_block_size') t3
      WHERE t1.saddr = t2.session_addr
      ORDER BY ROUND(t2.blocks*t3.value/1024/1024,2) DESC)
WHERE ROWNUM < 11;

@@title "Used SGA memory"
COL used_sga_mem FOR 9999999.99
SELECT 'plsql sharable memory' AS name, SUM(sharable_mem)/1024/1024 AS used_sga_mem
FROM v$db_object_cache
UNION
SELECT 'sqlarea sharable memory' AS name, SUM(sharable_mem)/1024/1024 AS used_sga_mem
FROM v$sqlarea
UNION
SELECT /*+ ORDERED */ t2.name, SUM(t1.value)/1024/1024 AS used_sga_mem
FROM v$statname t2, v$sesstat t1
WHERE t2.name = 'session uga memory'
AND t2.statistic# = t1.statistic#
GROUP BY t2.name;
COL used_sga_mem CLEAR

@@title "Used SGA memory sqlarea"
COL used_sga_mem FOR 9999999.99
SELECT *
FROM (SELECT t2.sid, t1.sharable_mem/1024/1024 AS used_sga_mem
      FROM v$sqlarea t1, v$session t2
      WHERE t1.hash_value = t2.sql_hash_value 
      AND t1.address = t2.sql_address
      ORDER BY sharable_mem DESC)
WHERE ROWNUM < 11;
COL used_sga_mem CLEAR

@@title "Used SGA memory UGA"
COL used_sga_mem FOR 9999999.99
SELECT *
FROM (SELECT t1.sid, t1.value/1024/1024 AS used_sga_mem
      FROM v$statname t2, v$sesstat t1
      WHERE t2.name = 'session uga memory'
      AND t2.statistic# = t1.statistic#
      ORDER BY t1.value DESC)
WHERE ROWNUM < 11;
COL used_sga_mem CLEAR

@@title "Used SGA memory PGA"
COL used_pga_mem FOR 9999999.99
SELECT *
FROM (SELECT t1.sid, t1.value/1024/1024 AS used_pga_mem
      FROM v$statname t2, v$sesstat t1
      WHERE t2.name = 'session pga memory'
      AND t2.statistic# = t1.statistic#
      ORDER BY t1.value DESC)
WHERE ROWNUM < 11;
COL used_pga_mem CLEAR

SET PAGESIZE 24 PAUSE OFF
