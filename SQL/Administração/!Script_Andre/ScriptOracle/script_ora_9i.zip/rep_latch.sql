REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_latch.sql
REM 
REM Version:     1.2
REM
REM Description: Reports latch statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Moved "Buffer Pool LRU Latch Contention Report" to       USC   06.11.03
REM rep_sga.sql
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 160

@@title "Latch Contention Report"
REM Hit Ratio should higher than 99 
REM redo copy latches are determined by LOG_SIMULTANEOUS_COPIES
COL name FOR a40
COL wait_hit HEAD "Wait|Hit Ratio"
COL no_wait_hit HEAD "No Wait|Hit Ratio"
SELECT l.name, l.gets, l.misses, ROUND((1-(l.misses/DECODE(l.gets,0,1,l.gets)))*100,2) AS wait_hit, 
  l.immediate_gets, l.immediate_misses, 
  ROUND((1-(l.immediate_misses/DECODE(l.immediate_gets,0,1,l.immediate_gets)))*100,2) AS no_wait_hit,
  wait_time
FROM v$latch l
WHERE ROUND((1-(l.misses/DECODE(l.gets,0,1,l.gets)))*100,2) < 100
OR ROUND((1-(l.immediate_misses/DECODE(l.immediate_gets,0,1,l.immediate_gets)))*100,2) < 100
ORDER BY l.name;
COL name CLEAR
COL wait_hit CLEAR
COL no_wait_hit CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Latch Children Overview"
SELECT name, count(*)
FROM v$latch_children
GROUP BY name
ORDER BY name;

@@title "Latch Holder Overview"
SELECT v1.name, v2.spid, v3.username, v3.sid, v3.serial#
FROM v$latchholder v1, v$process v2, v$session v3
WHERE v1.pid = v2.pid
AND v2.addr = v3.paddr;

@@title "Enqueue Statistics"
SELECT * FROM v$enqueue_stat;

SET PAGESIZE 24
