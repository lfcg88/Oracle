REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        top_privs.sql
REM 
REM Version:     2.0
REM
REM Description: Reports users with high privileges
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Introduction of direct grants and indirect through roles USC   08.07.03
REM -------------------------------------------------------------------------

SET LINESIZE 120

@@title "DBA, IMP_FULL, EXP_FULL Privileged User Report"
SELECT granted_role, grantee
FROM dba_role_privs
WHERE granted_role IN ('DBA','IMP_FULL_DATABASE', 'EXP_FULL_DATABASE')
AND EXISTS (SELECT 1
            FROM dba_users
            WHERE dba_users.username = dba_role_privs.grantee)
ORDER BY 1,2; 

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Direct Granted High System Privileges Report"
SELECT t1.username, t2.privilege AS direct_grant
FROM dba_users t1, dba_sys_privs t2
WHERE t1.username = t2.grantee
AND t1.username NOT IN ('SYS', 'SYSTEM')
AND (t2.privilege IN ('RESTRICTED SESSION')
     OR (t2.privilege LIKE 'ALTER%' AND t2.privilege <> 'ALTER SESSION')
     OR t2.privilege LIKE 'DROP%'
     -- OR privilege LIKE 'UNLIMITED%'
     OR (t2.privilege LIKE '%ANY%' AND t2.privilege NOT LIKE 'CREATE ANY%'))
ORDER BY 1,2;

@@title "By Roles Granted High System Privileges Report"
SELECT DISTINCT t1.username, t2.granted_role
FROM dba_users t1, dba_role_privs t2, dba_sys_privs t3
WHERE t1.username NOT IN ('SYS', 'SYSTEM')
AND t1.username = t2.grantee
AND t2.granted_role = t3.grantee
AND (t3.privilege IN ('RESTRICTED SESSION')
     OR (t3.privilege LIKE 'ALTER%' AND t3.privilege <> 'ALTER SESSION')
     OR t3.privilege LIKE 'DROP%'
     -- OR privilege LIKE 'UNLIMITED%'
     OR (t3.privilege LIKE '%ANY%' AND t3.privilege NOT LIKE 'CREATE ANY%'))
ORDER BY 1,2;

SET PAUSE OFF
