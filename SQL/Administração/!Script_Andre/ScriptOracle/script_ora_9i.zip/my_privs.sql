REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        my_privs.sql
REM 
REM Version:     1.1
REM
REM Description: Shows roles and privileges granted to current user
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   17.10.01
REM -------------------------------------------------------------------------

SET LINESIZE 160

ACCEPT isTableName CHAR PROMPT 'Table Name or Wildcard <%>: ' DEFAULT '%'

@@title "Role Report"
SELECT username, granted_role, admin_option
FROM user_role_privs
ORDER BY username, granted_role;

@@title "System Privilege Report"
SELECT username, privilege, admin_option
FROM user_sys_privs
ORDER BY username, privilege;

@@title "Quota Report"
SELECT tablespace_name, bytes/1024/1024 "Used", max_bytes/1024/1024 "Max"
FROM user_ts_quotas
ORDER BY tablespace_name;

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Object Privilege Report"
COL privilege FOR a10
SELECT grantee, owner||'.'||table_name "Object", privilege, grantor
FROM user_tab_privs
WHERE table_name LIKE UPPER('&isTableName')
ORDER BY grantee, owner||'.'||table_name;
COL privilege CLEAR

SET PAUSE OFF
