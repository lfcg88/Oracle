REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         get_ddl.sql
REM
REM Version:      1.1
REM
REM Requirements: Oracle9i
REM
REM Description:  Extract DDL Syntax of DB objects
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   05.03.02
REM Where clause object_type NOT IN added, SET LONG 1000000  USC   24.11.03
REM Subpartitioned Objects cause an error ?!                 USC   25.11.03
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 0 LONG 1000000

ACCEPT isObjectOwner CHAR PROMPT 'Object Owner or Wildcard <%>: ' DEFAULT '%'
ACCEPT isObjectName CHAR PROMPT 'Object Name <%>: ' DEFAULT '%'

EXECUTE dbms_metadata.set_transform_param(dbms_metadata.session_transform,'SQLTERMINATOR',TRUE);

@@title "Object DDL Report"
COL ddl_text FOR a160
SELECT dbms_metadata.get_ddl(object_type, object_name, owner) AS ddl_text
FROM dba_objects
WHERE owner LIKE UPPER('&isObjectOwner')
AND object_name LIKE UPPER('&isObjectName')
AND object_type NOT IN ('PACKAGE BODY', 'TABLE PARTITION', 'TABLE SUBPARTITION', 'INDEX PARTITION', 'INDEX SUBPARTITION')
ORDER BY owner, object_name, object_type;
COL ddl_text CLEAR

EXECUTE dbms_metadata.set_transform_param(dbms_metadata.session_transform,'DEFAULT');

