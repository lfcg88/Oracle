REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         user_sql.sql
REM 
REM Version:      1.1
REM
REM Requirements: Oracle9i
REM
REM Description:  Shows detail SQL statements executed by a user/sid
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   04.06.03
REM Adjusted where clause DECODE(v0.sql_address,'00'         USC   16.11.03
REM -------------------------------------------------------------------------

SET LINESIZE 140 PAGESIZE 999

ACCEPT sUserName CHAR PROMPT 'Username or Wildcard <%>: ' DEFAULT '%'
ACCEPT sSid CHAR PROMPT 'Session ID or Wildcard <%>: ' DEFAULT '%'

@@title "Session SQL Report"
COLUMN username FORMAT a10
COLUMN executions FORMAT 99999 heading "Exec."
BREAK ON username ON sid
SELECT /*+ ORDERED */ NVL(v0.username,v0.type) username, v0.sid sid, v1.sql_text
FROM v$session v0, v$sqltext v1
WHERE v0.username LIKE UPPER('&sUserName')
AND v0.sid LIKE '&sSid'
AND DECODE(v0.sql_hash_value,0,v0.prev_hash_value,v0.sql_hash_value) = v1.hash_value
AND DECODE(v0.sql_address,'00',v0.prev_sql_addr,v0.sql_address) = v1.address
-- AND v0.status = 'ACTIVE'
ORDER BY 1,2,piece;
CLEAR BREAKS
COLUMN USERNAME CLEAR
COLUMN EXECUTIONS CLEAR
TTITLE OFF

