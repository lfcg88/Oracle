REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         user_pga.sql
REM 
REM Version:      1.0
REM
REM Requirements: Oracle9i
REM
REM Description:  Shows PGA statistics about a given session id (SID)
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   20.08.01
REM -------------------------------------------------------------------------

SET LINESIZE 160 PAGESIZE 48

ACCEPT sUserName CHAR PROMPT 'Username or Wildcard <%>: ' DEFAULT '%'
ACCEPT sSid CHAR PROMPT 'Session ID or Wildcard <%>: ' DEFAULT '%'

@@title "Session PGA Optimal Usage Statistics"
SELECT t2.sid, t1.name, t2.value
FROM v$statname t1, v$sesstat t2, v$session t3
WHERE t1.name like 'workarea exec%'
AND t1.statistic# = t2.statistic#
AND t3.sid = t2.sid
AND t3.username LIKE UPPER('&sUserName')
AND t3.sid LIKE '&sSid'
ORDER BY t2.sid;

@@title "Session Workarea Mem Usage(KB)"
SELECT TO_NUMBER(DECODE(t1.sid, 65535, NULL, t1.sid)) sid,
  t1.operation_type OPERATION,
  TRUNC(t1.WORK_AREA_SIZE/1024) WSIZE, 
  TRUNC(t1.EXPECTED_SIZE/1024) ESIZE,
  TRUNC(t1.ACTUAL_MEM_USED/1024) "ACT MEM", 
  TRUNC(t1.MAX_MEM_USED/1024) "MAX MEM", 
  t1.number_passes PASS
FROM v$sql_workarea_active t1, v$session t2
WHERE t2.username LIKE UPPER('&sUserName')
AND t2.sid LIKE '&sSid'
AND t2.sid = t1.sid
ORDER BY 1,2;

SET LINESIZE 100 PAGESIZE 24





