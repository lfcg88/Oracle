REM -------------------------------------------------------------------------
REM Developer:    Uwe Suckow
REM
REM File:         rep_undo.sql
REM 
REM Version:      1.3
REM
REM Requirements: Oracle9i
REM
REM Description:  Reports rollback segment statistics
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM Display of optsize					                     USC   22.10.01
REM Tuning of "Rollback Tablespace Space Overview" and       USC   04.11.03
REM report output optimized
REM Added SID holding a transaction                          USC   08.01.03
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 160

@@title "Undo Management Report"
COL name FOR a30
COL value FOR a30
SELECT name, value
FROM v$parameter
WHERE name IN ('pga_aggregate_target', 'workarea_size_policy')
OR name like 'undo_%'
ORDER BY name;
COL name CLEAR
COL value CLEAR

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "Automated Undo Statistics Report"
-- Show statistics of last 3 hours
SELECT TO_CHAR(begin_time, 'DD-MM-YY HH24:MI:SS') AS begin_time, TO_CHAR(end_time, 'DD-MM-YY HH24:MI:SS') AS end_time,
  undoblks, txncount, maxquerylen, unxpstealcnt, unxpblkrelcnt, unxpblkreucnt, ssolderrcnt, nospaceerrcnt
FROM v$undostat
WHERE begin_time >= (SELECT MAX(begin_time) - 3/24
                     FROM v$undostat)
UNION
-- Show undo space errors or problems
SELECT TO_CHAR(begin_time, 'DD-MM-YY HH24:MI:SS') AS begin_time, TO_CHAR(end_time, 'DD-MM-YY HH24:MI:SS') AS end_time,
  undoblks, txncount, maxquerylen, unxpstealcnt, unxpblkrelcnt, unxpblkreucnt, ssolderrcnt, nospaceerrcnt
FROM v$undostat
WHERE unxpstealcnt > 0
OR unxpblkrelcnt > 0
OR unxpblkreucnt > 0
OR ssolderrcnt > 0
OR nospaceerrcnt > 0
ORDER BY begin_time DESC;

@@title "Rollback Tablespace Space Overview"
COL tablespace FOR a30
COL sum_bytes HEAD "Size|(MB)"
COL used_mb HEAD "Used|(MB)"
COL free_mb HEAD "Free|(MB)"
COL min_mb HEAD "Min. Extent| (MB)"
COL avg_mb HEAD "Avg. Extent| (MB)"
COL max_mb HEAD "Max. Extent| (MB)"
COL free_ext HEAD "Free|extents"
COL used_ext HEAD "Used|extents"
SELECT t1.tablespace_name "Tablespace",
  t2.sum_bytes,
  ROUND(t3.used_mb,2) used_mb,
  ROUND(SUM(t1.bytes)/1024/1024,2) free_mb,
  ROUND(MIN(t1.bytes/1024/1024),2) min_mb,
  ROUND(AVG(t1.bytes/1024/1024),2) avg_mb,
  ROUND(MAX(t1.bytes/1024/1024),2) max_mb,
  count(*) free_ext,
  t3.used used_ext
FROM dba_free_space t1, (SELECT tablespace_name, SUM(bytes)/1024/1024 sum_bytes
                         FROM dba_data_files
                         WHERE tablespace_name IN (SELECT DISTINCT tablespace_name
                                                   FROM dba_rollback_segs)
                         GROUP BY tablespace_name) t2,
                        (SELECT tablespace_name, SUM(extents) used, SUM(bytes)/1024/1024 used_mb
                         FROM dba_segments
                         WHERE tablespace_name IN (SELECT DISTINCT tablespace_name
                                                   FROM dba_rollback_segs)
                         GROUP BY tablespace_name) t3
WHERE t1.tablespace_name IN (SELECT DISTINCT tablespace_name
                             FROM dba_rollback_segs)
AND t1.tablespace_name = t2.tablespace_name
AND t1.tablespace_name = t3.tablespace_name (+)
GROUP BY t1.tablespace_name, t2.sum_bytes, t3.used, t3.used_mb;
COL tablespace CLEAR
COL sum_bytes CLEAR
COL used_mb CLEAR
COL free_mb CLEAR
COL min_mb CLEAR
COL avg_mb CLEAR
COL max_mb CLEAR
COL free_ext CLEAR
COL used_ext CLEAR

@@title "Rollback Segments Report"
COL name FOR a15
COL rsize FORMAT 999999.00
COL high_water FORMAT 999999.00
COL avg_shrink FOR 999999.00
COL initial_mb HEAD "INIT|_MB" FOR 999.00
COL status HEAD "STA-|TUS" FOR a4
COL xacts HEAD "AC-|TIV" FOR 99
COL shrinks HEAD "SHRI-|NKS" FOR 9999
COL extents HEAD "EXT-|ENTS" FOR 9999
SELECT t3.tablespace_name, t3.segment_name AS name, t3.initial_extent/1024/1024 initial_mb, t2.rssize/1024/1024 AS rsize,
  t2.optsize/1024/1024 AS osize, t2.hwmsize/1024/1024 AS high_water, t2.extents, t2.xacts, v0.sid, t2.waits, t2.gets, 
  DECODE(t3.status, 'ONLINE','ON','OFFLINE','OFF','?') AS status, t2.shrinks, 
  t2.aveshrink/1024/1024 AS avg_shrink, t2.extends
FROM v$rollname t1, v$rollstat t2, dba_rollback_segs t3, 
 (SELECT xidusn, sid
  FROM v$transaction v1, v$session v2
  WHERE v1.addr = v2.taddr) v0
WHERE t3.segment_name = t1.name (+)
AND t1.usn = t2.usn (+)
AND t1.usn = v0.xidusn (+)
ORDER BY t3.tablespace_name, t3.status DESC;
COL rsize CLEAR
COL high_water CLEAR
COL name CLEAR
COL avg_shrink CLEAR
COL status CLEAR
COL initial_mb CLEAR
COL xacts CLEAR
COL shrinks CLEAR
COL extents CLEAR

SET PAUSE OFF

@@title "Rollback Segment Wait Ratio Report"
REM
REM The ratio of the sum of WAITS to the sum of GETS in v$rollstat should be less
REM than 5%
SELECT ROUND(SUM(waits)/SUM(gets)*100,2) "Wait Ratio", SUM(waits) "Waits", SUM(gets) "Gets"
FROM v$rollstat;

@@title "Rollback Segment Statistic Report"
REM
REM 'db block gets' means block accessed for INSERT, UPDATE, DELETE and SELECT FOR UPDATE
REM undo waits should be less than 1% compared to 'db block gets' + 'consistent gets'
REM otherwise create more rollback segments
REM SYSTEM UNDO HEADER - The number of waits for buffers containing header blocks of the SYSTEM rollback segment. 
REM SYSTEM UNDO BLOCK - The number of waits for buffers containing blocks of the SYSTEM rollback segment other than header blocks. 
REM UNDO HEADER - The number of waits for buffers containing header blocks of rollback segments other than the SYSTEM rollback segment. 
REM UNDO BLOCK - The number of waits for buffers containing blocks other than header blocks of rollback segments other than the SYSTEM rollback segment.                     
REM
COL block_gets HEAD "DML|Block Gets"
COL consistent_gets HEAD "Select|Block Gets"
COL rec_applied HEAD "Undo Records|applied"
COL sys_undo_head HEAD "System Undo|Header Waits"
COL sys_undo_block HEAD "System Undo|Block Waits"
COL undo_head HEAD "Undo|Header Waits"
COL undo_block HEAD "Undo|Block Waits"
SELECT bg.value block_gets, cg.value consistent_gets,
  cr.value rec_applied,
  suh.count sys_undo_head, sub.count sys_undo_block, uh.count undo_head, ub.count undo_block
FROM v$sysstat cg, v$sysstat cr, v$sysstat bg, 
  v$waitstat suh, v$waitstat sub, v$waitstat uh, v$waitstat ub
WHERE bg.name = 'db block gets'
AND cg.name = 'consistent gets'
AND cr.name = 'data blocks consistent reads - undo records applied'
AND suh.class = 'system undo header'
AND sub.class = 'system undo block'
AND uh.class = 'undo header'
AND ub.class = 'undo block';
COL rec_applied CLEAR
COL sys_undo_head CLEAR
COL sys_undo_block CLEAR
COL undo_block CLEAR
COL block_gets CLEAR
COL consistent_gets CLEAR

SET PAGESIZE 24
