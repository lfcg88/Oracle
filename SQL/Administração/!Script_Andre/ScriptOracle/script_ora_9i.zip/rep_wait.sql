REM -------------------------------------------------------------------------
REM Developer:   Uwe Suckow
REM
REM File:        rep_wait.sql
REM 
REM Version:     1.0
REM
REM Description: Reports wait events
REM
REM Changes:                                                 Who:  Date:
REM Rollout                                                  USC   10.01.00
REM -------------------------------------------------------------------------

SET PAGESIZE 48 LINESIZE 120

@@title "Buffer Busy Waits Report"
REM data block     -> encrease block_buffer
REM segment header -> encrease freelists
REM undo header    -> encrease rollback segments
SELECT *
FROM v$waitstat
WHERE count != 0
ORDER BY count desc;

SET PAUSE ON PAUSE "Hit <RETURN>..."

@@title "System Event Report"
SELECT event, total_waits, total_timeouts AS Seconds
FROM v$system_event
WHERE event NOT IN ('dispatcher timer', 'pmon timer', 'rdbms ipc message', 'smon timer')
AND total_waits > 0
ORDER BY total_waits ASC;

SET PAUSE OFF

@@title "Session Wait Report"
SELECT event, SUM(seconds_in_wait), SUM(wait_time)
FROM v$session_wait 
WHERE event NOT IN ('dispatcher timer', 'pmon timer', 'rdbms ipc message', 'smon timer')
GROUP BY event;

SET PAGESIZE 24
