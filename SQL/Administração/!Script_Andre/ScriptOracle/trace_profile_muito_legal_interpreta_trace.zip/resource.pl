#!/usr/bin/perl
#
# File:          resource.pl
# Author:        Andy Rivenes, andy@appsdba.com, www.appsdba.com
#                Copyright (C) 2004-2005 AppsDBA Consulting. All Rights Reserved.
#             
# Date:          01/28/2004
#
# Description:   Creates an Oracle event 10046 trace interval resource profile.
#
# Modifications:
#   1.1,  AR, 02/19/2004, Changed hash array declarations. Compatible with
#                         perl 5.8. Removed event count for "unaccounted-for"
#                         time.
#   1.2,  AR, 03/31/2004, Fixed the case where the minimum CPU time could be
#                         left with the negative seeding value.
#   1.3,  AR, 01/19/2005, Updated Interval Rates and Waits section to add a
#                         "cumulative" label for avg, min, max times. The
#                         interval resource profiler makes no attempt to 
#                         calculate exclusive times for each statement.
#                
#
# Known Bugs:
#
#
# Enhancements Needed:
#
#
# Disclaimer:
#
#
#  AppsDBA Consulting licenses the Software to you on an "AS IS" basis, 
#  without warranty of any kind.
# 
#  APPSDBA CONSULTING HEREBY EXPRESSLY DISCLAIMS ALL WARRANTIES OR CONDITIONS, EITHER
#  EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OR 
#  CONDITIONS OF MERCHANTABILITY, NON INFRINGEMENT AND FITNESS FOR A PARTICULAR 
#  PURPOSE. 
# 
#  You are solely responsible for determining the appropriateness of using this 
#  Software and assume all risks associated with the use of this Software, 
#  including but not limited to the risks of program errors, damage to or loss 
#  of data, programs or equipment, and unavailability or interruption of 
#  operations. 
# 
#  APPSDBA CONSULTING WILL NOT BE LIABLE FOR ANY DIRECT DAMAGES OR FOR ANY SPECIAL,
#  INCIDENTAL, OR INDIRECT DAMAGES OR FOR ANY ECONOMIC CONSEQUENTIAL DAMAGES (INCLUDING
#  LOST PROFITS OR SAVINGS), EVEN IF APPSDBA CONSULTING HAS BEEN ADVISED OF THE 
#  POSSIBILITY OF SUCH DAMAGES. AppsDBA Consulting will not be liable for the loss of,
#  or damage to, your records or data, or any damages claimed by you based on a third
#  party claim. 
#
#  This software may be copied and furnished to others, and derivative works that 
#  comment on or otherwise explain it or assist in its implementation may be 
#  prepared, copied, published and distributed, in whole or in part, provided 
#  that the above copyright notice and this paragraph are included on all such 
#  copies and derivative works.
# 
#
###############################################################################
#
# INCLUDES / DIRECTIVES
#
###############################################################################
#
use strict;
use warnings;
#
use Time::Local; # Used to convert to UNIX epoch time
#
###############################################################################
#
# SUBROUTINES
#
###############################################################################
#
# VERSION - Display utility version
#
###############################################################################
sub VERSION {
  #
  # Process parameters
  #
  my ($obanner) = @_;
  #
  our $ohtml;
  #
  if ( $obanner == 1 ) {
    if ( $ohtml == 0 ) {
      print "\n";
      print "+-+-+  AppsDBA Event 10046 Interval Resource Profiler\n";
      print "\n";
      print "+-+-+  Copyright (c) 2004-2005, AppsDBA Consulting. All Rights Reserved.\n";
      print "+-+-+  Version 1.3, 01/19/2005\n";
      print "\n";
    }
    else {
      print "<h1>AppsDBA Event 10046 Interval Resource Profiler</h1>\n";
      print "<h4>Copyright (c) 2004-2005, AppsDBA Consulting. All Rights Reserved.<h4>\n";
      print "<h4>Version 1.3, 01/19/2005</h4>\n";
    }
  }
  else {
    print "\n";
  }
}
#
###############################################################################
#
# HELP - Display help information
#
###############################################################################
sub HELP {
  print "Usage: resource [-html|-text] <trace file>\n";
}
#
###############################################################################
#
# NUMERICALLY - Sort numbers in ascending order
#
###############################################################################
sub NUMERICALLY { 
  $a <=> $b;
}
#
###############################################################################
#
# DESCENDING - Sort numbers in descending order
#
###############################################################################
sub DESCENDING { 
  $b <=> $a;
}
#
###############################################################################
#
# COMMIFY - Return number with commas
#           (Benjamin Goldberg, nntp.perl.org FAQ)
#
###############################################################################
sub COMMIFY {
  my $number = shift;
  1 while ($number =~ s/^([-+]?\d+)(\d{3})/$1,$2/);
  return $number;
}
#
###############################################################################
#
# WRITE_INFO - Write formatted info to the output file
#
###############################################################################
sub WRITE_INFO {
  #
  # Process parameters
  #
  my ($info_label, $info_value) = @_;
  #
  printf "%-24s = %-25s\n", $info_label, $info_value;
}
#
###############################################################################
#
# CHK_RANGE - Check range to see if this line is part of the session
#
#    inputs:  $SIDSN - SIDSN key for the $session_list
#             $nlines - current line number
#
#    outputs: 0 - skip, not part of range 
#             1 - process, part of range
#
###############################################################################
sub CHK_RANGE { 
  #
  # Process parameters
  #
  my ($SIDSN, $nlines) = @_;
  #
  our %session_list;
  my $session_list = \%session_list;
  my $RC = 0;
  #
  if ( $SIDSN == 0 ) {
    $RC = 1;  # No SID, so assume full range
  }
  else {
    foreach my $sline (keys %{$session_list->{$SIDSN}}) {
      if (( $session_list->{$SIDSN}->{$sline}->{'start_key'} <= $nlines ) &&
         ( $session_list->{$SIDSN}->{$sline}->{'end_key'} >= $nlines )) {
        $RC = 1;
      }
    }
  }
  return $RC;
}
#
###############################################################################
#
# INIT_SUMSTATS - Initialize the sumstats hash
#
#
###############################################################################
sub INIT_SUMSTATS { 
  #
  # Process parameters
  #
  our %sumstats;
  my $sumstats = \%sumstats;
  #
  foreach my $typ ('non','rec') {
    foreach my $scmd ('PARSE','EXEC','FETCH') {
      $sumstats->{$typ}->{$scmd}->{'action'} = 0;
      $sumstats->{$typ}->{$scmd}->{'cpu'} = 0;
      $sumstats->{$typ}->{$scmd}->{'cpu_min'} = -1;
      $sumstats->{$typ}->{$scmd}->{'cpu_max'} = 0;
      $sumstats->{$typ}->{$scmd}->{'ela'} = 0;
      $sumstats->{$typ}->{$scmd}->{'phy'} = 0;
      $sumstats->{$typ}->{$scmd}->{'pga'} = 0;
      $sumstats->{$typ}->{$scmd}->{'cr'} = 0;
      $sumstats->{$typ}->{$scmd}->{'cu'} = 0;
      $sumstats->{$typ}->{$scmd}->{'lio'} = 0;
      $sumstats->{$typ}->{$scmd}->{'rows'} = 0;
      $sumstats->{$typ}->{$scmd}->{'sp'} = 0;
      $sumstats->{$typ}->{$scmd}->{'hp'} = 0;
    }
  }
}
#
###############################################################################
#
# INIT_SUMSTATS - Initialize the sumwait_totals hash
#
#
###############################################################################
sub INIT_SUMWAIT_TOTALS { 
  #
  # Process parameters
  #
  my ($event) = @_;
  #
  our %sumwait_totals;
  my $sumwait_totals = \%sumwait_totals;
  #
  $sumwait_totals->{$event}->{'time_waited'} = 0;
  $sumwait_totals->{$event}->{'total_waits'} = 0;
  $sumwait_totals->{$event}->{'min_time'} = -1;
  $sumwait_totals->{$event}->{'max_time'} = 0;
  $sumwait_totals->{$event}->{'total_distkey'} = 0;
}
#
###############################################################################
#
# PR_SQL_STAT - Create statistics for new PEFU statements
#               This subroutine collects stats for each PEFU statement
#               grouped by SQL address.  This is summed by the parent
#               "PARSING IN CURSOR" line number as well as each individual
#               cursor.
#
###############################################################################
sub PR_SQL_STAT { 
  #
  # Process parameters
  #
  my ($pefu_line) = @_;
  #
  our $c_factor;
  our $e_factor;
  our $PRECISION;
  our %sumstats;
  our %sumwait;
  #
  my $sumstats = \%sumstats;
  my $sumwait = \%sumwait;
  #
  my $pga = 0;
  #
  # Collect stats for SQL statements
  #
  my ($lnum,$cmd,$cur,$cpu,$ela,$phy,$cr,$cu,$mis,$rows,$dep,$og,$tim) = split(/:/,$pefu_line);
  #
  # tkprof reports UNMAP and SORT UNMAP stats as part of EXEC
  #
  my $scmd;
  if ($cmd =~ m/^UNMAP|^SORT UNMAP/) {
    $scmd = 'EXEC';  # Report UNMAP/SORT UNMAP as execute time - same as tkprof
  }
  else {
    $scmd = $cmd;
  }
  #
  # Format cpu and ela times
  #
  my $cpu_time = sprintf($PRECISION, ($cpu * $c_factor));  # Convert and round
  my $ela_time = sprintf($PRECISION, ($ela * $e_factor));  # Convert and round
  #
  # Associate direct I/O block count by PEFU statement
  #
  foreach my $curnum (keys %{$sumwait->{'pga'}}) {
    if ( ($curnum == $cur) && (defined $sumwait->{'pga'}->{$curnum}) ) { 
      $pga = $sumwait->{'pga'}->{$curnum};
      undef $sumwait->{'pga'}->{$curnum};
      last;
    }
  }
  #
  # Add to recursive/non-recursive interval totals
  #
  if ($dep == 0) {
    #
    # Capture non-recursive CPU time by statement
    #
    # Sum non-recursive mode SQL
    #
    $sumstats->{'non'}->{$scmd}->{'action'}++;
    $sumstats->{'non'}->{$scmd}->{'cpu'} += $cpu_time;
    #
    if ( ($sumstats->{'non'}->{$scmd}->{'cpu_min'} < 0) ||
         ($cpu_time < $sumstats->{'non'}->{$scmd}->{'cpu_min'}) ) {
      $sumstats->{'non'}->{$scmd}->{'cpu_min'} = $cpu_time;
    }
    if ( $cpu_time > $sumstats->{'non'}->{$scmd}->{'cpu_max'} ) {
      $sumstats->{'non'}->{$scmd}->{'cpu_max'} = $cpu_time;
    }
    #
    $sumstats->{'non'}->{$scmd}->{'ela'} += $ela_time;
    $sumstats->{'non'}->{$scmd}->{'phy'} += $phy;
    $sumstats->{'non'}->{$scmd}->{'pga'} += $pga;
    $sumstats->{'non'}->{$scmd}->{'cr'} += $cr;
    $sumstats->{'non'}->{$scmd}->{'cu'} += $cu;
    $sumstats->{'non'}->{$scmd}->{'lio'} += ($cr + $cu);
    $sumstats->{'non'}->{$scmd}->{'rows'} += $rows;
    if ($scmd eq 'PARSE') {
      if ($mis == 0) {
        $sumstats->{'non'}->{$scmd}->{'sp'}++;
      }
      else {
        $sumstats->{'non'}->{$scmd}->{'hp'}++;
      }
    }
  }
  else {
    #
    # Sum recursive mode SQL
    #
    $sumstats->{'rec'}->{$scmd}->{'action'}++;
    $sumstats->{'rec'}->{$scmd}->{'cpu'} += $cpu_time;
    #
    if ( ($sumstats->{'rec'}->{$scmd}->{'cpu_min'} < 0) ||
         ($cpu_time < $sumstats->{'rec'}->{$scmd}->{'cpu_min'}) ) {
      $sumstats->{'rec'}->{$scmd}->{'cpu_min'} = $cpu_time;
    }
    if ( $cpu_time > $sumstats->{'rec'}->{$scmd}->{'cpu_max'} ) {
      $sumstats->{'rec'}->{$scmd}->{'cpu_max'} = $cpu_time;
    }
    #
    $sumstats->{'rec'}->{$scmd}->{'ela'} += $ela_time;
    $sumstats->{'rec'}->{$scmd}->{'phy'} += $phy;
    $sumstats->{'rec'}->{$scmd}->{'pga'} += $pga;
    $sumstats->{'rec'}->{$scmd}->{'cr'} += $cr;
    $sumstats->{'rec'}->{$scmd}->{'cu'} += $cu;
    $sumstats->{'rec'}->{$scmd}->{'lio'} += ($cr + $cu);
    $sumstats->{'rec'}->{$scmd}->{'rows'} += $rows;
    if ($scmd eq 'PARSE') {
      if ($mis == 0) {
        $sumstats->{'rec'}->{$scmd}->{'sp'}++;
      }
      else {
        $sumstats->{'rec'}->{$scmd}->{'hp'}++;
      }
    }
  }
}
#
###############################################################################
#
# PR_STAT_SUM - Create an statistic summary
#
#    inputs:  $sqlkey - parent cursor line number
#             $sqladdr - parent cursor address, used for printing
#
#             $c_factor - cpu centi-second conversion
#             $e_factor - elapsed time centi-second conversion
#
#    outputs: Local rpt... and sumt... variables for printing
#
###############################################################################
sub PR_STAT_SUM { 
  #
  our $ohtml;
  our $PRECISION;
  our %sumstats;
  #
  my $sumstats = \%sumstats;
  #
  my ($sumtact, $sumtcpu, $sumtela, $sumtphy, $sumtpga, $sumtsga,
      $sumtcr, $sumtcu, $sumtlio, $sumtrow);
  #
  # Print non-recursive and recursive SQL totals
  #
  foreach my $typkey ('non','rec') {
    #
    # Zero out summary totals
    #
    $sumtact = 0;  # Total PARSE|EXEC|FETCH
    $sumtcpu = 0;  # Total CPU    
    $sumtela = 0;  # Total elapsed time
    $sumtphy = 0;  # Total physical reads (Total)
    $sumtpga = 0;  # Total physical reads (PGA)
    $sumtsga = 0;  # Total physical reads (SGA)
    $sumtcr = 0;   # Total consistent reads
    $sumtcu = 0;   # Total current mode reads
    $sumtlio = 0;  # Total logical I/O
    $sumtrow = 0;  # Total rows
    #
    # Write header
    #
    if ($typkey eq 'non') {
      if ($ohtml == 1) {
        print "<h2>OVERALL TOTALS FOR ALL NON-RECURSIVE STATEMENTS</h2>\n";
        print "<pre>\n";
      }
      else {
        print "OVERALL TOTALS FOR ALL NON-RECURSIVE STATEMENTS\n\n";
      }
    }
    else {
      if ($ohtml == 1) {
        print "</pre>\n";
        print "<h2>OVERALL TOTALS FOR ALL RECURSIVE STATEMENTS</h2>\n";
        print "<pre>\n";
      }
      else {
        print "\nOVERALL TOTALS FOR ALL RECURSIVE STATEMENTS\n\n";
      }
    }
    $~ = "STAT_TOP";
    write;
    #
    my ($action, $rptact, $rptcpu, $rptela, $rptphy, $rptpga, $rptsga,
        $rptcr, $rptcu, $rptlio, $rptrow);
    #
    foreach my $scmd ('PARSE','EXEC','FETCH') {
      $action = $scmd;
      $rptact = sprintf("%0d", $sumstats->{$typkey}->{$scmd}->{'action'});
      $rptcpu = sprintf($PRECISION, $sumstats->{$typkey}->{$scmd}->{'cpu'});
      $rptela = sprintf($PRECISION, $sumstats->{$typkey}->{$scmd}->{'ela'});
      $rptphy = sprintf("%0d", $sumstats->{$typkey}->{$scmd}->{'phy'});
      $rptpga = sprintf("%0d", $sumstats->{$typkey}->{$scmd}->{'pga'});
      $rptsga = sprintf("%0d", ( $rptphy - $rptpga ));
      $rptcr = sprintf("%0d", $sumstats->{$typkey}->{$scmd}->{'cr'});
      $rptcu = sprintf("%0d", $sumstats->{$typkey}->{$scmd}->{'cu'});
      $rptlio = sprintf("%0d", $sumstats->{$typkey}->{$scmd}->{'lio'});
      $rptrow = sprintf("%0d", $sumstats->{$typkey}->{$scmd}->{'rows'});
      #
      printf("%-7s %8s %11s %12s %11s  %10s %10s %8s  %10s %10s %8s\n",
        &COMMIFY($action),&COMMIFY($rptact),&COMMIFY($rptrow),&COMMIFY($rptcpu),&COMMIFY($rptela),
        &COMMIFY($rptlio),&COMMIFY($rptcr),&COMMIFY($rptcu),&COMMIFY($rptphy),&COMMIFY($rptsga),
        &COMMIFY($rptpga));
      #
      $sumtact += $rptact;
      $sumtcpu += $rptcpu;
      $sumtela += $rptela;
      $sumtphy += $rptphy;
      $sumtpga += $rptpga;
      $sumtsga += $rptsga;
      $sumtcr += $rptcr;
      $sumtcu += $rptcu;
      $sumtlio += $rptlio;
      $sumtrow += $rptrow;
    }
    # Write final totals
    $sumtcpu = sprintf($PRECISION, $sumtcpu);
    $sumtela = sprintf($PRECISION, $sumtela);
    #
    $~ = "STAT_END";
    write;
    printf("Total   %8s %11s %12s %11s  %10s %10s %8s  %10s %10s %8s\n",
      &COMMIFY($sumtact),&COMMIFY($sumtrow),&COMMIFY($sumtcpu),&COMMIFY($sumtela),
      &COMMIFY($sumtlio),&COMMIFY($sumtcr),&COMMIFY($sumtcu),&COMMIFY($sumtphy),
      &COMMIFY($sumtsga),&COMMIFY($sumtpga));
  }
  #
  # Write separator
  if ($ohtml == 1) {
    print "</pre>\n";
    $~ = "SEPARATOR_LINE_HTML";
  }
  else {
    print "\n";
    $~ = "SEPARATOR_LINE";
  }
  write;
}
#
format STAT_TOP = 
                                                       --------- LIO Blocks ---------  --------- PIO Blocks ---------
Action     Count        Rows          CPU     Elapsed       Total Consistent  Current       Total        SGA      PGA
------- -------- ----------- ------------ -----------  ---------- ---------- --------  ---------- ---------- --------
.
#
format STAT_END =
------- -------- ----------- ------------ -----------  ---------- ---------- --------  ---------- ---------- --------
.
#
###############################################################################
#
# PR_EVENT_STAT - Collect statement wait events for a single SQL statement
#
#             inputs:  $wait_key - Wait event line number
#
#             outputs: %$sumwait
#
###############################################################################
sub PR_EVENT_STAT {
  #
  # Process parameters
  #
  my ($wait_line, $dep, $scmd) = @_;
  #
  our %sumwait;
  our $w_factor;
  #
  my $sumwait = \%sumwait;
  #
  my ($lnum,$cmd,$cur,$nam,$ela,$p1,$p2,$p3) = split(/:/, $wait_line);
  my $found = 0;
  my $ntim = ($ela * $w_factor);
  #
  foreach my $event (keys %$sumwait) {
    if ( $nam eq $event ) {
      $found = 1;
      #
      $sumwait->{$nam}->{'time_waited'} += $ntim;
      $sumwait->{$nam}->{'total_waits'}++;
      #
      # Add max and min
      # 
      if ( $ntim < $sumwait->{$nam}->{'min_time'} ) {
        $sumwait->{$nam}->{'min_time'} = $ntim;
      }
      #
      if ( $ntim > $sumwait->{$nam}->{'max_time'} ) {
        $sumwait->{$nam}->{'max_time'} = $ntim;
      }
      #
      last;
    }
  }
  #
  # Add wait event to summary array
  #
  if ($found == 0) {
    $sumwait->{$nam}->{'time_waited'} = $ntim;
    $sumwait->{$nam}->{'total_waits'} = 1;
    #
    # Add max and min
    # 
    $sumwait->{$nam}->{'min_time'} = $ntim;
    $sumwait->{$nam}->{'max_time'} = $ntim;
  }
  #
  # Capture direct I/O counts
  #
  foreach my $event ('\'direct path read\'', '\'direct path read (lob)\'') {
    if ( $nam eq $event ) {
       $sumwait->{'pga'}->{$cur} += $p3;
    }  
  }
}
#
###############################################################################
#
# PR_EVENT_SUM - Calculate and print "Rates and Waits" event summary
#
#   @wait_sum = ($ws_nam,$ws_ttmw,$ws_tw);
#
###############################################################################
sub PR_EVENT_SUM {
  #
  # Process parameters
  #
  my ($intvl_total) = @_;
  #
  our $ohtml;
  our $e_factor;
  our $PRECISION;
  #
  our %sumstats;
  our %sumwait;
  our %sumwait_totals = ();  # Initialize the wait event summary hash
  #
  my $sumstats = \%sumstats;
  my $sumwait = \%sumwait;
  my $sumwait_totals = \%sumwait_totals;
  #
  # Track totals 
  #
  my $sumwtot = 0;  # Total time waited
  my $sumtpct = 0;  # Total pct of waits
  my $sumtotev = 0;  # Total events
  #
  # Total events
  #
  my ($ntim, $ntw) = (0, 0);
  foreach my $event (keys %$sumwait) {
    $ntim = $sumwait->{$event}->{'time_waited'};
    $ntw = $sumwait->{$event}->{'total_waits'};
    #
    if  ( ($event ne 'TOTAL') && ($event ne 'unaccounted-for') &&
          ($event ne 'pga') && ($event ne 'CPU Service') ) {
      #
      # Initialize sumwait_totals hash for this event
      #
      &INIT_SUMWAIT_TOTALS($event);
      #
      $sumwtot += $ntim;
      $sumwait_totals->{$event}->{'time_waited'} += $ntim;
      $sumwait_totals->{$event}->{'total_waits'} += $ntw;
      $sumwait_totals->{$event}->{'total_distkey'}++;
      #
      # Add max and min
      # 
      if ( ($sumwait_totals->{$event}->{'min_time'} < 0) ||
           ($sumwait->{$event}->{'min_time'} < $sumwait_totals->{$event}->{'min_time'}) ) {
        $sumwait_totals->{$event}->{'min_time'} = $sumwait->{$event}->{'min_time'};
      }
      #
      if ($sumwait->{$event}->{'max_time'} > $sumwait_totals->{$event}->{'max_time'}) {
        $sumwait_totals->{$event}->{'max_time'} = $sumwait->{$event}->{'max_time'};
      }
    }
  }
  #
  # Rates and Waits - this code adds CPU time to the wait event summary
  # and calculates any missing time.
  #
  my ($cpu_service, $cpu_counts, $e_time) = (0, 0, 0);
  #
  # Initialize sumwait_totals hash for this event
  #
  &INIT_SUMWAIT_TOTALS('CPU Service');
  #
  # Add up the PARSE|EXEC|FETCH totals for non-recursive statement totals
  #
  # Calculate CPU min and max times
  #
  foreach my $typkey ('PARSE','EXEC','FETCH') {
    $cpu_counts += $sumstats->{'non'}->{$typkey}->{'action'} + $sumstats->{'rec'}->{$typkey}->{'action'};
    $cpu_service += $sumstats->{'non'}->{$typkey}->{'cpu'};
    #
    # Add max and min
    # 
    if ( ($sumwait_totals->{'CPU Service'}->{'min_time'} < 0) ||
         ($sumstats->{'non'}->{$typkey}->{'cpu_min'} < $sumwait_totals->{'CPU Service'}->{'min_time'}) ) {
      $sumwait_totals->{'CPU Service'}->{'min_time'} = $sumstats->{'non'}->{$typkey}->{'cpu_min'};
    }
    if ( $sumstats->{'non'}->{$typkey}->{'cpu_max'} > $sumwait_totals->{'CPU Service'}->{'max_time'} ) {
      $sumwait_totals->{'CPU Service'}->{'max_time'} = $sumstats->{'non'}->{$typkey}->{'cpu_max'};
    }
  }
  #
  $e_time = sprintf($PRECISION, ($intvl_total * $e_factor));
  #
  $sumwait_totals->{'CPU Service'}->{'time_waited'} = $cpu_service;
  $sumwait_totals->{'CPU Service'}->{'total_waits'} = $cpu_counts;
  #
  # Calculate the unaccounted for time -> t = e - (c + ela)
  #
  my $unacct_time = $e_time - ($cpu_service + $sumwtot);
  #
  if ($unacct_time != 0) {
    #
    # Initialize sumwait_totals hash for this event
    #
    &INIT_SUMWAIT_TOTALS('unaccounted-for');
    #
    $sumwait_totals->{'unaccounted-for'}->{'time_waited'} = $unacct_time;
    $sumwait_totals->{'unaccounted-for'}->{'total_waits'} = 0;
    if ($unacct_time > 0) {
      $sumwtot += $unacct_time;
    }
  }
  #
  # Print summary totals
  #
  if ($ohtml == 1) {
    print "<h2>INTERVAL RATES AND WAITS (service time + wait time)</h2>\n";
    print "<pre>\n";
  }
  else {
    print "INTERVAL RATES AND WAITS (service time + wait time)\n\n";
  }
  #
  # Write header
  $~ = "WAIT_EVENT_TOP";
  write;
  #
  # Sort wait events descending by total time waited
  #
  my ($sumtw, $sumtotw, $summin, $summax, $sumpct, $sumavg);
  #
  foreach our $event (sort { 
      $sumwait_totals->{$b}->{'time_waited'} <=> $sumwait_totals->{$a}->{'time_waited'}
      ||
      $sumwait_totals->{$b}->{'total_waits'} <=> $sumwait_totals->{$a}->{'total_waits'}
      } (keys(%$sumwait_totals))) {
    $sumtw = sprintf($PRECISION, $sumwait_totals->{$event}->{'time_waited'});
    $sumtotw = sprintf("%0d", $sumwait_totals->{$event}->{'total_waits'});
    if ( $sumwait_totals->{$event}->{'min_time'} < 0 ) {
      $summin = sprintf($PRECISION, 0);
    }
    else {
      $summin = sprintf($PRECISION, $sumwait_totals->{$event}->{'min_time'});
    }
    $summax = sprintf($PRECISION, $sumwait_totals->{$event}->{'max_time'});
    #
    if (($cpu_service + $sumwtot) > 0) {
      $sumpct = ($sumtw / ($cpu_service + $sumwtot)) * 100;
    }
    else {
      $sumpct = 0;
    }
    #
    if ($sumtotw > 0) {
      $sumavg = sprintf($PRECISION, ($sumtw / $sumtotw));
    }
    else {
      $sumavg = sprintf($PRECISION, 0);
    }
    #
    $sumtotev += $sumtotw; # Running event total
    #
    if ( $event eq 'unaccounted-for' ) {
      if ($sumtw <= 0) {
        $sumpct = 0;
      }
      $sumtotw = " ";
      $summin = " ";
      $summax = " ";
      $sumavg = " ";
      # Strip quotes from event and pad to a fixed length name for printing
      $event =~ s/'//g;
      my $out_length = length $event;
      if ( $out_length < 33 ) {
        my $numsp = 33 - $out_length;
        for (my $i=1; $i < $numsp; $i++) {
          $event .= " ";
        }
      }
    }
    else {
      # Strip quotes from event name and pad to a fixed length for printing
      $event =~ s/'//g;
      my $out_length = length $event;
      if ( $out_length > 32 ) {
        $event = substr($event, 0, 31) . "*";
      }
      #
      if ($ohtml == 1) {
        #$event = "<a href=\"\#$event\">$event</a>";
        if ( $out_length < 33 ) {
          my $numsp = 33 - $out_length;
          for (my $i=1; $i < $numsp; $i++) {
            $event .= " ";
          }
        }
      }
    }
    #
    $sumtpct += $sumpct; # Running pct total
    $sumpct = sprintf("%.2f", $sumpct);
    #
    if ($ohtml == 1) {
      # Changed to printf to handle the variable length html
      printf("%32s  %17s   %6s  %10s  %13s  %13s  %13s\n",
        $event,&COMMIFY($sumtw),$sumpct,&COMMIFY($sumtotw),&COMMIFY($sumavg),&COMMIFY($summin),&COMMIFY($summax));
    }
    else {
      printf("%-32s  %17s   %6s  %10s  %13s  %13s  %13s\n",
        $event,&COMMIFY($sumtw),$sumpct,&COMMIFY($sumtotw),&COMMIFY($sumavg),&COMMIFY($summin),&COMMIFY($summax));
    }
  }
  #
  # Print event totals
  $sumtpct = sprintf("%.2f", $sumtpct);
  #
  $~ = "WAIT_END";
  write;
  #
  printf("%-32s  %17s   %6s  %10s\n",
    "Total",&COMMIFY($e_time),$sumtpct,&COMMIFY($sumtotev));
  #
  if ($ohtml == 1) {
    print "</pre>\n";
  }
  else {
    print "\n";
  }
  #
  # Write separator
  if ($ohtml == 1) {
    $~ = "SEPARATOR_LINE_HTML";
  }
  else {
    $~ = "SEPARATOR_LINE";
  }
  write;
}
#
format WAIT_EVENT_TOP = 
                                        Total Event  % Event       Total  --------------- Cumulative ----------------
Event Name                               Time (sec)     Time      Events  Avg Time(sec)  Min Time(sec)  Max Time(sec)
--------------------------------  -----------------  -------  ----------  -------------  -------------  -------------
.
#
format WAIT_END =
--------------------------------  -----------------  -------  ----------  -------------  -------------  -------------
.
#
###############################################################################
#
# PR_TRC_SUMMARY - Process the trace file summary
#                  This is the first pass to determine the sessions in the file.
#
###############################################################################
sub PR_TRC_SUMMARY {
  #
  # Process parameters
  #
  my ($trcfile) = @_;
  #
  our $trcfile_lines;
  our $num_sessions;
  our $num_connections;
  our $ora_ver_str;
  our $node_name;
  our $instance_name;
  our ($c_factor, $e_factor, $w_factor, $PRECISION);
  our ($truncated, $trunc_size); 
  our $ohtml; 
  #
  our %session_list;
  my $session_list = \%session_list;
  #
  my $preamble_timing = 0; # If preamble has been found and timing set, don't recheck
  my $SIDSN;
  #
  open TRCFILE, "< $trcfile" or die "$0: can't open '$trcfile'  ($!)";
  while ($_ = <TRCFILE>) {
    $trcfile_lines++;
    #
    if (/^(PARSING IN CURSOR).#(\d+).*len=(\d+).*dep=(\d+).*uid=(\d+).*oct=(\d+).*lid=(\d+).*tim=(\d+).*hv=(\d+).*ad='(\w+)/i) {
      #
      my $tim = $8;  
      #
      if ( ! $preamble_timing ) {
        if ( $tim =~ m/(\d{16})/ ) {
          if ( ($c_factor * 100) == 1 ) {
            #
            # Timing has 16 significant digits so timing is microseconds
            #
            # Timing multiplcation factors
            # In 9i wait events and elpased time are reported in 
            # microseconds (.000_001)
            $c_factor = 0.000_001;  # CPU time (1,000,000ths)
            $e_factor = 0.000_001;  # Elapsed time (1,000,000ths)
            $w_factor = 0.000_001;  # Wait events (1,000,000ths)
            $PRECISION = "%.6f";  # Set CPU, elapsed, and aggregated time format precision
            #
            $preamble_timing = 1; # Set to true at this point so we don't keep checking            
          }
        }
      }
    }
    elsif (/^(\*{3}\s)/i) {
      #
      # Save the parsed record
      #
      if (m/^\*{3}\sSESSION ID:\((\d+)\.(\d+)\)\s(\d{4})-(\d{2})-(\d{2})\s+(\d{2}):(\d{2}):(\d{2})\.(\d+)/) {
        #
        # The session id marker, if found, marks the start of a new session within the trace file.
        #
        $SIDSN = $1.$2;
        $num_connections++;  # Total number of connections
        #
        my $found_session = 0;
        foreach my $skey (keys %$session_list) {
          if ( $skey == $SIDSN ) {
            $found_session = 1;
            last;
          }
        }
        if ( $found_session == 0 ) {
          $num_sessions++;  # Number of distinct sessions
        }
        #
        # Set previous range
        #
        my $rnum = 0;  # Test just to make sure we don't set more than one.
        foreach my $skey (keys %$session_list) {
          foreach my $sline (keys %{$session_list->{$skey}}) {
            if ( $session_list->{$skey}->{$sline}->{'end_key'} == 0 ) {
              $session_list->{$skey}->{$sline}->{'end_key'} = $trcfile_lines - 1;
              $rnum++;
              if ( $rnum > 1 ) {
                print STDOUT "\nWARNING: Setting more than one end_key for a range.\n";
              }
            }
          }
        }
        #
        $session_list->{$SIDSN}->{$trcfile_lines}->{'start_key'} = $trcfile_lines + 1;
        $session_list->{$SIDSN}->{$trcfile_lines}->{'end_key'} = 0;
        $session_list->{$SIDSN}->{$trcfile_lines}->{'SID'} = $1;
        $session_list->{$SIDSN}->{$trcfile_lines}->{'SN'} = $2;
        $session_list->{$SIDSN}->{$trcfile_lines}->{'start_time'} = "$4-$5-$3 $6:$7:$8.$9";
        #
        $session_list->{$SIDSN}->{$trcfile_lines}->{'intvl_start'} = 0;
        $session_list->{$SIDSN}->{$trcfile_lines}->{'intvl_end'} = 0;
      }
      elsif (m/^\*{3}\sDUMP FILE SIZE IS LIMITED TO\s(\d+)\sBYTES\s\*{3}/) {
        #
        # The trace file has been truncated
        #
        $truncated = 1;
        $trunc_size = $1;  # Dump file size in bytes
      }
    }
    else {
      #
      # Look for preamble information
      #
      # Check for other lines or skip
      # Get instance name
      if (/^Instance name:/) {
        chop $_;
        (my $ilabel,$instance_name) = split(/:/, $_);
        $instance_name =~ s/\s//g;  # Strip any white space chars
      }
      # Get node name
      elsif (/^Node name:/) {
        chop $_;
        (my $nlabel,$node_name) = split(/:/, $_);
        $node_name =~ s/\s//g;  # Strip any white space chars
      }
      #
      # Get version, also use this to set timing format masks
      #
      elsif ( m/^Oracle.*Release\s*(\d+\.\d+\.\d+\.\d+\.\d+)/ ) {
        $ora_ver_str = $1;  # Set printable version string
        # Timing multiplcation factors
        $ora_ver_str =~ m/^(\d+)\.\d+\.\d+\.\d+\.\d+/;
        # print "\nMajor version: $1\n";
        if ( $1 >= 9 ) {
          # In 9i and above wait events and elpased time are reported in 
          # microseconds (.000_001)
          # and cpu time is still centisecond and converted in the trace file
          # to microsecond times.
          $c_factor = 0.000_001;  # CPU time (1,000,000ths)
          $e_factor = 0.000_001;  # Elapsed time (1,000,000ths)
          $w_factor = 0.000_001;  # Wait events (1,000,000ths)
          $PRECISION = "%.6f";  # Set CPU, elapsed, and aggregated time format precision
        }
        #
        $preamble_timing = 1; # Found preamble timing, set to true
      }
    }
  }
  close TRCFILE;
  #
  # Set final range
  #
  if ( $num_sessions == 0 ) {
    $session_list->{0}->{$trcfile_lines}->{'start_key'} = 1;
    $session_list->{0}->{$trcfile_lines}->{'end_key'} = $trcfile_lines;
    $session_list->{0}->{$trcfile_lines}->{'SID'} = "UNKNOWN";
    $session_list->{0}->{$trcfile_lines}->{'SN'} = "UNKNOWN";
    $session_list->{0}->{$trcfile_lines}->{'start_time'} = "UNKNOWN";
    $session_list->{0}->{$trcfile_lines}->{'intvl_start'} = 0;
    $session_list->{0}->{$trcfile_lines}->{'intvl_end'} = 0;
    #
    $num_sessions = 1;
    $num_connections = 1;
  }
  else {
    my $rnum = 0;  # Test just to make sure we don't set more than one.
    foreach my $skey (keys %$session_list) {
      foreach my $sline (keys %{$session_list->{$skey}}) {
        if ( $session_list->{$skey}->{$sline}->{'end_key'} == 0 ) {
          $session_list->{$skey}->{$sline}->{'end_key'} = $trcfile_lines;
          $rnum++;
          if ( $rnum > 1 ) {
            print "\nWARNING: Setting more than one end_key for a range.\n";
          }
        }
      }
    }
  }
  #
  # Write separator
  if ($ohtml == 1) {
    $~ = "SEPARATOR_LINE_HTML";
  }
  else {
    $~ = "SEPARATOR_LINE";
  }
  write;
  #
}
#
###############################################################################
#
# PR_TRC_DETAIL - Process the trace file details
#
###############################################################################
sub PR_TRC_DETAIL {
  #
  # Process parameters
  #
  my ($trcfile, $SIDSN) = @_;
  #
  my $lcmd = '';;
  our $nlines = 0;
  our $num_sql = 0;  # Total number of SQL statements
  our $ohtml;
  our %session_list;
  #
  our %sumwait = ();
  our %sumstats = ();
  &INIT_SUMSTATS;
  #
  our $time_start = 0;
  our $time_end = 0;
  our $time_offset = 0;
  #
  my $wait_line;
  my $pefu_line;
  #
  my $session_list = \%session_list;
  my $sumstats = \%sumstats;
  my $sumwait = \%sumwait;
  #
  # Send status info to STDOUT
  #
  print STDOUT "Processing session: $SIDSN\n";
  #
  open TRCFILE, "<$trcfile" or die "$0: can't open '$trcfile'  ($!)";
  while ($_ = <TRCFILE>) {
    $nlines++;
    #
    # Send status info to STDOUT
    #
    if ( ($nlines % 10000) == 0 ) {
      print STDOUT "Processed $nlines lines\n";
    }
    #
    if ( &CHK_RANGE($SIDSN, $nlines) ) {
      #
      if (/^(PARSING IN CURSOR).#(\d+).*len=(\d+).*dep=(\d+).*uid=(\d+).*oct=(\d+).*lid=(\d+).*tim=(\d+).*hv=(\d+).*ad='(\w+)/i) {
        #
        # Parse the record
        #
        my ($cur, $dep, $uid, $hv, $ad) = (0, 0, 0, 0, 0);  # Initialize local variables at outermost level
        if ($9 == 0) {
          ($cur, $dep, $uid, $hv, $ad) = ($2, $4, $5, $nlines, $10);
        }
        else {
          ($cur, $dep, $uid, $hv, $ad) = ($2, $4, $5, $9, $10);
        }
        #
        # Track interval time start and end
        #
        if ($time_start == 0) {
          $time_start = ($8 - $time_offset);
          $time_offset = 0;
          $time_end = $8;
        }
        else {
          $time_end = $8;
        }
        #
        # Add this to the total SQL count
        #
        $num_sql++;
        #
        # Set up for the next statement
        #
        $lcmd = $1;  # Last command found
      }
      elsif (/^(PARSE|EXEC|FETCH|UNMAP|SORT UNMAP).#(\d+).c=(\d+),e=(\d+),p=(\d+),cr=(\d+),cu=(\d+),mis=(\d+),r=(\d+),dep=(\d+),og=(\d+),tim=(\d+)/i) {
        #
        # Add the PARSE|EXEC|FETCH|UNMAP|SORT UNMAP line marker
        #
        # Save the parsed record
        #
        $pefu_line = join(':',$nlines,$1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12);
        #
        # Track interval time start and end
        #
        if ($time_start == 0) {
          $time_start = ($12 - $time_offset);
          $time_offset = 0;
          $time_end = $12;
        }
        else {
          $time_end = $12;
        }
        #
        &PR_SQL_STAT($pefu_line);  # Call PR_SQL_STAT to add all the totals
        #
        # Set up for the next statement
        #
        $lcmd = $1;  # Last command found
      }
      elsif (/^(WAIT).#(\d+).*nam=(\'.*\').*ela=\s*(\d+).*p1=(-?\d+).*p2=(-?\d+).*p3=(-?\d+)/i) {
        #
        # Save the parsed record
        #
        $wait_line = join(':',$nlines,$1,$2,$3,$4,$5,$6,$7);
        #
        # Track interval time start and end
        #
        if ($time_start == 0) {
          $time_offset = $4;
        }
        $time_end += $4;
        #
        &PR_EVENT_STAT($wait_line);  # Call PR_EVENT_STAT to add all the totals
        #
        # Set up for the next statement
        #
        $lcmd = $1;  # Last command found
      }
      else {
        # Handle everything else
        #
        # Capture SQL statements
        #
        if ($lcmd eq 'PARSING IN CURSOR') {
          if (/^END OF STMT/) {
            $lcmd = '';
          }
        }
        else {
          #
          # Capture any timing or skip
          #
          if (/^.*#(\d+).*dep=(\d+).*tim=(\d+)/i) {
            # print "$_\n";
            #
            # Track interval time start and end
            #
            if ($time_start == 0) {
              $time_start = ($3 - $time_offset);
              $time_offset = 0;
              $time_end = $3;
            }
            else {
              $time_end = $3;
            }
          }
          elsif (/^.*#(\d+).*tim=(\d+)/i) {
            # print "$_\n";
            #
            # Track interval time start and end
            #
            if ($time_start == 0) {
              $time_start = ($2 - $time_offset);
              $time_offset = 0;
              $time_end = $2;
            }
            else {
              $time_end = $2;
            }
          }
          #
          # Set up for the next statement
          #
          $lcmd = '';  # Last command found
        }
      }
    }
    else {
      # We've crossed a range or ended - deal with the time span!!
      #
      if ( &CHK_RANGE($SIDSN, ($nlines - 1)) ) {
        foreach my $sline (keys %{$session_list->{$SIDSN}}) {
          if ( $session_list->{$SIDSN}->{$sline}->{'end_key'} == ($nlines - 1) ) {
            $session_list->{$SIDSN}->{$sline}->{'intvl_start'} = $time_start;
            $session_list->{$SIDSN}->{$sline}->{'intvl_end'} = $time_end;
            #
            # Reset interval time
            #
            $time_start = 0;
            $time_end = 0;
            $time_offset = 0;
            #
            last;
          }
        }
      }
    }
  }
  #
  # Record any final timing here
  # This is the case where the range ended the file
  #
  if ( &CHK_RANGE($SIDSN, $nlines) ) {
    foreach my $sline (keys %{$session_list->{$SIDSN}}) {
      if ( $session_list->{$SIDSN}->{$sline}->{'end_key'} == $nlines ) {
        $session_list->{$SIDSN}->{$sline}->{'intvl_start'} = $time_start;
        $session_list->{$SIDSN}->{$sline}->{'intvl_end'} = $time_end;
        last;
      }
    }
  }
  #
}
#
format SESSION_TITLE_HTML =
<hr>
<h2>SESSION INFORMATION</h2>
.
#
format SESSION_TITLE =
*********************************************************************************************************************
 
SESSION INFORMATION

.
#
format SEPARATOR_LINE_HTML = 
<hr>
.
#
format SEPARATOR_LINE = 
*********************************************************************************************************************

.
#
###############################################################################
#
# Print trace file session banner information
#
###############################################################################
sub PR_PRT_DETAIL {
  #
  # Process parameters
  #
  my ($SIDSN) = @_;
  #
  our $PRECISION;
  our $ohtml;
  our $e_factor;
  our $num_sql;
  our %session_list;
  #
  my ($SID, $SN) = (0, 0);
  my $session_list = \%session_list;
  #
  # Send status info to STDOUT
  #
  print STDOUT "Begin output phase for session: $SIDSN\n";
  #
  # Write separator
  if ($ohtml == 1) {
    $~ = "SESSION_TITLE_HTML";
  }
  else {
    $~ = "SESSION_TITLE";
  }
  write;
  #
  $~ = "INFO_OUT";
  if ($ohtml == 1) {
    print "<pre>\n";
  }
  #
  if ( $SIDSN == 0 ) {
    &WRITE_INFO("Session SID:", "UNKNOWN");
    #
    &WRITE_INFO("Session Serial#:", "UNKNOWN");
  }
  else {
    foreach my $sline (sort NUMERICALLY (keys %{$session_list->{$SIDSN}})) {
      $SID = $session_list->{$SIDSN}->{$sline}->{'SID'};
      $SN = $session_list->{$SIDSN}->{$sline}->{'SN'};
      last;
    }
    #
    &WRITE_INFO("Session SID:", $SID);
    #
    &WRITE_INFO("Session Serial#:", $SN);
  }
  #
  my $first_line = 0;
  my $intvl_total = 0;
  my ($session_start, $time_start, $time_end) = (0, 0, 0);
  foreach my $sline (sort NUMERICALLY (keys %{$session_list->{$SIDSN}})) {
    if ( $first_line == 0 ) {
      print "\nConnection Summary\n\n";
    }
    $first_line++;
    $session_start = $session_list->{$SIDSN}->{$sline}->{'start_time'};
    $time_start = $session_list->{$SIDSN}->{$sline}->{'intvl_start'};
    $time_end = $session_list->{$SIDSN}->{$sline}->{'intvl_end'};
    $intvl_total += ($time_end - $time_start);
    #
    &WRITE_INFO("Session start:", $session_start);
    #
    &WRITE_INFO("Interval start (t0)", sprintf("%.0f",$time_start));
    #
    &WRITE_INFO("Interval end (t1)", sprintf("%.0f",$time_end));
    print "\n";
  }
  #
  &WRITE_INFO("Interval duration", sprintf($PRECISION, ($intvl_total * $e_factor)) . "s");
  #
  &WRITE_INFO("SQL cursors found", &COMMIFY($num_sql));
  #
  if ($ohtml == 1) {
    print "</pre>\n";
  }
  else {
    print "\n";
  }
  #
  # Write separator
  if ($ohtml == 1) {
    $~ = "SEPARATOR_LINE_HTML";
  }
  else {
    $~ = "SEPARATOR_LINE";
  }
  write;
  #
  ###############################################################################
  #
  # Process each option
  #
  ###############################################################################
  #
  # print "Processing stat summary: ", scalar localtime,"\n";
  #
  &PR_STAT_SUM;
  #
  # print "Processing event summary: ", scalar localtime,"\n";
  #
  &PR_EVENT_SUM($intvl_total);
}
#
###############################################################################
#
# Begin of main program
#
###############################################################################
#
# Global Declarations
#
# Set constants
#
# All Oracle versions prior to 9i report in centiseconds (.01),
# so set this as the default if the version can't be determined
# from the trace file.
our $c_factor = 0.01;  # CPU time (100ths)
our $e_factor = 0.01;  # Elapsed time (100ths)
our $w_factor = 0.01;  # Wait time (100ths)
#
our $PRECISION = "%.2f";  # Set CPU, elapsed, and aggregated time format precision
#
# Set variables
#
our $trcfile_lines = 0; # Global
our $num_sessions = 0; # Global
our $ora_ver_str="UNKNOWN";
our $node_name="UNKNOWN";
our $instance_name="UNKNOWN";
#
our ($time_start, $time_end, $time_offset) = (0, 0, 0);
our $num_sql = 0;
our $nlines = 0;
our $num_connections = 0;
our $truncated = 0; # Global, 0 - full trace file; 1 - truncated trace file
our $trunc_size = 0; # Global, if truncated then size of file in bytes
our $ohtml=0;
#
our %session_list = ();
#
my $obanner=1; # Set to print banner on command line
my $num_args=0;
my $otext=0;
my $trcfile;
#
###############################################################################
#
# Process possible switches
#
###############################################################################
#
#
# Display version information
#
&VERSION($obanner);
#
if ( @ARGV ) {
  while (@ARGV and $ARGV[0] =~ /^-/) {
    $_ = shift;
    $num_args++;
    if (($_ eq '-help') || ($_ eq '-?')) {
      &HELP;
      die "\n";    
    }
    elsif ($_ eq '-html') {
      $ohtml=1;
    }
    elsif ($_ eq '-text') {
      $otext=1;
    }
    else {
      print "Invalid option: $_\n\n";
      &HELP;
      die "\n";
    }
  }
  #
  if ( $num_args == 0 ) {
    # Set default options
    $ohtml = 1;
    $otext = 0;
    print "No options specified, using -html\n\n";
  }
  elsif ( ($ohtml == 1) && ($otext == 1) ) {
    print "-html is not valid with the -text option\n\n";
    &HELP;
    die "\n";
  }
  else {
    print "Options specified:";
    if ($ohtml == 1) {
      print " -html\n";
    }
    if ($otext == 1) {
      print " -text\n";
    }
    print "\n";
  }
  #
  # Check for trace file
  #
  $trcfile = shift(@ARGV);
  if (defined $trcfile) { 
    if (-e $trcfile) {
      print "Processing trace file: '$trcfile'\n\n";
    }
    else {
      print "File specified does not exist\n\n";
      &HELP;
      die "\n";
    }
  }
  else {
    print "No file to process\n\n";
    &HELP;
    die "\n";
  }
}
else {
  print "No options or file specified\n\n";
  &HELP;
  die "\n";
}
#
# Set output file
#
my $outfile;
if ( $trcfile =~ m/(^\w*)\.*/ ) {
  #
  if ($ohtml == 1) {
    $outfile = "$1.html";
  }
  else {
    $outfile = "$1.txt";
  }
  #
  open OUTFILE, ">$outfile"
    or die "$0: can't create output file: $!";
  #
  print "Output file: '$outfile'\n\n";
  #
  select OUTFILE;
}
else {
  print "Can't determine file name\n";
  die "\n";
}
#
###############################################################################
#
# Print trace file header
#
###############################################################################
#
if ($ohtml == 1) {
  print "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\">\n";
  print "<html>\n";
  print "<head>\n";
  print "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n";
  #
  if ( $obanner == 1 ) {
    print "<title>AppsDBA Event 10046 Interval Resource Profile for \'$trcfile\'</title>\n";
  }
  else {
    print "<title>Event 10046 Interval Resource Profile for \'$trcfile\'</title>\n";
  }
  print "<STYLE TYPE=\"text/css\">\n";
  print "<!--\n";
  #
  print "html {font-size: 10pt;font-family: veranda,helvetica,arial,sans-serif;}\n";
  print "a:link, a:visited {text-decoration: underline;}\n";
  print "a:link    { color: blue; }\n";
  print "a:active  { color: red;  }\n";
  print "a:hover   { background: yellow; color: black; }\n";
  #
  print "h1:before {content: counter(chapter) ". ";counter-reset: section;\n";
  print " counter-increment: chapter;}\n";
  print "h2:before {content: counter(chapter) "." counter(section);\n";
  print " counter-reset: subsection;counter-increment: section;}\n";
  print "h3:before {content: counter(chapter)"."counter(section)"."counter(subsection);\n";
  print " counter-reset: subsection;}\n";
  print "h1,h2,h3,h4 {text-align: left;color: maroon;}\n";
  print "h1 {font-size: 140%;font-weight: bold;font-style: normal;line-height: 1.2;\n";
  print " margin: 2ex 0em 1ex 0em;}\n";
  print "h2 {font-size: 120%;font-weight: bold;font-style: normal;line-height: 1.1;\n";
  print " margin: 2ex 0em 1ex 0em;}\n";
  print "h3 {font-size: 100%;font-weight: bold;font-style: normal;line-height: 1.1;\n";
  print " margin: 2ex 0em 1ex 0em;}\n";
  print "p {margin: 1ex 0em 1ex 0em;}\n";
  print "pre.flush {font-size: 90%;font-family: courier new, courier, monospace;\n";
  print " font-weight: normal;margin: 1ex 0em 1ex 0em;}\n";
  print "pre {font-size: 90%;font-family: courier new, courier, monospace;\n";
  print " font-weight: normal;margin: 1ex 0em 1ex 2em;}\n";
  print "blockquote {margin: 1ex 0em 1ex 2em;}\n";
  #
  print ".small  { font-size: 70%; }\n";
  print ".size8  { font-size:  8pt; }\n";
  print ".size9  { font-size:  9pt; }\n";
  print ".size10 { font-size: 10pt; }\n";
  print ".red    { color: red; }\n";
  print ".maroon { color: maroon; }\n";
  print ".arial {font-family: arial, sans-serif;}\n";
  print "input {font-size: 100%;}\n";
  #
  print "-->\n";
  print "</STYLE>\n";
  print "</head>\n";
  print "<body>\n";
  #
  if ( $obanner == 1 ) {
    print "<a href=\"http://www.appsdba.com\">\n";
    print "<img src=\"http://www.appsdba.com/gifs/appsdba_cons.gif\" width=\"242\" height=\"50\" border=\"0\" \n";
    print "alt=\"AppsDBA Consulting - www.appsdba.com\" /></a>\n";
  }
}
#
# Display version information
#
&VERSION($obanner);
#
if ($ohtml == 1) {
  print "<pre class=flush>\n";
}
#
print "Processing trace file: '$trcfile'\n\n";
#
print "Run date: ", scalar localtime,"\n";
#
if ($ohtml == 1) {
  print "</pre>\n";
}
else {
  print "\n";
}
#
###############################################################################
#
# Process the trace file summary
#
###############################################################################
#
#
# Send status info to STDOUT
#
print STDOUT "\n*********************\n";
print STDOUT "Begin Pass 1\n";
print STDOUT "*********************\n\n";
#
&PR_TRC_SUMMARY($trcfile);
#
###############################################################################
#
# Print trace file summary information
#
###############################################################################
#
if ($ohtml == 1) {
  print "<h2>TRACE INFORMATION</h2>\n";
  print "<pre>\n";
}
else {
  print "TRACE INFORMATION\n\n";
}
#
$~ = "INFO_OUT";
#
&WRITE_INFO("Node Name", $node_name);
#
&WRITE_INFO("Instance Name", $instance_name);
#
&WRITE_INFO("Database Version", $ora_ver_str);
#
&WRITE_INFO("Trace file", $trcfile);
#
&WRITE_INFO("Trace file lines", $trcfile_lines);
#
&WRITE_INFO("Distinct sessions", &COMMIFY($num_sessions));
#
&WRITE_INFO("Number of connections", &COMMIFY($num_connections));
#
if ( $truncated == 1 ) {
  print "\n*** Trace file was truncated at $trunc_size bytes ***\n";
}
#
print "\n";
#
if ($ohtml == 1) {
  print "</pre>\n";
}
#
# Write separator
if ($ohtml == 1) {
  $~ = "SEPARATOR_LINE_HTML";
}
else {
  $~ = "SEPARATOR_LINE";
}
write;
#
# Send status info to STDOUT
#
print STDOUT "Number of trace file lines: $trcfile_lines\n";
print STDOUT "Number of distinct sessions: $num_sessions\n";
#
###############################################################################
#
# Process the trace file session details
#
###############################################################################
#
# Send status info to STDOUT
#
print STDOUT "\n*********************\n";
print STDOUT "Begin Pass 2\n";
print STDOUT "*********************\n\n";
#
my $session_list = \%session_list;
#
if (keys(%$session_list)) {
  foreach my $SIDSN (keys %$session_list) {
    #
    &PR_TRC_DETAIL($trcfile, $SIDSN);
    #
    &PR_PRT_DETAIL($SIDSN);
  }
}
else {
  &PR_TRC_DETAIL($trcfile, 0);
  &PR_PRT_DETAIL(0);
}
#
if ($ohtml == 1) {
  print "<pre class=flush>\n";
}
#
print "End of script: ", scalar localtime,"\n";
#
if ($ohtml == 1) {
  print "</pre>\n";
}
#
if ($ohtml == 1) {
  print "</body>\n";
  print "</html>\n";
}



__END__

=head1 NAME

Resource Profiler - creates an interval resource profile from an Oracle
event 10046 level 8 or higher trace file


=head1 SYNOPSIS

resource [-html|-text] <trace file>


=head1 DESCRIPTION

B<resource> will parse an Oracle event 10046 level 8 or higher trace file
and create a resource profile for each session found in the trace file.
It will also produce tkprof-like statement totals sections for all recursive
and non-recursive statements. If nothing else, this helps in comparisons
of accuracy between tkprof and B<resource>. In general, you will find that 
B<resource> is more accurate than tkprof.

B<resource> supports all versions of Oracle trace files from Oracle7.

*** There are no warranties or guarantees!  Use at your own risk! ***

=head2 Options

=over 2

=item B<-text>

B<resource> supports text file output. The file name produced is 
<trace file>.txt. This is the default.

=item B<-html>

B<resource> also supports W3CW 4.01 HTML compatible html output. The 
file produced is <trace file>.html.

=back


=head1 AUTHOR

Andy Rivenes (andy@appsdba.com)


=head1 BUGS

No known bugs.


=head1 SEE ALSO

Oracle Note: 39817.1, Interpreting Raw SQL_TRACE and DBMS_SUPPORT.START_TRACE
output, Oracle Corporation, Last Revision Date: 12-NOV-2003

=head2 Additional Information

http://www.appsdba.com


=head1 COPYRIGHT

Copyright (c) 2004 by AppsDBA Consulting. All Rights Reserved.

