#!/usr/local/bin/perl -w
#
print "<HTML>\n<HEAD><TITLE>DOJV INDEX Dead Space</TITLE>\n";
print "<H1 align=center>DOJV INDEX Dead Space</H1>\n";  ;
$x=`date`;
chomp($x);
print "<H3><B>".$x."</B></H3>\n";
print "<CENTER><A HREF=\"../monitor.htm\">Back</A>\n";
print "<TABLE width=80% border=1>\n";
print "<TR><TH>OWNER.INDEX</TH><TH>Used</TH><TH>Deleted</TH><TH>Dead/Total Ratio</TH>\n";
$x=`grep "^#" viw1.log | sort +3n -r > viw.rm0`;
open(OLD,"viw.rm0");
while (<OLD>) {
   if (/^#/) {$_=substr($_,1)}
   chomp;
   @words=split(' ');
   $w0=$words[0];
   $w1=$words[1];
   $w2=$words[2];
   $w3=$words[3];
   if ($w3 == 0) {next}
   print "<TR><TD>$w0</TD><TD align=right>$w1</TD><TD align=right>$w2</TD>";
   print "<TD align=right>";
   printf ("%6.3f",$w3);
   print "</TD>\n";
}
close(OLD);
print "</TABLE><A HREF=\"../monitor.htm\">Back</A></CENTER>\n</BODY>\n</HTML>\n";
