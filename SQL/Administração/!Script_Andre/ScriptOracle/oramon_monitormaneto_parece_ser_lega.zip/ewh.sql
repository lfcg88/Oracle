connect internal
set charwidth 20
spool ewh
select FREE.tablespace_name
      ,FREE.Maxbyte/1024 MAX_FREE
      ,NEXT.owner
      ,NEXT.segment_type
      ,NEXT.segment_name
      ,next_extent/1024 NEXT_EXTENT
      ,trunc(FREE.Maxbyte/NEXT.next_extent) CNT_NEXTS
from ( select owner,segment_type,segment_name,tablespace_name,next_extent
       from   sys.DBA_SEGMENTS                    ) NEXT
    ,( select tablespace_name,max(bytes) Maxbyte
       from   sys.DBA_FREE_SPACE
       group by tablespace_name                   ) FREE
where FREE.tablespace_name  = NEXT.tablespace_name
and   NEXT.next_extent * 2 >= FREE.Maxbyte
order by 7,tablespace_name,owner,segment_type,segment_name;
spool off
