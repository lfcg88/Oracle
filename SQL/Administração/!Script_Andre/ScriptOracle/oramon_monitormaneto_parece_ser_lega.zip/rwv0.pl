#!/usr/local/bin/perl -w
#
$k=0;
open(OLD,"rwm.raw");
while (<OLD>) {
   $k++;
}
close(OLD);
$l=0;
open(OLD,"rwm.raw");
while (<OLD>) {
   $l++;
   if ($l > ($k - 490)) {
      $c=substr($_,19,1);
      if ($c == 0) {print}
      if ($c == 5) {print}
   }
}
close(OLD);
