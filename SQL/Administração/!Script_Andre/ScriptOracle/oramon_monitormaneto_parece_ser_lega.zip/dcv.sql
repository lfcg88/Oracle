connect internal
spool dcv
set numwidth  12
set charwidth 20
select 'DOJV'||to_char(sysdate,'YYYY/MM/DD-HH24:MI'),  sum(gets), sum(getmisses)
 from v$rowcache;
spool off
exit
