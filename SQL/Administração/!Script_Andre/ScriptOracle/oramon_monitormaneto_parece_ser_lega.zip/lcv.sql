connect internal
spool lcv
set numwidth  12
set charwidth 20
select 'DOJV'||to_char(sysdate,'YYYY/MM/DD-HH24:MI'),  sum(pins), sum(reloads)  
 from v$librarycache;
spool off
exit
