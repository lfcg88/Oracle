connect internal
spool rwm
set numwidth  12
set charwidth 20
select 'DOJV'||to_char(sysdate,'YYYY/MM/DD-HH24:MI'),  sum(phyrds), sum(phywrts), sum(phyblkrd)
 from v$filestat;
spool off
exit
