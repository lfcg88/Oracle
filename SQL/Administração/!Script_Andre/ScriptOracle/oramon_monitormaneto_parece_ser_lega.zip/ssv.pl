#!/usr/local/bin/perl -w
#
$x=`date +%Y/%m/%e-%H:%M`;
chop($x);
$x =~ s/ /0/;
$k=0;
open (OLD,'ssv.log');
while (<OLD>) {
  $k++;
  if ($k < 3) {next}
  if (/select/) {last}
  chop;
  @words=split(' ');
  $w0=$words[0];
  $w1=$words[1];
  $ss{$w0}=$w1;
}
close(OLD);
open(NEW,">>dev.raw");
printf(NEW "%s%12d%12d\n",$x,$ss{9},$ss{39});
close NEW;
open(NEW,">>srv.raw");
printf(NEW "%s%12d%12d\n",$x,$ss{139},$ss{140});
close NEW;
open(NEW,">>tsv.raw");
printf(NEW "%s%12d%12d\n",$x,$ss{118},$ss{119});
close NEW;
