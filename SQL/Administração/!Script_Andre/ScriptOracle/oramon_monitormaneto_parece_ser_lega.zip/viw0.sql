connect internal
spool viw0
select owner, index_name
 from dba_indexes
  where owner='VCIN'
    and not (index_name like 'SYS%');
spool off
