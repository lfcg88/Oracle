connect internal
set charwidth 20
spool fsh
select * from dba_free_space
 where not ((tablespace_name = 'TEMP')
        or  (tablespace_name = 'SYSTEM')
        or  (tablespace_name like 'RBS%'))
  order by 1,4;
spool off
