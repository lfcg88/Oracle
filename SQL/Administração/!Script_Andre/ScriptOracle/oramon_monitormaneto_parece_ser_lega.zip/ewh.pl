#!/usr/local/bin/perl -w
#
print "<HTML>\n<HEAD><TITLE>DOJV Extents*2 > Free Space</TITLE>\n";
print "<H1 align=center>DOJV Extents*2 > Free Space</H1>\n";
print "<CENTER><A HREF=\"../monitor.htm\">Back</A></CENTER>\n";
print "<PRE>\n";
print "<H3><B>".`date`."</B></H3>\n";
open(OLD,"ewh.log");
while (<OLD>) {
   chop;
   $s0='';
   $s1='';
   if (substr($_,length($_)-2,2) eq " 0") {$s0='<B><FONT COLOR="RED">'; $s1="</FONT></B>"}
   print $s0.$_.$s1."\n";
}
close(OLD);
print "</PRE>\n";
print "<CENTER><A HREF=\"../monitor.htm\">Back</A></CENTER>\n</BODY>\n</HTML>\n";
