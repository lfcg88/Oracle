#!/usr/local/bin/perl -w
#
$k=0;
open(OLD,"lcv.raw");
while (<OLD>) {
   $k++;
}
close(OLD);
$l=0;
open(OLD,"lcv.raw");
while (<OLD>) {
   $l++;
   if ($l > ($k - 289)) {
      print;
   }
}
close(OLD);
