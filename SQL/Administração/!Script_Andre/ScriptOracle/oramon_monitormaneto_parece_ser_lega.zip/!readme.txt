Included herein are the complete set of scripts for the instance DOJV.

To impliment in your environment consider the following:

  * Change DOJV to your instance name
  * Change ftp target & password
  * Change $ORACLE... variables where appropriate
  * Change #!/usr/local/bin/perl where appropriate

I think I've included all appropriate files, if not let me know!

The naming convention is:

   xxy - element

   xx  = what
     y = how often

    rw = read writes

    lc = library cache
    dc = dictionary cache

   ssv - (creates he following from v$sysstat)
    de = data cache effectiveness
    ts = table scans
    sr = sorts memory/disk

    te = temp extent allocation
    rb = rollback extents
    ew = extent warning
    fs = free space
    me = max extent report

    vi = validate index - dead space

     m =  1 minute
     v =  5 minutes
     h = 60 minutes
     d =  1 day
     w =  1 week
