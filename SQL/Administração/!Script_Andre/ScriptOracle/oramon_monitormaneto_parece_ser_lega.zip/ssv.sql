connect internal
set numwidth  16
spool ssv
select statistic#, sum(value) from v$sysstat group by statistic#;
spool off
exit
