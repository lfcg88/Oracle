#!/usr/local/bin/perl -w
#
print "<HTML>\n<HEAD><TITLE>DOJV MAX(EXTENT) > 2</TITLE>\n";
print "<H1 align=center>DOJV MAX(EXTENT) > 2</H1>\n";
print "<CENTER><A HREF=\"../monitor.htm\">Back</A></CENTER>\n";
print "<PRE>\n";
print "<H3><B>".`date`."</B></H3>\n";
open(OLD,"meh.log");
while (<OLD>) {
   print;
}
close(OLD);
print "</PRE>\n";
print "<CENTER><A HREF=\"../monitor.htm\">Back</A></CENTER>\n</BODY>\n</HTML>\n";
