connect internal
set charwidth 32
spool meh
select substr(owner,1,6) owner, segment_name, segment_type, tablespace_name, max(extent_id)
 from dba_extents
  where not owner= 'SYS'
   group by substr(owner,1,6), segment_name, segment_type, tablespace_name
    having max(extent_id) > 2
     order by 5 desc,1,2,3,4;
spool off
