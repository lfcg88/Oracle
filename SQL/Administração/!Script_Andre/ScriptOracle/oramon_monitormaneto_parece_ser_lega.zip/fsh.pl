#!/usr/local/bin/perl -w
#
print "<HTML>\n<HEAD><TITLE>DOJV Free Space</TITLE>\n";
print "<H1 align=center>DOJV Free Space</H1>\n";
print "<CENTER><A HREF=\"../monitor.htm\">Back</A></CENTER>\n";
print "<PRE>\n";
print "<H3><B>".`date`."</B></H3>\n";
open(OLD,"fsh.log");
while (<OLD>) {
   print;
}
close(OLD);
print "</PRE>\n";
print "<CENTER><A HREF=\"../monitor.htm\">Back</A></CENTER>\n</BODY>\n</HTML>\n";
