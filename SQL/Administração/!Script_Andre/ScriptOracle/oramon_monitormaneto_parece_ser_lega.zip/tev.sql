connect internal
spool tev
set numwidth  12
set charwidth 20
select 'DOJV'||to_char(sysdate,'YYYY/MM/DD-HH24:MI'),  sum(extents)
 from dba_segments
  where tablespace_name='TEMP';
spool off
exit
