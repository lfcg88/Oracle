#!/usr/local/bin/perl -w
#
print "connect internal\n";
print "spool viw1.log\n";
open(OLD,"viw0.log");
while (<OLD>) {
   $k++;
   if ($k<3) {next}
   if (/selected/) {last}
   chomp;
   @words=split(' ');
   $w0=$words[0];
   $w1=$words[1];
   print "validate index ".$w0.".".$w1.";\n";
   print "select '#$w0.'||name, LF_ROWS_LEN, DEL_LF_ROWS_LEN, ";
   print "(DEL_LF_ROWS_LEN*100) / (LF_ROWS_LEN+DEL_LF_ROWS_LEN+1) from index_stats;\n";
}
close(OLD);
print "spool off\n";
