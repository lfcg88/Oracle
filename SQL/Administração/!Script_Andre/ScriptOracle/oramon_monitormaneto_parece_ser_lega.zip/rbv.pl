#!/usr/local/bin/perl -w
#
print "<HTML>\n<HEAD><TITLE>DOJV ROLLBACK Extents -Last 8 Hours</TITLE>\n";
print "<H1 align=center>DOJV ROLLBACK Extents -Last 8 Hours</H1>\n";
print "<H6 align=center> <font color=\"#FF0000\">?? relaod ??</font></H6>\n";
print "<CENTER><A HREF=\"../monitor.htm\">Back</A>\n";
print "<TABLE width=50% border=1>\n";
print "<TR><TH>DATE - TIME</TH><TH>Allocated extents</TH>\n";
open(OLD,"rbv.rm1");
while (<OLD>) {
   chop;
   @words=split(' ');
   $w0=substr($words[0],4);
   $w1=$words[1];
   print "<TR><TD>$w0</TD><TD align=right>$w1</TD>\n";
}
close(OLD);
print "</TABLE><A HREF=\"../monitor.htm\">Back</A></CENTER>\n</BODY>\n</HTML>\n";
