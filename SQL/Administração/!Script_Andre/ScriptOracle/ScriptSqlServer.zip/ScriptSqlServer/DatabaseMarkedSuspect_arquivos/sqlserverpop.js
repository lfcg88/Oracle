<!-- hide from JavaScript-challenged browsers
function openWindow(url) {
	popupWin = window.open(url,'new_page','width=400,height=400')
}
function openWindow2(url) {
	popupWin = window.open(url,'new_page','width=400,height=450')
}
function openWindow3(url) {
	popupWin = window.open(url,'new_page','width=400,height=450,scrollbars=yes')
}
function openWindow4(url) {
	popupWin = window.open(url,'new_page','width=400,height=525')
}
function openWindow5(url) {
	popupWin = window.open(url,'new_page','width=450,height=525,scrollbars=yes,toolbars=yes,menubar=yes,resizable=yes')
}
function openWindow6(url) {
	popupWin = window.open(url,'new_page','width=500,height=450,scrollbars=yes')
}
function openWindowHelp(url) {
	popupWin = window.open(url,'new_page','width=470,height=200,scrollbars=yes')
}
// done hiding -->
