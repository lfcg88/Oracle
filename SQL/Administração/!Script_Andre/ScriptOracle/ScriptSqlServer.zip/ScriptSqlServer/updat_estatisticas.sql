create procedure sp__updatestats
as
/*********************************************************************/
/* Stored Procedure: sp__updatestats                                 */
/* Creation Date:    6/12/98                                         */
/* Copyright:        Michael R. Hotek                                */
/* Written by: Michael Hotek					     */
/*                                                                   */
/* Purpose: This procedure runs update statistics for all databases  */
/*          on a periodic schedule.                                  */
/*                                                                   */
/* Input Parameters: None                                            */
/*                                                                   */
/* Output Parameters: None                                           */
/*                                                                   */
/* Usage:                                                            */
/*   exec sp__updatestats                                            */
/*                                                                   */
/* Local Variables:                                                  */
/*  @command        The command to execute                           */
/*  @database       The name to the database to process              */
/*  @table          The name of the table to process                 */
/*  @fetch_inner    Controls the inner cursor                        */
/*  @fetch_outer    Controls the outer cursor                        */
/*                                                                   */
/* Return Status: None                                               */
/*                                                                   */
/* Called By: SQL Server task                                        */
/*                                                                   */
/* Calls: None                                                       */
/*                                                                   */
/* Data Modifications: None                                          */
/*                                                                   */
/* Updates:                                                          */
/*   Date     Author      Purpose                                    */
/*   6/12/98  Mike Hotek  Created                                    */
/*   6/15/98  Mike Hotek  Added temp table for row counts            */
/*   6/15/98  Mike Hotek  Accounted for dbs that update stats can't  */
/*                          run in (read only, offline, etc.)        */
/*   12/09/99 Mike Hotek  Removed unnecessary tracking               */
/*                                                                   */
/*********************************************************************/
declare @command        varchar(255),
        @database       varchar(30),
        @table          varchar(30),
        @fetch_inner    int,
        @fetch_outer    int

--Temp table to process new tables
create table #tables
(name   varchar(30))

--Declare cursor to loop over all databases
--A status of 1024 is a read only database and as such update stats can not be run on it.
declare curdb cursor for select name from master..sysdatabases where name not in ('master', 'model', 'tempdb', 'msdb', 'pubs','distribution')
    and status & 32 != 32 and status & 64 != 64 and status & 128 != 128 and status & 256 != 256 and status & 512 != 512 and status & 1024 != 1024
    and status & 4096 != 4096

print 'Opening database cursor'
--Open cursor and perform initial fetch
open curdb
fetch curdb into @database

--Save fetch status to local variable
select @fetch_outer = @@fetch_status

while @fetch_outer = 0
begin
    --Build command to select all user tables from the first database
    --A UID = 1 filters out any tables not created by the dbo.  This is because I consider tables created
    --by any user to be temporary tables and as such should not have update stats run on them
    select @command = 'select name from ' + @database + "..sysobjects where type = 'U' and uid = 1"

    select 'Inserting into temp table from ' + @database
    --Insert the names into the temp table for processing
    insert into #tables exec(@command)

    --Declare inner cursor to process each table
    declare curtables cursor for select name from #tables

    --Open and perform initial fetch
    select 'Opening table cursor on database: ' + @database
    open curtables
    fetch curtables into @table

    --Save fetch status into local variable
    select @fetch_inner = @@fetch_status

    while @fetch_inner = 0
    begin
            --Create update stats command and execute
            select 'Updating stats on ' + @database + '..' + @table
            select @command = 'update statistics ' + @database + '..' + @table
            exec(@command)

           --Fetch next table to process
           print 'Fetching next table'
           fetch curtables into @table

           --Save fetch status into local variable
           select @fetch_inner = @@fetch_status
    end

    --Cleanup temp table and cursor
    print 'Truncating temp table and deallocating tables cursor'
    truncate table #tables
    close curtables
    deallocate curtables

    --Fetch next database
    print 'Fetching the next database'
    fetch curdb into @database

    --Save fetch status to local variable
    select @fetch_outer = @@fetch_status
end
--Clean up
print 'Final cleanup'
close curdb
deallocate curdb
drop table #tables
return
go
