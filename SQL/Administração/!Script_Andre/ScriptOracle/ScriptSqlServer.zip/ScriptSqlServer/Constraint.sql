
select * from pubs.INFORMATION_SCHEMA.TABLE_CONSTRAINTS



Code Example 1:
Just enter the name of the table in place of "x" and this piece of T-SQL will give you the forign key constraints defined on that table, the name of the child and parent tables and also the names of the columns involved for the child and the parent tables. 

select 	object_name(constid) as constraint_name,
       	object_name(fkeyid) as table_name, 
        col_name(fkeyid, fkey) as column_name,
	object_name(rkeyid) as referenced_table_name,
   	col_name(rkeyid, rkey) as referenced_column_name
from sysforeignkeys
where object_name(fkeyid) = x
order by constraint_name, table_name, referenced_table_name,  keyno

Code Example 2:
Subsitute x with the name of the table and you will get the name of the constraints defined on the table (Primary Key as well as the Foreign key constraints), the names of the columns involved and the position of the columns in the constraint, for example, which column is number 1 in the case of a covered primary key.

select 	constraint_name,
	column_name,
	ordinal_position
from information_schema.key_column_usage
where constraint_catalog = db_name()
and table_name = x
order by constraint_name, ordinal_position
