if (global_article.length != 0)
  {
  var article = new Array(
  new sa("http://www.moreover.com' TARGET='_self","News powered by Moreover Technologies","powered by Moreover.com","text"," "," "," ",global_article[0].harvest_time," "," ")
  )
  global_article[global_article.length] = article[0]; 
  }
moreover_text = 1;
