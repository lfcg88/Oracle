<!-- Keylime Software  4.1 13/07/2000
var kl_siteID = "578";
var kl_tagProtocol = "";
var kl_akamaipath = "a1944.g.akamai.net/f/1944/1482/8h/";
if (location.protocol == "https:")
{
  kl_tagProtocol = "s";
  kl_akamaipath = "a248.e.akamai.net/f/248/1482/8h/"
}
var kl_tag = "<SCR" + "IPT LANGUAGE='JavaScript' " +
  "SRC=http" + kl_tagProtocol + "://" + kl_akamaipath +
 "stats.klsoft.com/akamai/Site_" + kl_siteID + kl_tagProtocol + "_ePulse.js" +
  "></SCR" + "IPT>";
document.write(kl_tag);
// -->
