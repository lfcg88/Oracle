
create table project
(project_ID number primary key,
 teamid number,
 job varchar2(100),
 status varchar2(20) check (status in ('ACTIVE', 'INACTIVE'))
);


create UNIQUE index
job_unique_in_teamid on project
( case when status = 'ACTIVE' then teamid else null end,
  case when status = 'ACTIVE' then job    else null end
)
/


insert into project(project_id,teamid,job,status)
values( 1, 10, 'a', 'ACTIVE' );


insert into project(project_id,teamid,job,status)
values( 2, 10, 'a', 'ACTIVE' );


update project
   set status = 'INACTIVE'
  where project_id = 1
    and teamid = 10
    and status = 'ACTIVE';


insert into project(project_id,teamid,job,status)
values( 2, 10, 'a', 'ACTIVE' );



