

alter tablespace users offline;

alter tablespace users online;

alter session set sql_trace=true;

begin
    for x in ( select username from all_users )
    loop
        for i in 1 .. 10
        loop
            for y in ( select a.username,
                              a.temporary_tablespace,
                              b.object_name ,
                              b.object_type /* CLUSTER */
                         from user_info a, users_objects b
                        where a.username = b.owner
                          and a.username = X.USERNAME )
            loop
                null;
            end loop;
        end loop;
    end loop;
end;
/

alter session set sql_trace=false;


create index user_info_username_idx on user_info_heap(username);
 
create index user_objects_owner_idx on
users_objects_heap(owner);



