

create table t1
as
select * from dba_objects;

insert /*+ append */ into t1 select * from t1;

commit;

insert /*+ append */ into t1 select * from t1;

commit;

create index uncompressed_idx
on t1( owner,object_type,object_name );

analyze table t1 compute statistics
for table
for all indexes
for all indexed columns;


create table t2
as
select * from t1;

create index compressed_idx
on t2( owner,object_type,object_name )
COMPRESS 3;

analyze table t2 compute statistics
for table
for all indexes
for all indexed columns;


analyze index uncompressed_idx validate structure;
create table index_stats_copy as select * from index_stats;

analyze index compressed_idx validate structure;

insert into index_stats_copy select * from index_stats;


variable x refcursor
declare
    l_stmt long;
begin
    for x in ( select '''' || column_name || '''' quoted,
                      column_name
                 from user_tab_columns
                where table_name = 'INDEX_STATS_COPY'
                  and column_name not in
                      ('NAME','PARTITION_NAME') )
    loop
        l_stmt := l_stmt || ' select ' || x.quoted || ' name,
                    max(decode(name,''UNCOMPRESSED_IDX'',' ||
                    x.column_name || ',null)) uncompressed,
                    max(decode(name,''UNCOMPRESSED_IDX'',
                        to_number(null),' || x.column_name ||
                        ')) compressed
                    from index_stats_copy union all';
    end loop;
    l_stmt :=
    'select name, uncompressed, compressed,
            uncompressed-compressed diff,
            decode(uncompressed,0,
               to_number(null),
               round(compressed/uncompressed*100,2)) pct
       from ( ' ||
         substr( l_stmt, 1,
                 length(l_stmt)-length(' union all') ) ||
            ') order by name';
    open :x for l_stmt;
end;
/


alter session set sql_trace=true;

begin
    for x in ( select * from t1 )
    loop
        for y in ( select *
                     from t1
                    where owner = x.owner
                      and object_name = x.object_name
                      and object_type = x.object_type )
        loop
            null;
        end loop;
    end loop;
    for x in ( select * from t2 )
    loop
        for y in ( select *
                     from t2
                    where owner = x.owner
                      and object_name = x.object_name
                      and object_type = x.object_type )
        loop
            null;
        end loop;
    end loop;
end;
/

