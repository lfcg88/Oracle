
create or replace trigger xxx
after delete or update or insert on emp
declare
begin
  
 for irec in (select deptno, count(*) emps
           from emp
           group by deptno
           having count(*) <3
               or count(*) >8)
 loop
     RAISE_APPLICATION_ERROR(-20000, 'Department '
     ||irec.deptno || ' has '||irec.emps||' employees!');
 end loop;
end;
/



select deptno, count(*),
       case when count(*) NOT between 3 and 8 then '<<<===='
            else null
        end
  from emp
 group by deptno
/
delete from emp where empno in ( 7369, 7566, 7788 );

delete from emp where empno in ( 7369, 7566 );

prompt do the other delete in another session
pause

select deptno, count(*),
       case when count(*) NOT between 3 and 8 then '<<<===='
            else null
        end
  from emp
 group by deptno
/

