
create table association
( primary_key_table1,
  primary_key_table2,
  <possibly some columns pertaining to the relationship> );

create index association_idx1 on 
association(primary_key_table1, primary_key_table2 );

create index association_idx2 on 
association(primary_key_table2, primary_key_table1 );              


create table association 
( primary_key_table1,
  primary_key_table2,
  <possibly some columns pertaining to the relationship>,
  primary key(primary_key_table1,primary_key_table2) )
organization index;

create index association_idx on 
association(primary_key_table2);


create table t
( a int,
  b int,
  primary key (a,b)
)
organization index;

create index t_idx on t(b);

set autotrace traceonly explain
select a, b from t where b = 55;


create table iot
( username varchar2(30),
  document_name varchar2(30),
  other_data       char(100),
  constraint iot_pk
  primary key (username,document_name)
)
organization index
/

create table heap
( username varchar2(30),
  document_name varchar2(30),
  other_data       char(100),
  constraint heap_pk
  primary key (username,document_name)
)
/


begin
    for i in 1 .. 100
    loop
        for x in ( select username
                     from all_users )
        loop
            insert into heap
            (username,document_name,other_data)
            values
            ( x.username, x.username || '_' || i, 'x' );

            insert into iot
            (username,document_name,other_data)
            values
            ( x.username, x.username || '_' || i, 'x' );
        end loop;
    end loop;
    commit;
end;
/


alter session set sql_trace=true;

declare
    type array is table of varchar2(100);
    l_array1 array;
    l_array2 array;
    l_array3 array;
begin
for i in 1 .. 10
loop
    for x in (select username from all_users)
    loop
        for y in ( select * from heap single_row
                    where username = x.username )
        loop
            null;
        end loop;
        for y in ( select * from iot single_row
                    where username = x.username )
        loop
            null;
        end loop;
        select * bulk collect
          into l_array1, l_array2, l_array2
          from heap bulk_collect
         where username = x.username;
        select * bulk collect
          into l_array1, l_array2, l_array2
          from iot bulk_collect
         where username = x.username;
    end loop;
end loop;
end;
/

