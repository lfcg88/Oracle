

create or replace directory data_dir as '/tmp/'
/


create table external_table
(EMPNO NUMBER(4) ,
 ENAME VARCHAR2(10),
 JOB VARCHAR2(9),
 MGR NUMBER(4),
 HIREDATE DATE,
 SAL NUMBER(7, 2),
 COMM NUMBER(7, 2),
 DEPTNO NUMBER(2)
)
ORGANIZATION EXTERNAL
( type oracle_loader
  default directory data_dir
  access parameters
  ( fields terminated by ',' )
  location ('emp.dat')
)
/


host flat scott/tiger emp > /tmp/emp.dat
host head /tmp/emp.dat

select ename, job, hiredate
  from external_table
/

delete from emp where mod(empno,2) = 1
/

update emp set sal = sal/2
/

merge into EMP e1
using EXTERNAL_TABLE e2
on ( e2.empno = e1.empno )
when matched then
 update set e1.sal = e2.sal
when not matched then
 insert (empno, ename, job, mgr, hiredate, sal, comm, deptno)
 values ( e2.empno, e2.ename, e2.job, 
          e2.mgr, e2.hiredate, e2.sal, e2.comm, e2.deptno )
/


