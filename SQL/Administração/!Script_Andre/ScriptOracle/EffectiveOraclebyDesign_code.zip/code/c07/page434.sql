
create table uncompressed
pctfree 0
as
select *
  from dba_objects
 order by owner, object_type, object_name;

analyze table uncompressed
compute statistics
for table;

create table compressed
COMPRESS
as
select *
  from uncompressed
 order by owner, object_type, object_name;

analyze table compressed
compute statistics
for table;

select cblks comp_blks, uncblks uncomp_blks,
       round(cblks/uncblks*100,2) pct
  from (
select max(decode(table_name,'COMPRESSED',blocks,null)) cblks,
  max(decode(table_name,'UNCOMPRESSED',blocks,null)) uncblks
  from user_tables
 where table_name in ( 'COMPRESSED', 'UNCOMPRESSED' )
       )
/

create table compressed
COMPRESS
as
select *
  from uncompressed
 order by dbms_random.random;

analyze table compressed
compute statistics
for table;

select cblks comp_blks, uncblks uncomp_blks,
       round(cblks/uncblks*100,2) pct
  from (
select max(decode(table_name,'COMPRESSED',blocks,null)) cblks,
  max(decode(table_name,'UNCOMPRESSED',blocks,null)) uncblks
  from user_tables
 where table_name in ( 'COMPRESSED', 'UNCOMPRESSED' )
       )
/

analyze table uncompressed compute statistics;

select column_name, num_distinct, num_nulls, avg_col_len
from user_tab_columns
where table_name = 'UNCOMPRESSED'
/

drop table compressed;

create table compressed
COMPRESS
as
select *
  from uncompressed
 order by timestamp;

analyze table compressed
compute statistics
for table;

x
select cblks comp_blks, uncblks uncomp_blks,
       round(cblks/uncblks*100,2) pct
  from (
select max(decode(table_name,'COMPRESSED',blocks,null)) cblks,
  max(decode(table_name,'UNCOMPRESSED',blocks,null)) uncblks
  from user_tables
 where table_name in ( 'COMPRESSED', 'UNCOMPRESSED' )
       )
/

exec dbms_stats.gather_table_stats( user, 'BIG_TABLE_EXTERNAL' );

select column_name, num_distinct, num_nulls, avg_col_len
from user_tab_columns
where table_name = 'BIG_TABLE_EXTERNAL'
/

create table big_table_compressed
COMPRESS
as
select * from big_table_external
order by object_name;

CREATE TABLE audit_trail_table
( timestamp date,
  username  varchar2(30),
  action    varchar2(30),
  object    varchar2(30),
  message   varchar2(80)
)
PARTITION BY RANGE (timestamp)
( PARTITION jan_2002 VALUES LESS THAN
  ( to_date('01-feb-2002','dd-mon-yyyy') ) ,
  PARTITION feb_2002 VALUES LESS THAN
  ( to_date('01-mar-2002','dd-mon-yyyy') ) ,
  PARTITION mar_2002 VALUES LESS THAN
  ( to_date('01-apr-2002','dd-mon-yyyy') ) ,
  PARTITION apr_2002 VALUES LESS THAN
  ( to_date('01-may-2002','dd-mon-yyyy') ) ,
  PARTITION mar_2003 VALUES LESS THAN
  ( to_date('01-apr-2003','dd-mon-yyyy') ) ,
  PARTITION the_rest VALUES LESS THAN
  ( maxvalue )
)
/

create index partitioned_idx_local
on audit_trail_table(username)
LOCAL
/

insert into audit_trail_table
select to_date( '01-mar-2003 ' ||
                 to_char(created,'hh24:mi:ss'),
                 'dd-mon-yyyy hh24:mi:ss' ) +
                 mod(rownum,31),
       owner,
       decode( mod(rownum,10), 0, 'INSERT',
             1, 'UPDATE', 2, 'DELETE', 'SELECT' ),
       object_name,
       object_name || ' ' || dbms_random.random
  from (select * from dba_objects
        UNION ALL
        select * from dba_objects
        UNION ALL
        select * from dba_objects
        UNION ALL
        select * from dba_objects)
/

analyze table audit_trail_table partition (mar_2003)
compute statistics
/

select num_rows, blocks
  from user_tab_partitions
 where table_name = 'AUDIT_TRAIL_TABLE'
   and partition_name = 'MAR_2003'
/

select column_name, num_distinct, num_nulls, avg_col_len
  from USER_PART_COL_STATISTICS
 where table_name = 'AUDIT_TRAIL_TABLE'
   and partition_name = 'MAR_2003'
/
drop table temp;

create table temp
COMPRESS
as
select timestamp, username, action, object, message
  from audit_trail_table Partition(mar_2003)
 order by object, username, action
/

create index temp_idx on temp(username)
/

analyze table temp
compute statistics
for table
for all indexes
for all indexed columns
/
 analyzed.

alter table audit_trail_table
drop partition jan_2002;

set timing on
alter table audit_trail_table
exchange partition mar_2003
with table temp
including indexes
without validation
/

select blocks
  from user_tab_partitions
 where table_name = 'AUDIT_TRAIL_TABLE'
   and partition_name = 'MAR_2003'
/
                                                                                                              
alter table audit_trail_table
split partition the_rest
at ( to_date('01-may-2003','dd-mon-yyyy') )
into ( partition apr_2003, partition the_rest )
/

