

alter table dept
add emp_count number
constraint must_be_between_3_8
check(emp_count between 3 and 8 OR emp_count = 0)
deferrable initially deferred;

update dept
   set emp_count = (select count(*)
                      from emp
                     where emp.deptno = dept.deptno )
/

alter table dept
modify emp_count NOT NULL;

create trigger emp_dept_cnt_trigger
after insert or update or delete on emp
for each row
begin
    if ( updating and :old.deptno = :new.deptno )
    then
        return; -- no change
    end if;
    if ( inserting or updating )
    then
        update dept set emp_count = emp_count+1
         where deptno = :new.deptno;
    end if;
    if ( updating or deleting )
    then
        update dept set emp_count = emp_count-1
         where deptno = :old.deptno;
    end if;
end;
/


