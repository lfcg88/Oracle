
create cluster object_id_lookup
( object_id number )
single table
hashkeys 50000
size 100
/


create table single_table_hash_cluster
( owner, object_name, object_id,
  object_type, created, last_ddl_time,
  timestamp, status )
cluster object_id_lookup(object_id)
as
select owner, object_name, rownum,
       object_type, created, last_ddl_time,
       timestamp, status
  from ( select * from dba_objects
         union all
         select * from dba_objects)
where rownum <= 50000
/

create table heap_table
( owner, object_name, object_id,
  object_type, created, last_ddl_time,
  timestamp, status,
  constraint heap_table_pk
    primary key(object_id) )
as
select owner, object_name, rownum,
       object_type, created, last_ddl_time,
       timestamp, status
  from ( select * from dba_objects
         union all
         select * from dba_objects)
where rownum <= 50000
/


alter session set sql_trace=true;
 
declare
    l_rec single_table_hash_cluster%rowtype;
begin
    for iters in 1 .. 3
    loop
        for i in 1 .. 50000
        loop
            select * into l_rec
              from single_table_hash_cluster
             where object_id = i;

            select * into l_rec
              from heap_table
             where object_id = i;
        end loop;
    end loop;
end;
/



