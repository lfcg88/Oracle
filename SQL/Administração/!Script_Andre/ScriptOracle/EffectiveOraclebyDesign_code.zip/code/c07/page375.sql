

create table t
as
select to_char( to_date('01-jan-1995','dd-mon-yyyy')+rownum, 'yyyymmdd' ) str_date,
       to_date('01-jan-1995','dd-mon-yyyy')+rownum date_date
  from all_objects
/

create index t_str_date_idx on t(str_date);

create index t_date_date_idx on t(date_date);

analyze table t compute statistics
for table
for all indexes
for all indexed columns;

set autotrace on explain
select * from t 
where str_date between '20001231' and '20010101';

select * from t where date_date between to_date('20001231','yyyymmdd') and to_date('20010101','yyyymmdd');


select * from t 
where str_date between '20001231' and '20060101';

select * from t where date_date between to_date('20001231','yyyymmdd') and to_date('20060101','yyyymmdd');


