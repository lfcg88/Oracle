
select cluster_name, owner, table_name
  from dba_tables
 where cluster_name is not null
 order by cluster_name
/



