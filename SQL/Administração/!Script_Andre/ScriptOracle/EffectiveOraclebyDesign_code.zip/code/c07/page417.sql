
create table t as
select 'Y' processed_flag, a.* from all_objects a;


create or replace view v
as
select t.*,
       case when processed_flag = 'N' then 'N'
                else NULL
        end processed_flag_indexed
  from t;


create index t_idx on
t( case when processed_flag = 'N' then 'N'
        else NULL
    end );


analyze index t_idx validate structure;

select name, del_lf_rows, lf_rows, lf_blks
  from index_stats;


update t set processed_flag = 'N'
  where rownum <= 100;



analyze index t_idx validate structure;



select name, del_lf_rows, lf_rows, lf_blks
  from index_stats;


analyze table t compute statistics
for table
for all indexes
for all indexed columns
/


column rowid new_val r

select rowid, object_name
  from v
 where processed_flag_indexed = 'N'
   and rownum = 1;


update v
    set processed_flag = 'Y'
  where rowid = '&R';


set autotrace on
select rowid, object_name
  from v
 where processed_flag_indexed = 'N'
   and rownum = 1;


update v
    set processed_flag = 'Y'
  where rowid = '&R';


analyze index t_idx validate structure;

select name, del_lf_rows, lf_rows, lf_blks
  from index_stats;


insert into t
select 'N' processed_flag, a.* from all_objects a
where rownum <= 2;


analyze index t_idx validate structure;

select name, del_lf_rows, lf_rows, lf_blks
  from index_stats;

