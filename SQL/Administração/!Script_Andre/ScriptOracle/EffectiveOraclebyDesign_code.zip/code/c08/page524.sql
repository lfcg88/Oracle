
select port,
       activity,
       lead(activity)
         over (partition by port
                   order by activity_date) nxt_activity,
       activity_date,
       lead(activity_date)
         over (partition by port
                   order by activity_date) nxt_activity_date
  from t
/
select port,
       activity,
       substr( data, 15 ) activity,
       activity_date,
       to_date( substr( data, 1, 14 ), 'yyyymmddhh24miss' )
  from (
select port,
       activity,
       activity_date,
       (select MIN(to_char(activity_date,'yyyymmddhh24miss')||activity)
          from t t2
         where t2.port = t.port
           and t2.activity_date > t.activity_date ) data
  from t
       )
/
select port, activity, nxt_activity, activity_date, nxt_activity_date,
       nxt_activity_date - activity_date days_between
  from (
select port,
       activity,
       lead(activity)
         over (partition by port
                   order by activity_date) nxt_activity,
       activity_date,
       lead(activity_date)
         over (partition by port
                   order by activity_date) nxt_activity_date
  from t
       )
/
select port, activity, nxt_activity,
       avg( nxt_activity_date - activity_date ) days_between
  from (
select port,
       activity,
       lead(activity)
         over (partition by port
                   order by activity_date) nxt_activity,
       activity_date,
       lead(activity_date)
         over (partition by port
                   order by activity_date) nxt_activity_date
  from t
       )
 where nxt_activity is not null
 group by port, activity, nxt_activity
 order by 1, 2
/

