

select deptno, sal,
       dense_rank() over( partition by deptno order by sal desc) dense_rank
 from emp
/


select deptno,
       decode( dense_rank, 1, sal ) sal1,
       decode( dense_rank, 2, sal ) sal2,
       decode( dense_rank, 3, sal ) sal3
  from (
select deptno, sal,
       dense_rank() over( partition by deptno order by sal desc) dense_rank
 from emp
       )
 where dense_rank <= 3
/


select deptno,
       max(decode( dense_rank, 1, sal )) sal1,
       max(decode( dense_rank, 2, sal )) sal2,
       max(decode( dense_rank, 3, sal )) sal3
  from (
select deptno, sal,
       dense_rank() over( partition by deptno order by sal desc) dense_rank
 from emp
       )
 where dense_rank <= 3
 group by deptno
/

