
create table job_table
( job_id int primary key,
  lo_rid ROWID,
  hi_rid ROWID,
  total_rows number )
/


create or replace 
procedure parallel_procedure( P_JOB in number )
as
        l_job_table job_table%rowtype;
        l_cnt       number;
begin
        select * into l_job_table from job_table where job_id = p_job;

        select count(*)
          into l_cnt
          from big_table_copy
         where ROWID between l_job_table.lo_rid and l_job_table.hi_rid;

        update job_table
           set total_rows = l_cnt
         where job_id = p_job;

end;
/
declare
        l_job number;
begin
        for x in ( select * from job_view )
        loop
                dbms_job.submit( l_job, 'parallel_procedure(JOB);' );
                insert into job_table ( job_id, lo_rid, hi_rid )
                values ( l_job, x.min_rid, x.max_rid );
        end loop;
        commit;
end;
/
select count(*) from big_table_copy;


select sum(total_rows) from job_table;

