et autotrace traceonly explain
alter session set db_file_multiblock_read_count = 1;
select /*+ FULL(b) */ count(*) from big_table.big_table b;
alter session set db_file_multiblock_read_count = 2;
select /*+ FULL(b) */ count(*) from big_table.big_table b;
alter session set db_file_multiblock_read_count = 4;
select /*+ FULL(b) */ count(*) from big_table.big_table b;
alter session set db_file_multiblock_read_count = 512;
select /*+ FULL(b) */ count(*) from big_table.big_table b;
set autotrace off

