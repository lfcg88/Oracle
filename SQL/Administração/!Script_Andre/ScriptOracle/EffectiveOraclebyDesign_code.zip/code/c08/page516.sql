
select *
from big_table t1
where last_ddl_time = (select max(last_ddl_time)
                         from big_table t2
                        where t2.owner = t1.owner )
/

select *
  from big_table t1, ( select owner, max(last_ddl_time) max_time
                         from big_table
                        group by owner ) t2
 where t1.owner = t2.owner
   and t1.last_ddl_time = t2.last_ddl_time
/

select owner, last_ddl_time, object_name, object_type
  from ( select t1.*,
                max(last_ddl_time) over (partition by owner) max_time
           from big_table t1
           )
 where last_ddl_time = max_time
/

