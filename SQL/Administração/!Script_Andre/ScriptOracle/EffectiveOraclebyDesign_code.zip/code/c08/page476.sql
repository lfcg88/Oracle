
create table admission_docs
( registerNumber references students, 
  documentId references documentMaster, 
  dt date,
  constraint admission_pk 
  primary key(registerNumber, documentid, dt));

insert into admission_docs
select object_id, mod(ROWNUM,3)+1, created+object_id-ROWNUM
  from all_objects, (select 1 from all_users where ROWNUM <= 12);


select *
  from documentMaster, admission_docs, students
 where documentMaster.documentId = :bv2
   and documentMaster.documentId = admission_docs.documentId
   and admission_docs.registerNumber = students.registerNumber
   and students.registerNumber = :bv
/

