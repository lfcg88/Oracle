
select a.username, a.user_id, a.created,
       nvl(b.cons_cnt,0) cons, nvl(c.tables_cnt,0) tables
  from all_users a,
       (select owner, count(*) cons_cnt
              from all_constraints
                 group by owner) b,
           (select owner, count(*) tables_cnt
              from all_tables
                 group by owner) c
 where a.username = b.owner(+)
   and a.username = c.owner(+)
   and a.created > sysdate-50
/


select username, user_id, created,
       (select count(*)
          from all_constraints
         where owner = username) cons,
       (select count(*)
          from all_tables
         where owner = username) tables
  from all_users
 where all_users.created > sysdate-50
/


select a.username, a.user_id, a.created,
       nvl(b.cons_cnt,0) cons, nvl(c.tables_cnt,0) tables
  from all_users a,
       (select all_constraints.owner, count(*) cons_cnt
          from all_constraints, all_users
         where all_users.created > sysdate-50
           and all_users.username = all_constraints.owner
         group by owner) b,
       (select all_tables.owner, count(*) tables_cnt
          from all_tables, all_users
         where all_users.created > sysdate-50
           and all_users.username = all_tables.owner
         group by owner) c
 where a.username = b.owner(+)
   and a.username = c.owner(+)
   and a.created > sysdate-50
/

