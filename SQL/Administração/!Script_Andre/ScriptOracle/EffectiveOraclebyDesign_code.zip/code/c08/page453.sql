create table t as select * from all_objects;

set autotrace on
select count(*) from t;


set autotrace off

delete from t where owner <> 'SCOTT';

set autotrace on
select count(*) from t;


set autotrace off
alter table t move;
Table altered.

set autotrace on
select count(*) from t;

