
create table t
as
select * from all_objects;

create index t_idx1 on t(object_id);

create index t_idx2 on t(owner,object_type);

analyze table t
compute statistics
for table
for all indexes
for all indexed columns;
set autotrace traceonly explain
select object_id, owner, object_type
  from t
 where object_id between 100 and 2000
   and owner = 'SYS'
/

set autotrace traceonly
select object_id, owner, object_type
  from t
 where object_id between 100 and 2000
   and owner = 'SYS'
/

select /*+ index( t t_idx1 ) */ object_id, owner, object_type
  from t
 where object_id between 100 and 2000
   and owner = 'SYS'
/

select /*+ index( t t_idx2 ) */ object_id, owner, object_type
  from t
 where object_id between 100 and 2000
   and owner = 'SYS'
/

