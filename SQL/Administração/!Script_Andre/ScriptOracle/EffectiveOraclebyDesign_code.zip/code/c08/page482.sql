
create table emp
as
select * from scott.emp;

update emp
   set deptno = 9
 where deptno = 10;

create table dept
as
select *
  from scott.dept;

alter table emp add constraint emp_pk primary key(empno);

alter table dept add constraint dept_pk primary key(deptno);

analyze table emp compute statistics;

analyze table dept compute statistics;

set autotrace on explain

select empno, ename, dept.deptno, dname
  from emp, dept
 where emp.deptno(+) = dept.deptno
 UNION ALL
select empno, ename, emp.deptno, null
  from emp, dept
 where emp.deptno = dept.deptno(+)
   and dept.deptno is null
 order by 1, 2, 3, 4
/

select empno, ename, nvl(dept.deptno,emp.deptno), dname
  from emp FULL OUTER JOIN dept on ( emp.deptno = dept.deptno )
 order by 1, 2, 3, 4
/

