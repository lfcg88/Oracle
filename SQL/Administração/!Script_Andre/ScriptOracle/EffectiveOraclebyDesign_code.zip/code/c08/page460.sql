
set autotrace traceonly explain
select * from t where b = 1 and c = 1;

