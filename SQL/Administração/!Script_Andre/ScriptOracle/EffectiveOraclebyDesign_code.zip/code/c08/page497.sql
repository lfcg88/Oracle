
create table t1
as
select * from all_objects;

create table t2
as
select * from all_users;

alter table t2 add constraint
t2_pk primary key(username);

alter table t1 add constraint
t1_pk primary key(object_id);

create index t1_sort_idx
on t1(owner,object_type);

analyze table t1 compute statistics
for table for all indexes
for all indexed columns;

analyze table t2 compute statistics
for table for all indexes
for all indexed columns;

variable min_row number
variable max_row number

exec :min_row := 1; :max_row := 10;

set autotrace on
select *
  from ( select /*+ first_rows */ a.*, ROWNUM rnum
           from ( select t1.owner, t1.object_name, 
                         t1.object_type, t2.user_id
                    from t1, t2
                   where t1.owner = t2.username
                   order by t1.owner, t1.object_type
                                ) A
                  where ROWNUM <= :max_row
           )
 where rnum >= :min_row
/

exec :min_row := 5000; :max_row := 5010;

/


select *
  from ( select /*+ first_rows */ a.*, ROWNUM rnum
           from ( select t1.owner, t1.object_name, 
                         t1.object_type, t2.user_id
                    from t1, t2
                    where t1.owner = t2.username
                    order by t1.owner, t1.object_type
                                ) A
           )
 where rnum between :min_row and :max_row
/



