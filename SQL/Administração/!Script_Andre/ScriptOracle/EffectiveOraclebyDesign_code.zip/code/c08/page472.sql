
create table t1
as
select *
  from all_users
 where 1=0;

create index t1_username_idx on t1(username);

create table t2
as
select *
  from all_objects
 created.

exec dbms_stats.set_table_stats
( user, 'T1', numrows => 10000000, numblks => 1000000 );

exec dbms_stats.set_table_stats
( user, 'T2', numrows => 10000, numblks => 1000 );

set autotrace traceonly explain
select t1.username, sum(t2.object_id)
  from t1, t2
 where t1.username = t2.owner (+)
 group by t1.username
/

