with players as
( select 'P'||ROWNUM username
    from all_objects
   where ROWNUM <= 8),
weeks as
( select ROWNUM week
    from all_objects
   where ROWNUM <= 7 )
select week,
       max(decode(rn,1,username,null)) u1,
       max(decode(rn,2,username,null)) u2,
       max(decode(rn,3,username,null)) u3,
       max(decode(rn,4,username,null)) u4,
       max(decode(rn,5,username,null)) u5,
       max(decode(rn,6,username,null)) u6,
       max(decode(rn,7,username,null)) u7,
       max(decode(rn,8,username,null)) u8
 from ( select username,
         week,
         row_number() over (partition by week order by rnd) rn
          from ( select username, week, dbms_random.random rnd
                   from players, weeks
               )
     )
 group by week
/

