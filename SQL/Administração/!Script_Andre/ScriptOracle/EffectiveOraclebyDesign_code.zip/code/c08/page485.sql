
create table hosts_heap
( hostname       varchar2(10),
  dt             date,
  load           number,
  other_stats    char(65),
  constraint hosts_heap_pk primary key(hostname,dt)
)
/


create table hosts_iot
( hostname       varchar2(10),
  dt             date,
  load           number,
  other_stats    char(65),
  constraint hosts_iot_pk primary key(hostname,dt)
)
organization index
/


declare
    l_load number;
begin
    for l_HOURS in 1 .. 100
    loop
        for l_HOSTS in 1 .. 100
        loop
            l_load := dbms_random.random;
            insert into hosts_heap
            (hostname,dt,load,other_stats)
            values
            ('hostnm' || l_hosts, sysdate-(100-l_hours)/24,
             l_load, 'x' );
            insert into hosts_iot
            (hostname,dt,load,other_stats)
            values
            ('hostnm' || l_hosts, sysdate-(100-l_hours)/24,
             l_load, 'x' );
        end loop;
        commit;
    end loop;
end;
/


analyze table hosts_heap compute statistics;


analyze table hosts_iot compute statistics;


set autotrace on
select avg(load)
  from hosts_heap
 where hostname = 'hostnm50'
   and dt >= sysdate-100/24
/
select avg(load)
  from hosts_iot
 where hostname = 'hostnm50'
   and dt >= sysdate-100/24
/

