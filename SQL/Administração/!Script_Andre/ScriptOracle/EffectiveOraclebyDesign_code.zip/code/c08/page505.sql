
select a.username, count(*)
  from all_users a, all_objects b
 where a.username = b.owner (+)
 group by a.username;

   select a.username, (select count(*)
                      from all_objects b
                     where b.owner = a.username) cnt
     from all_users a
/


