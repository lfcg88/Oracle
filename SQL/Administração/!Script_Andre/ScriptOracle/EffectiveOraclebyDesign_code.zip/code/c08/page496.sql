create table t ( x clob );

set autotrace traceonly explain
select * from t;

create index t_idx on t(x) indextype is ctxsys.context;
select * from t;

