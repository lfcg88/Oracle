
select * from dept where deptno NOT IN ( select deptno from emp )
/
select dept.*
  from dept, emp
 where dept.deptno = emp.deptno(+)
   and emp.ROWID is null;
select *
   from dept
  where NOT EXISTS 
     ( select null from emp where emp.deptno = dept.deptno );


create table t1 as select * 
 from all_objects where ROWNUM <= 10000;

create table t2 as select * 
from all_objects where ROWNUM <= 9950;

create index t2_idx on t2(object_id);


select count(*) from t1 rbo 
where object_id not in ( select object_id from t2 )
/

select count(*) from t1 rbo
 where NOT EXISTS (select null from t2 where t2.object_id = rbo.object_id )
/

select count(*) from t1, t2 rbo
 where t1.object_id = rbo.object_id(+) and rbo.object_id IS NULL
/

analyze table t1 compute statistics;
analyze table t2 compute statistics;

select count(*) from t1 cbo 
where object_id not in ( select object_id from t2 )
/

select count(*) from t1 cbo 
where object_id not in ( select object_id from t2 )
/

select count(*) from t1 cbo 
where object_id not in ( select object_id from t2 )
/

alter table t2 modify object_id null;
select count(*)
from
 t1 cbo where object_id not in ( select object_id from t2 )
/


select ename from emp 
 where empno not in (select mgr from emp);

select ename from emp 
 where NOT EXISTS (select null from emp e2 where e2.mgr = emp.empno);

select count(*)
from
 t1 cbo where object_id not in 
( select object_id from t2 where OBJECT_ID IS NOT NULL )
/



