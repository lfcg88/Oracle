
create table t
as
select mod(ROWNUM,3) a, ROWNUM b, ROWNUM c, object_name d
  from all_objects;

alter table t modify a not null;

create index t_idx on t(a,b,c);

analyze table t compute statistics;

set autotrace traceonly explain
select * from t where b = 1 and c = 1;

select /*+ index( t t_idx ) */ * from t 
where b = 1 and c = 1;
set autotrace off
