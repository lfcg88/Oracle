

create table students
( registerNumber number constraint students_pk primary key, 
  name varchar2(10) );
 
create table documentMaster
( documentId number constraint document_pk primary key, 
  description varchar2(10) );
 
create table admission_docs
( registerNumber references students, 
  documentId references documentMaster, 
  dt date,
  constraint admission_pk primary key(registerNumber, documentId));


insert into students
select object_id, object_name
  from all_objects;


insert into documentMaster
select ROWNUM, 'doc ' || ROWNUM
  from all_users
 where ROWNUM <= 5;

insert into admission_docs
select object_id, mod(ROWNUM,3)+1, created
  from all_objects, (select 1 from all_users where ROWNUM <= 3);


analyze table students compute statistics
for table for all indexes for all indexed columns;
 
analyze table documentMaster compute statistics
for table for all indexes for all indexed columns;
 
analyze table admission_docs compute statistics
for table for all indexes for all indexed columns;


set autotrace on
variable bv number
exec :bv := 1234

select a.* , decode(b.dt,null,'No','Yes') submitted, b.dt
 from (
select *
  from students, documentMaster
 where students.registerNumber = :bv
      ) a, admission_docs b
 where a.registerNumber = b.registerNumber(+)
   and a.documentId = b.documentId (+)
/

