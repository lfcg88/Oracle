
declare
    l_owner        dbms_sql.varchar2_table;
    l_object_name  dbms_sql.varchar2_table;
    l_object_type  dbms_sql.varchar2_table;
    l_created      dbms_sql.varchar2_table;
  
    cursor c is
    select owner, object_name, object_type, created
      from big_table
     order by created DESC;
begin
    select owner, object_name, object_type, created
      bulk collect into l_owner, l_object_name, l_object_type, 
                        l_created
      from ( select owner, object_name, object_type, created
               from big_table
              order by created DESC )
     where ROWNUM <= 10;

    open c;
    fetch c bulk collect
     into l_owner, l_object_name, l_object_type, l_created
    limit 10;
    close c;
end;
/



