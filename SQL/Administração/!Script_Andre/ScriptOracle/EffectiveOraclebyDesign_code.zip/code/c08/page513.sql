LOAD DATA
INFILE *
INTO TABLE t
REPLACE
FIELDS TERMINATED BY '|'
(
username "(select username from all_users where user_id = :username)"
)
BEGINDATA
0
5
11
19
21
30

