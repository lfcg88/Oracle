
select deptno,
       ename,
           sal,
       row_number() over (partition by deptno order by sal desc) rn,
       rank() over (partition by deptno order by sal desc ) rank,
       dense_rank() over ( partition by deptno order by sal desc ) dense_rank
  from emp
order by deptno, sal DESC
/

update emp set sal = 3000 where ename = 'JONES';

select deptno,
       ename,
           sal,
       row_number() over (partition by deptno order by sal desc) rn,
       rank() over (partition by deptno order by sal desc ) rank,
       dense_rank() over ( partition by deptno order by sal desc ) dense_rank
  from emp
order by deptno, sal DESC
/

rollback
/

select deptno, ename, sal, rn
  from (
select deptno,
       ename,
       sal,
       row_number() over (partition by deptno order by sal desc) rn,
       rank() over (partition by deptno order by sal desc ) rank,
       dense_rank() over ( partition by deptno order by sal desc ) dense_rank
  from emp
       )
 where rn <= 3
 order by deptno, sal DESC
/

select deptno, ename, sal, dense_rank
  from (
select deptno,
       ename,
       sal,
       row_number() over (partition by deptno order by sal desc) rn,
       rank() over (partition by deptno order by sal desc ) rank,
       dense_rank() over ( partition by deptno order by sal desc ) dense_rank
  from emp
       )
 where dense_rank <= 3
 order by deptno, sal DESC
/

