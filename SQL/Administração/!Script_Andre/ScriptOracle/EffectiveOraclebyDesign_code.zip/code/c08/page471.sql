

explain plan for
select a.ename, b.ename, a.hiredate, b.hiredate
 from emp a, emp b
where a.hiredate <= b.hiredate
  and a.empno <> b.empno
/

@?/rdbms/admin/utlxpls
select plan_table_output from table(dbms_xplan.display);

