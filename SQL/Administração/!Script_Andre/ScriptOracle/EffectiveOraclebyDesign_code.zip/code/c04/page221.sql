
create tablespace five_meg
datafile size 100m
uniform size 5m
/

select sum(bytes/1024/1024) free_space
from dba_free_space
where tablespace_name = ' FIVE_MEG'
/

column file_name new_val f
select file_name from dba_data_files
where tablespace_name = 'FIVE_MEG';

alter database
datafile '&f' resize 102464k;

select sum(bytes/1024/1024) free_space
from dba_free_space
where tablespace_name = 'FIVE_MEG';

