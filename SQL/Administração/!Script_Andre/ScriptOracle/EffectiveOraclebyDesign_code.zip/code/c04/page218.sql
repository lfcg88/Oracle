
create tablespace SYSTEM_MANAGED
 extent management local;


create table big_table_copy
 tablespace SYSTEM_MANAGED
 as
 select * from big_table;


select tablespace_name, extent_id, bytes/1024, blocks
 from user_extents
 where segment_name = ' BIG_TABLE_COPY'
/

