create tablespace uniform_extents
datafile size 2112k, size 2112k, size 2112k, size 2112k
uniform size 64k
/

create tablespace system_managed
datafile size 2112k, size 2112k, size 2112k, size 2112k
/

create table uniform_size ( x int, y char(2000) )
tablespace uniform_extents;

create table system_size ( x int, y char(2000) )
tablespace system_managed;

begin
 loop
   insert into uniform_size values( 1, 'x' );
   commit;
 end loop;
end;
/
begin
 loop
   insert into system_size values( 1, 'x' );
   commit;
 end loop;
end;
/
select segment_name, extent_id, blocks, file_id
from dba_extents
where segment_name in ( 'UNIFORM_SIZE' , 'SYSTEM_SIZE' )
and owner = user
order by segment_name, extent_id
/

