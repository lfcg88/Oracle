create tablespace auto_tbs datafile
size 64m autoextend on next 8m extent management local autoallocate
segment space management AUTO;
 
create tablespace manual_tbs datafile
size 64m autoextend on next 8m extent management local autoallocate
segment space management MANUAL;

declare
    cursor c
    is select rownum r, a.* from all_objects a;
    type c_rec is table of 
         ${type}_table%rowtype index by binary_integer;
    type rowidArray is table of rowid index by binary_integer;
    l_rec   c_rec;
    l_rids  rowidArray;
    l_empty rowidArray;
    n      number      := 25;
begin
    loop
        open c;
        loop
            fetch c bulk collect into l_rec limit N;
            exit when l_rec.count = 0;
            forall i in 1 .. l_rec.count
                insert into ${type}_table values l_rec(i);
            insert into ${type}_table values l_rec(1) 
            returning rowid into l_rids(l_rids.count+1);
            commit;
            if ( l_rids.count = 100 )
            then
                forall i in 1 .. l_rids.count
                    delete from ${type}_table 
                     where rowid = l_rids(i);
                commit;
                l_rids := l_empty;
            end if;
        end loop;
        close c;
    end loop;
end;
/

