
create tablespace manual;

create table t
( x date, y char(255) default 'x' )
storage ( freelists &1 )
tablespace manual;

create or replace procedure do_insert
as
    l_stop  date default sysdate+5/24/60;
    l_date  date default sysdate;
begin
    while ( l_date < l_stop )
    loop
        insert into t (x)
        values (sysdate)
        returning x into l_date;
        commit;
    end loop;
end;
/
exec perfstat.statspack.snap

declare
    l_job number;
begin
    for i in 1 .. 5
    loop
        dbms_job.submit( l_job, 'do_insert;' );
    end loop;
    commit;
end;
/

host sleep 400

exec perfstat.statspack.snap

