
create undo tablespace
UNDO_BIG datafile
size 1m autoextend on next 1m
maxsize 2048m;

create undo tablespace
UNDO_SMALL datafile
size 1m autoextend off;

show parameter undo_retention

alter system
set undo_tablespace = UNDO_BIG
scope = memory;

drop table t;

create table t
( x char(2000),
  y char(2000),
  z char(2000)
);

insert into t values('x','x','x');

begin
for i in 1 .. 500
loop
   update t set x=i,y=i,z=i;
   commit;
end loop;
end;
/

select bytes,maxbytes
  from dba_data_files
 where tablespace_name = 'UNDO_BIG';

alter system
set undo_tablespace = UNDO_SMALL
scope = memory;

show parameter undo_t

select bytes,maxbytes
  from dba_data_files
 where tablespace_name = 'UNDO_SMALL';


