
create table emp as select * from scott.emp;

variable a refcursor
variable b refcursor
variable c refcursor
alter session set sql_trace=true;
begin
    open :a for select empno from emp q1 where ename = 'BLAKE';
    open :b for select empno from emp q2 where ename = 'BLAKE';
    open :c for select empno from emp q3 where ename = 'SMITH';
end;
/
print a
begin
    for i in 1 .. 1000
    loop
        update emp
           set sal = sal
         where ename = 'BLAKE';
        commit;
    end loop;
    delete from emp
     where ename = 'SMITH';
    commit;
end;
/
print b
print c

