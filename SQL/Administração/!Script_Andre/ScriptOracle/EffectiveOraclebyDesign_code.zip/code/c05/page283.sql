Alter system flush shared_pool;
Alter session set sql_trace=true;
variable processed varchar2(1);
exec :processed := 'N';
select *
  from records_to_be_processed initially_N
 where processed = :processed;

exec :processed := 'Y';
select *
  from records_to_be_processed initially_N
 where processed = :processed;

exec :processed := 'Y';
select *
  from records_to_be_processed initially_Y
 where processed = :processed;

exec :processed := 'N';
select *
  from records_to_be_processed initially_Y
 where processed = :processed;
set autotrace off

