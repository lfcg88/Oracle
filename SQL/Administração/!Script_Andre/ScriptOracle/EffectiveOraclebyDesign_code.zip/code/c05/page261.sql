update emp set sal = sal * 1.1

create index sal_idx on emp(sal);

alter session set sql_trace=true;

update emp set sal = sal*1.1;

