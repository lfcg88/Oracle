drop table t;
create table t ( x int );
alter session set sql_trace=true;
begin
    for i in 1 .. 1000
    loop
        execute immediate 'insert into t values ( ' || i || ')';
    end loop;
end;
/

