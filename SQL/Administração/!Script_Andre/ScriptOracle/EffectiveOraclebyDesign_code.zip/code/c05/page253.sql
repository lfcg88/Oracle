alter session set sql_trace=true;
declare
    cursor c is select * from big_table;
    l_rec  big_table%rowtype;
begin
    open c;
    fetch c into l_rec;
    close c;
end;
/

