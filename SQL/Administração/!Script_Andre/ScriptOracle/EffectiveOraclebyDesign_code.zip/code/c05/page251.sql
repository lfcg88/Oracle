declare
    l_data   dbms_sql.number_table;
    l_empty  dbms_sql.number_table;
begin
    for i in 1 .. 1000
    loop
        l_data(mod(i,100)) := i;
        if ( mod(i,100) = 0 )
        then
            forall j in 0 .. l_data.count-1
                insert into t values ( l_data(j) );
            l_data := l_empty;
        end if;
    end loop;
end;
/

