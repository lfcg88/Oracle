
create public synonym emp for d.emp;
alter system flush shared_pool;

connect a/a
create table emp ( x int );
select * from emp;

connect b/b
create table emp ( x int );
select * from emp;

connect d/d
create table emp ( x int );
grant select on emp to c;
select * from emp;

connect c/c
select * from emp;

select address, executions, sql_text
  from v$sql
 where upper(sql_text) like 'SELECT * FROM EMP%';

select kglhdpar, address,
       auth_check_mismatch, translation_mismatch
  from v$sql_shared_cursor
 where kglhdpar in
 ( select address
     from v$sql
    where upper(sql_text) like 'SELECT * FROM EMP%' )
/

