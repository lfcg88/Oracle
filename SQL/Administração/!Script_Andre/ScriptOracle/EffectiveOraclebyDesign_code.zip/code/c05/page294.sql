                                                                                                             
create or replace type vcArray as table of varchar2(5)
/
create or replace package dyn_insert2
as
    procedure exec_imd_method1( p_tname in varchar2,
                                p_value in varchar2 );
    procedure exec_imd_method2( p_tname in varchar2,
                                p_value in vcArray );
end;
/
create or replace package body dyn_insert2
as

procedure exec_imd_method1( p_tname in varchar2,
                            p_value in varchar2 )
is
begin
    execute immediate
    'insert into ' || p_tname || '(x) values (:x)'
    using p_value;
end;

procedure exec_imd_method2( p_tname in varchar2,
                            p_value in vcArray )
is
begin
/****
 **** This block of code can be used to emulate
 **** dynamic BULK inserts in Oracle8i
    execute immediate
    'begin
       forall i in 1 .. :n
          insert into ' || p_tname || '(x) values (:x(i));
     end;'
    using p_value.count, p_value;
 **** since the syntax that follows is new with Oracle9i
 ****/

    forall i in 1 .. p_value.count
      execute immediate 'insert into ' || p_tname || '(x) values( :x )'
      using p_value(i);

end;
end;
/
exec runstats_pkg.rs_start

declare
    l_array vcArray := vcArray();
begin
    for i in 1 .. 5000
    loop
        l_array.extend;
        l_array(l_array.count) := i;
        if ( mod(l_array.count,1000) = 0 or i = 5000 )
        then
            dyn_insert2.exec_imd_method2('T', l_array );
            l_array := vcArray();
        end if;
    end loop;
end;
/

exec runstats_pkg.rs_middle
begin
    for i in 1 .. 5000
    loop
        dyn_insert2.exec_imd_method1('T',i );
    end loop;
end;
/

exec runstats_pkg.rs_stop(500)

