create or replace procedure 
do_something( p_owner in varchar2 )
as
begin
    for x in ( select *
                 from all_objects
                where owner = p_owner )
    loop
        exit;
        /* we would be processing these records here */
    end loop;
end;
/

alter session set sql_trace=true;
 
declare
    l_cnt number := 0;
begin
    for x in ( select * from all_users )
    loop
        do_something( x.username );
        l_cnt := l_cnt + 1;
    end loop;
    dbms_output.put_line( l_cnt || ' rows processed.' );
end;
/

