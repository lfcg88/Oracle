declare
    c sys_refcursor;
    type array is table of  big_table%rowtype index by binary_integer;
    l_rec array;
begin
    for i in 1 .. 5
    loop
        open c for select * from big_table;
        fetch c bulk collect into l_rec limit i*1000;
        close c;
    end loop;
end;
/

