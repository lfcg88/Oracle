
                                                                                                             
create table user_table 
( username varchar2(30), password varchar2(30) );

insert into user_table values 
( 'tom', 'top_secret_password' );

commit;

accept Uname prompt "Enter username: "
accept Pword prompt "Enter password: "
select count(*)
  from user_table
 where username = '&Uname'
   and password = '&Pword'
/
variable uname varchar2(30);
variable pword varchar2(30);
exec :uname := 'tom'; 
exec :pword := 'i_dont_know'' or ''x'' = ''x';

select count(*)
  from user_table
 where username = :uname
   and password = :pword
/

