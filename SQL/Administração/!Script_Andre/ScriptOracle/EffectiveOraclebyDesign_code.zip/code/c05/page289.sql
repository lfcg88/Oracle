alter session set session_cached_cursors=100;

exec runstats_pkg.rs_start

declare
    type rc is ref cursor;
    l_cursor rc;
begin
    for i in 1 .. 5000
    loop
        open l_cursor for
        'select x
           from t
          where x = :x' using i;
        close l_cursor;
    end loop;
end;
/

exec runstats_pkg.rs_middle

declare
        cursor c( p_input in varchar2)
        is
        select x
          from t
         where x = p_input;
begin
    for i in 1 .. 5000
    loop
                open c(i);
        close c;
    end loop;
end;
/

exec runstats_pkg.rs_stop(100)

