declare
    cursor c is select /*+ FIRST_ROWS(1) */ * from big_table order by owner;
    l_rec  big_table%rowtype;
begin
    open c;
    fetch c into l_rec;
    close c;
end;
/

