create or replace package dyn_insert
as
    procedure dbms_sql_method( p_tname in varchar2,
                               p_value in varchar2 );

    procedure exec_imd_method( p_tname in varchar2,
                               p_value in varchar2 );
end;
/
create or replace package body dyn_insert
as

g_last_tname varchar2(30);
g_cursor     number := dbms_sql.open_cursor;

procedure dbms_sql_method( p_tname in varchar2,
                           p_value in varchar2 )
is
    l_rows number;
begin
    if ( g_last_tname <> p_tname or g_last_tname is null )
    then
        dbms_sql.parse( g_cursor,
                       'insert into ' || p_tname ||
                       ' (x) values (:x)',
                        dbms_sql.native );
        g_last_tname := p_tname;
    end if;
    dbms_sql.bind_variable( g_cursor, ':x', p_value );
    l_rows := dbms_sql.execute( g_cursor );
end;

procedure exec_imd_method( p_tname in varchar2,
                           p_value in varchar2 )
is
begin
    execute immediate
    'insert into ' || p_tname || '(x) values (:x)'
    using p_value;
end;

end;
/

begin
    for i in 1 .. 5000
    loop
        dyn_insert.dbms_sql_method( 'T', i );
    end loop;
end;
/

exec runstats_pkg.rs_middle

begin
    for i in 1 .. 5000
    loop
        dyn_insert.exec_imd_method( 'T', i );
    end loop;
end;
/

exec runstats_pkg.rs_stop(100)

