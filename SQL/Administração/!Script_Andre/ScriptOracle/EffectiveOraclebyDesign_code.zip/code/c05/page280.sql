
select * from records_to_be_processed where status = 'N';

create table records_to_be_processed
as
select decode( mod(rownum,100), 0, 'N', 'Y' ) processed, a.*
  from all_objects a;

create index processed_idx on records_to_be_processed(processed);

analyze table records_to_be_processed compute statistics
for table
for all indexes
for all indexed columns
/

variable processed varchar2(1);
exec :processed := 'N'

set autotrace traceonly explain
select *
  from records_to_be_processed
 where processed = 'N';


select *
  from records_to_be_processed
 where processed = :processed;

