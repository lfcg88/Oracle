
create table emp
as
select ename, empno, deptno
  from scott.emp;

create table emp_dept_cnt
( deptno primary key, cnt )
organization index
as
select deptno, count(*)
  from emp
 group by deptno;

create trigger emp_dept_cnt_trigger
after insert or update or delete on emp
for each row
begin
    if ( inserting or updating )
    then
        merge into emp_dept_cnt in_trigger
        using (select :new.deptno deptno from dual) n
           on ( in_trigger.deptno = n.deptno )
         when matched then
       update set cnt = cnt+1
         when not matched then
       insert (deptno,cnt) values (:new.deptno,1);
    end if;
    if ( updating or deleting )
    then
        update emp_dept_cnt in_trigger
           set cnt = cnt-1
         where deptno = :old.deptno;
    end if;
end;
/
alter session set sql_trace=true;

insert into emp (ename,empno,deptno) 
 values ( 'tom',  123, 10 );

insert into emp (ename,empno,deptno) 
 values ( 'mary', 123, 10 );

delete from emp;

