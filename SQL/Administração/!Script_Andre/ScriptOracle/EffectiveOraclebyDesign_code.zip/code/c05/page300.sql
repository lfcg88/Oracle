
create or replace package emp_dept_cnt_pkg
as
    procedure insert_update( p_deptno in number );
    procedure update_delete( p_deptno in number );
end;
/

create or replace package body emp_dept_cnt_pkg
as

procedure insert_update( p_deptno in number )
as
begin
    merge into emp_dept_cnt in_package
    using (select p_deptno deptno from dual) n
       on ( in_package.deptno = n.deptno )
     when matched then
   update set cnt = cnt+1
     when not matched then
   insert (deptno,cnt) values (p_deptno,1);
end;

procedure update_delete( p_deptno in number )
as
begin
    update emp_dept_cnt in_package
       set cnt = cnt-1
     where deptno = p_deptno;
end;

end;
/
create or replace trigger emp_dept_cnt_trigger
after insert or update or delete on emp
for each row
begin
    if ( inserting or updating )
    then
       emp_dept_cnt_pkg.insert_update( :new.deptno );
    end if;
    if ( updating or deleting )
    then
       emp_dept_cnt_pkg.update_delete( :old.deptno );
    end if;
end;
/

