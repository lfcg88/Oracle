
show parameter workarea_size_policy;


alter system flush shared_pool;

select count(*) from big_table;

alter session set workarea_size_policy = manual;

select count(*) from big_table;

select sql_text, child_number, hash_value, address
  from v$sql
 where upper(sql_text) = 'SELECT COUNT(*) FROM BIG_TABLE'
/

select optimizer_mismatch
  from v$sql_shared_cursor
 where kglhdpar in
 ( select address
     from v$sql
    where upper(sql_text) = 'SELECT COUNT(*) FROM BIG_TABLE' );

