create table t1 as select * from all_objects;
create table t2 as select * from all_objects where rownum <= 15000;

alter table t1 add constraint t1_pk primary key(object_id);
alter table t2 add constraint t2_pk primary key(object_id);

analyze table t1 compute statistics
for table for all indexes for all indexed columns;

analyze table t2 compute statistics
for table for all indexes for all indexed columns;

create or replace function get_data( p_object_id in number ) return varchar2
is
    l_object_name t2.object_name%type;
begin
    select object_name into l_object_name
      from t2
     where object_id = p_object_id;
    return l_object_name;
exception
    when no_data_found then
        return NULL;
end;
/

select a.object_id, a.object_name oname1, b.object_name oname2
  from t1 a, t2 b
 where a.object_id = b.object_id(+);

select object_id, object_name oname1, get_data(object_id) oname2
  from t1;

begin
    runstats_pkg.rs_start;
    for x in ( select a.object_id,
                      a.object_name oname1,
                      b.object_name oname2
                 from t1 a, t2 b
                where a.object_id = b.object_id(+) )
    loop
        null;
    end loop;
    runstats_pkg.rs_middle;
    for x in ( select object_id,
                      object_name oname1,
                      get_data(object_id) oname2
                 from t1 )
    loop
        null;
    end loop;
    runstats_pkg.rs_stop;
end;
/

