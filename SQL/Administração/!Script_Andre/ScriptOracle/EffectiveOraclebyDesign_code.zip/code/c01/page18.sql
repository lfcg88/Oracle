Session 1> insert into emp ( empno, deptno, salary )
        2  values ( 102, 2, 60 );

Session 2> update emp
        2     set deptno = 2
        3   where empno = 100;

Session 2> update dept
        2     set sum_of_salary = ( select sum(salary)
        3                             from emp
        4                            where emp.deptno = dept.deptno )
        5   where dept.deptno in ( 1, 2 );

Session 1> update dept
        2     set sum_of_salary = (select sum(salary)
        3                            from emp
        4                           where emp.deptno = dept.deptno)
        5   where dept.deptno = 2;

