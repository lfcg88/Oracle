Create table objects ( oid int primary key, name varchar2(255) );

Create table attributes
( attrId int primary key, attrName varchar2(255),
datatype varchar2(25) );

Create table object_Attributes
( oid int, attrId int, value varchar2(4000),
primary key(oid,attrId) );

Create table Links ( oid1 int, oid2 int,
primary key (oid1, oid2) );

insert into attributes values ( 1, 'DATE_OF_BIRTH', 'DATE' );
insert into attributes values ( 2, 'FIRST_NAME',    'STRING' );
insert into attributes values ( 3, 'LAST_NAME',    'STRING' );
commit;

insert into objects values ( 1, 'PERSON' );
insert into object_Attributes values( 1, 1, '15-mar-1965' );
insert into object_Attributes values( 1, 2, 'Thomas' );
insert into object_Attributes values( 1, 3, 'Kyte' );
commit;

insert into objects values ( 2, 'PERSON' );
insert into object_Attributes values( 2, 1, '21-oct-1968' );
insert into object_Attributes values( 2, 2, 'John' );
insert into object_Attributes values( 2, 3, 'Smith' );
commit;

select 
max( decode(attrName, 'FIRST_NAME', value, null )) first_name,
max( decode( attrName, 'LAST_NAME',  value, null ) ) last_name
  from objects, object_attributes, attributes
 where attributes.attrName in ( 'FIRST_NAME', 'LAST_NAME' )
   and object_attributes.attrId = attributes.attrId
   and object_attributes.oid = objects.oid
   and objects.name = 'PERSON'
 group by objects.oid
/

select *
  from (
select
max(decode(attrName, 'FIRST_NAME', value, null)) first_name,
max(decode(attrName, 'LAST_NAME',  value, null)) last_name,
max(decode(attrName, 'DATE_OF_BIRTH',  value, null))
                                                 date_of_birth
  from objects, object_attributes, attributes
 where attributes.attrName in ( 'FIRST_NAME',
                                'LAST_NAME', 'DATE_OF_BIRTH' )
   and object_attributes.attrId = attributes.attrId
   and object_attributes.oid = objects.oid
   and objects.name = 'PERSON'
 group by objects.oid
       )
 where last_name = 'Smith'
    or date_of_birth like '%-mar-%'
/

