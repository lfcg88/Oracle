create table t1 ( x int );

audit insert on t1 by access;

create table t2 ( x int );

create table t2_audit
as
select sysdate dt, a.*
  from v$session a
 where 1=0;

create index t2_audit_idx on t2_audit(sid,serial#);

create trigger t2_audit
after insert on t2
begin
    insert into t2_audit
    select sysdate, a.*
      from v$session a
     where sid = (select sid
                    from v$mystat
                    where rownum=1);
end;
/

create table t1_times ( xstart timestamp, xstop timestamp );

create or replace procedure p1( n in number )
as
    l_rowid rowid;
begin
    insert into t1_times (xstart) values (systimestamp)
    returning rowid into l_rowid;
    for i in 1 .. n
    loop
        insert into t1 values (i);
        commit;
    end loop;
    update t1_times set xstop = systimestamp where rowid = l_rowid;
    commit;
end;
/

