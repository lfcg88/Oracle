create table dept
( deptno        int primary key,
  sum_of_salary number
);

create table emp
( empno      int primary key,
  deptno     references dept,
  salary     number
);

insert into dept ( deptno ) values ( 1 );

insert into dept ( deptno ) values ( 2 );
insert into emp ( empno, deptno, salary )
values ( 100, 1, 55 );

insert into emp ( empno, deptno, salary )
values ( 101, 1, 50 );


update dept
   set sum_of_salary =
   ( select sum(salary)
       from emp
          where emp.deptno = dept.deptno )
 where dept.deptno = 1;

commit;
select * from emp;
select * from dept;



