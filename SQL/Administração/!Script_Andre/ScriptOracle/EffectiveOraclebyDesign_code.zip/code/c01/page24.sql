create table cities
as
select username city
  from all_users
 where rownum<=37;

alter table cities
add constraint
cities_pk primary key(city);

create table with_ri
( x    char(80),
  city references cities
);

create table without_ri
( x    char(80),
  city varchar2(30)
);
alter session set sql_trace=true;

declare
    type array is table of varchar2(30) index by binary_integer;
    l_data array;
begin
    select * BULK COLLECT into l_data from cities;
    for i in 1 .. 1000
    loop
        for j in 1 .. l_data.count
        loop
            insert into with_ri
            values ('x', l_data(j) );
            insert into without_ri
            values ('x', l_data(j) );
        end loop;
    end loop;
end;
/


