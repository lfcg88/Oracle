select rpad('*',2*level,'*') || ename ename
from emp
start with mgr is null
connect by prior empno = mgr
/

