create table emp
as
select empno, ename, sal, comm
  from scott.emp;

alter table emp
add constraint emp_pk
primary key(empno);

begin
   dbms_wm.EnableVersioning
   ( 'EMP', 'VIEW_WO_OVERWRITE' );
end;
/
update emp set sal = 5000
 where ename = 'KING';

commit;

update emp set comm = 4000
 where ename = 'KING';

commit;

delete from emp
 where ename = 'KING';

commit;

select ename, sal, comm, user_name,
       type_of_change, createtime,
       retiretime
  from emp_hist
 where ename = 'KING'
 order by createtime;


