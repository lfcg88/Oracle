create table clustered ( x int, data char(255) );

insert /*+ append */
  into clustered  (x, data)
select rownum, dbms_random.random
  from all_objects;

alter table clustered
add constraint clustered_pk primary key (x);

analyze table clustered compute statistics;

create table non_clustered ( x int, data char(255) );

insert /*+ append */
  into non_clustered (x, data)
select x, data
  from clustered
 ORDER BY data;

alter table non_clustered
add constraint non_clustered_pk primary key (x);

analyze table non_clustered compute statistics;

select index_name, clustering_factor
  from user_indexes
 where index_name like '%CLUSTERED_PK';

show parameter optimizer_index
set autotrace traceonly explain
select * from clustered where x between 50 and 2750;
select * from non_clustered where x between 50 and 2750;
set autotrace off

