column pct_dept format 99.9
column pct_overall format 99.9
break on deptno skip 1

select deptno,
       ename,
       sal,
       sum(sal) over (partition by deptno order by sal,ename) cum_sal,
       round(100*ratio_to_report(sal)
            over (partition by deptno), 1 ) pct_dept,
       round(100*ratio_to_report(sal) over () , 1 ) pct_overall
  from emp
 order by deptno, sal
/

