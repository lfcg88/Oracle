create table t ( x varchar2(30) );
declare
    procedure method1( p_data in varchar2 )
    is
    begin
        execute immediate
        'insert into t(x) values(:x)'
        using p_data;
    end method1;
  
    procedure method2( p_data in varchar2 )
    is
    begin
        execute immediate
        'insert into t(x) values( ''' ||
         replace( p_data,'''', '''''' ) || ''' )';
    end method2;
begin
    runstats_pkg.rs_start;
    for i in 1 .. 10000
    loop
        method1( 'row ' || I );
    end loop;
    runstats_pkg.rs_middle;
    for i in 1 .. 10000
    loop
        method2( 'row ' || I );
    end loop;
    runstats_pkg.rs_stop;
end;
/

