 select emp.deptno,
       emp.ename,
       emp.sal,
       sum(emp4.sal) cum_sal,
       round(100*emp.sal/emp2.sal_by_dept,1) pct_dept,
       round(100*emp.sal/emp3.sal_overall,1) pct_overall
  from emp,
       (select deptno, sum(sal) sal_by_dept
          from emp
         group by deptno ) emp2,
       (select sum(sal) sal_overall
          from emp ) emp3,
       emp emp4
 where emp.deptno = emp2.deptno
   and emp.deptno = emp4.deptno
   and (emp.sal > emp4.sal or
         (emp.sal = emp4.sal and emp.ename >= emp4.ename))
 group by emp.deptno, emp.ename, emp.sal,
       round(100*emp.sal/emp2.sal_by_dept,1),
       round(100*emp.sal/emp3.sal_overall,1)
 order by deptno, sal
/

