
create table plan_hashes
( sql_text           varchar2(1000),
  hash_value         number,
  plan_hash_value    number,
  constraint plan_hashes_pk
  primary key(hash_value,sql_text,plan_hash_value)
)
organization index;

insert into plan_hashes( sql_text, hash_value, plan_hash_value )
select distinct sql_text,
       hash_value,
       plan_hash_value
  from v$sql
 where command_type in (
 /* DELETE */ 7,    /* INSERT */ 2,
 /* MERGE  */ 189,  /* SELECT */ 3,
 /* UPDATE */ 6 )
   and parsing_user_id <> 0
   and parsing_schema_id <> 0;


create table emp
as
select * from scott.emp;

alter table emp
add constraint emp_pk
primary key(empno);

create table dept
as
select * from scott.dept;

alter table dept
add constraint dept_pk
primary key(deptno);


select ename, dname
  from emp, dept
 where emp.deptno = dept.deptno;


select distinct sql_text,
       hash_value,
       plan_hash_value,
       decode( (select 1
                  from plan_hashes
                 where plan_hashes.hash_value = v$sql.hash_value
                   and plan_hashes.sql_text = v$sql.sql_text
                   and rownum = 1), 1, 'Changed', 'New' ) status
  from v$sql
 where (sql_text, hash_value, plan_hash_value)
not in (select sql_text, hash_value, plan_hash_value
           from plan_hashes)
   and command_type in (
 /* DELETE */ 7,    /* INSERT */ 2,
 /* MERGE  */ 189,  /* SELECT */ 3,
 /* UPDATE */ 6 )
   and parsing_user_id <> 0
   and parsing_schema_id <> 0
/

insert into plan_hashes( sql_text, hash_value, plan_hash_value )
select distinct sql_text,
       hash_value,
       plan_hash_value
  from v$sql
 where (sql_text, hash_value, plan_hash_value)
not in (select sql_text, hash_value, plan_hash_value
           from plan_hashes)
   and command_type in (
 /* DELETE */ 7,    /* INSERT */ 2,
 /* MERGE  */ 189,  /* SELECT */ 3,
 /* UPDATE */ 6 )
   and parsing_user_id <> 0
   and parsing_schema_id <> 0
/




