
/* set up parent child WITHOUT constrained type...*/
create table p1 ( x number(12) primary key);
create table c1 ( x number references p1  on delete cascade);
create index c1_idx on c1(x);


/* set up parent child WITH constrained type... */
create table p2 ( x number(12) primary key);
create table c2 ( x number(12) references p2 on delete cascade );
create index c2_idx on c2(x);
/* created some parent data... */
insert into p1 select rownum from all_objects;
insert into p2 select rownum from all_objects;
commit;


insert into c1 select * from p1;
commit;
insert into c2 select * from p2;
commit;

begin
    for x in ( select * from p1 )
    loop
        for i in 1 .. 5
        loop
            insert into c1 values ( x.x );
        end loop;
        commit;
    end loop;
end;
/

update c1 set x = x+1 where x < 5000;
commit;
update c2 set x = x+1 where x < 5000;
commit;

begin
    for x in ( select * from c1 where x between 5000 and 10000)
    loop
        update c1 set x = x+1 where x = x.x;
    end loop;
    commit;
end;
/


delete from p1 where mod(x,2) = 0;
commit;
delete from p2 where mod(x,2) = 0;
commit;

begin
    for x in ( select * from p1 )
    loop
        delete from p1 where x = x.x;
    end loop;
end;
/
commit;



