column c0 new_val c0
column c1 new_val c1
column c2 new_val c2
column c3 new_val c3
column c4 new_val c4

SELECT min(object_id)-1 c0,
PERCENTILE_DISC(0.25) WITHIN GROUP (ORDER BY object_id) c1,
PERCENTILE_DISC(0.50) WITHIN GROUP (ORDER BY object_id) c2,
PERCENTILE_DISC(0.75) WITHIN GROUP (ORDER BY object_id) c3,
max(object_id) c4
FROM big_table
/

select
sum( case when object_id > &c0 and object_id <= &c1
 then 1 else 0 end ) range1,
sum( case when object_id > &c1 and object_id <= &c2
 then 1 else 0 end ) range2,
sum( case when object_id > &c2 and object_id <= &c3
 then 1 else 0 end ) range3,
sum( case when object_id > &c3 and object_id <= &c4
 then 1 else 0 end ) range4,
count(*)
from big_table
/

