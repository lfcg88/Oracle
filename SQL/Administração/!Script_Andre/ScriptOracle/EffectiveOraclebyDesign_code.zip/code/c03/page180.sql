create table big_table_hashed nologging
partition by hash(object_id) partitions 10
as
select * from big_table;

insert into big_table ( owner, object_name, object_id, 
                        last_ddl_time, created )
select 'SPECIAL_ROW' , object_name, object_id, last_ddl_time, created
 from big_table where rownum = 1;

insert into big_table_hashed ( owner, object_name, object_id, 
                               last_ddl_time, created )
select 'SPECIAL_ROW' , object_name, object_id, last_ddl_time, created
 from big_table_hashed where rownum = 1;

create index big_idx1 on big_table(owner);
create index big_hash_idx1 on big_table_hashed(owner) LOCAL;

analyze table big_table for table for all indexes for all indexed columns;
analyze table big_table_hash 
for table for all indexes for all indexed columns;

delete from plan_table;

explain plan for select * from big_table where owner = :x;

select * from table(dbms_xplan.display);

delete from plan_table;

explain plan for 
select * from big_table_hashed where owner = :x;

select * from table(dbms_xplan.display);

create index big_hash_idx1 on big_table_hashed(owner)
global partition by range (owner)
( partition values less than ( ' F' ),
  partition values less than ( ' M' ),
  partition values less than ( ' T' ),
  partition values less than ( MAXVALUE )
);



