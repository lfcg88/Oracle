
declare
        l_cname varchar2(30);
begin
        select column_name
          into l_cname
          from user_cons_columns
         where constraint_name = 'CHECK_CONS'
           and position is null;
        dbms_output.put_line( l_cname );
end;
/



