
create or replace package body demo_pkg
as
    cursor C1(p_inputs in varchar2)
    is
    select emp.ename, emp.hiredate, dept.dname
      from emp, dept
     where emp.deptno = dept.deptno
       and emp.ename like p_inputs;

    procedure process( p_record in C1%rowtype )
    is
    begin
        null;
    end;

    procedure process_data( p_inputs in varchar2 )
    is
    begin
        for x in C1(p_inputs)
        loop
            process(x);
        end loop;
    end;
end;
/
create or replace package demo_pkg
as
    procedure process_data( p_cname in varchar2,
                            p_inputs in varchar2 );
end;
/
create or replace package body demo_pkg
as
    cursor TEMPLATE_cursor
    is
    select emp.ename, emp.hiredate, dept.dname
      from emp, dept;

    type rc is ref cursor;

    procedure process( p_record in template_cursor%rowtype )
    is
    begin
        null;
    end;

    procedure process_data( p_cname in varchar2,
                            p_inputs in varchar2 )
    is
        l_cursor rc;
        l_rec    template_cursor%rowtype;
    begin
        open l_cursor
        for
        'select emp.ename, emp.hiredate, dept.dname
           from emp, dept
          where emp.deptno = dept.deptno
            and emp.' || p_cname || ' like :x'
          USING p_inputs;

        loop
            fetch l_cursor into l_rec;
            exit when l_cursor%notfound;
            process(l_rec);
        end loop;
        close l_cursor;
    end;
end;
/

