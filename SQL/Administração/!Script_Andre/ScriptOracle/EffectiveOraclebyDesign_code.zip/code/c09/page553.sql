
create table t ( x int );

create view v as select * from t;

create procedure p
as
begin
        for x in ( select * from v )
        loop
                null;
        end loop;
end;
/

create function f return number
as
        l_cnt number;
begin
        select count(*) into l_cnt from t;
        return l_cnt;
end;
/

select name, type, referenced_name, referenced_type
  from user_dependencies
 where referenced_owner = user
 order by name
/

select object_name, object_type, status
  from user_objects
/

alter table t add y number
/

select object_name, object_type, status
  from user_objects
/

create procedure p2
as
begin
        p;
end;
/


select name, type, referenced_name, referenced_type
  from user_dependencies
 where referenced_owner = user
 order by name
/


select object_name, object_type, status
  from user_objects
/


alter table t add z number
/


select object_name, object_type, status
  from user_objects
/


drop procedure p2;

drop function f;

create package p1
as
        procedure p;
end;
/

create package body p1
as
procedure p
as
begin
        for x in ( select * from v )
        loop
                null;
        end loop;
end;
end p1;
/

create package p2
as
        procedure p;
end;
/

create package body p2
as
procedure p
as
begin
        p1.p;
end;
end p2;
/

select name, type, referenced_name, referenced_type
  from user_dependencies
 where referenced_owner = user
 order by name
/


select object_name, object_type, status
  from user_objects
/


alter table t add a number
/

select object_name, object_type, status
  from user_objects
/


exec p2.p

select object_name, object_type, status
  from user_objects
/



