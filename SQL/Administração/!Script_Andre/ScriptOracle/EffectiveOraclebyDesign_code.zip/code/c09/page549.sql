
create table t1
( a int primary key, y char(80) );

create table t2
( b int primary key, a references t1, y char(80) );

create index t2_a_idx on t2(a);

create table t3
( c int primary key, b references t2, y char(80) );

create index t3_b_idx on t3(b);

insert into t1
select rownum, 'x'
  from all_objects
 where rownum <= 1000;

insert into t2
select rownum, mod(rownum,1000)+1, 'x'
  from all_objects
 where rownum <= 5000;

insert into t3
select rownum, mod(rownum,5000)+1, 'x'
  from all_objects;

exec runstats_pkg.rs_start;


begin
    for i in 1 .. 1000
    loop
        for x in ( select t1.a t1a, t1.y t1y,
                          t2.b t2b, t2.a t2a, t2.y t2y,
                          t3.c t3c, t3.b t3b, t3.y t3y
                     from t1, t2, t3
                    where t1.a = i
                      and t2.a (+) = t1.a
                      and t3.b (+) = t2.b )
        loop
            null;
        end loop;
    end loop;
end;
/


exec runstats_pkg.rs_middle


begin
    for i in 1 .. 1000
    loop
        for a in ( select t1.a, t1.y
                     from t1 where t1.a = i )
        loop
            for b in ( select t2.b, t2.a, t2.y
                         from t2 where t2.a = a.a )
            loop
                for c in ( select t3.c, t3.b, t3.y
                             from t3 where t3.b = b.b )
                loop
                    null;
                end loop;
            end loop;
        end loop;
    end loop;
end;
/


exec runstats_pkg.rs_stop(1000);


