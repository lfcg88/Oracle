
create table t
as
select * from all_objects;

create or replace package demo_pkg
as
    type varchar2_array is table of varchar2(30)
         index by binary_integer;

    type rc is ref cursor;

    procedure index_by( p_owner in varchar2,
                        p_object_name out varchar2_array,
                        p_object_type out varchar2_array,
                        p_timestamp out varchar2_array );
    procedure ref_cursor( p_owner in varchar2,
                          p_cursor in out rc );
end;
/

create or replace package body demo_pkg
as

procedure index_by( p_owner in varchar2,
                    p_object_name out varchar2_array,
                    p_object_type out varchar2_array,
                    p_timestamp out varchar2_array )
is
begin
    select object_name, object_type, timestamp
      bulk collect into
           p_object_name, p_object_type, p_timestamp
      from t
     where owner = p_owner;
end;

procedure ref_cursor( p_owner in varchar2,
                      p_cursor in out rc )
is
begin
    open p_cursor for
    select object_name, object_type, timestamp
      from t
     where owner = p_owner;
end;
end;
/



