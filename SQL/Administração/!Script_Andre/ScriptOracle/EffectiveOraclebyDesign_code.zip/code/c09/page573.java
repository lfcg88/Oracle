import java.sql.*;
import java.util.Date;
import oracle.jdbc.driver.*;
import oracle.sql.*;

class indexby
{

static long start = new Date().getTime();
public static void showElapsed( String msg )
{
long end = new Date().getTime();
 
    System.out.println( msg + " " + (end - start) + " ms");
    start = end;
}

public static void main(String args[])throws Exception
{
    DriverManager.registerDriver 
    (new oracle.jdbc.driver.OracleDriver());

    Connection conn=DriverManager.getConnection
    ("jdbc:oracle:oci8:@ora920.us.oracle.com","scott", "tiger");

    showElapsed( "Connected, going to prepare" );
    OracleCallableStatement cstmt =
    (OracleCallableStatement)conn.prepareCall
    ( "begin demo_pkg.index_by(?,?,?,?); end;" );

    showElapsed( "Prepared, going to bind" );
    int maxl        = 15000;
    int elemSqlType = OracleTypes.VARCHAR;
    int elemMaxLen  = 30;

    cstmt.setString( 1, "SYS" );
    cstmt.registerIndexTableOutParameter
    ( 2, maxl, elemSqlType, elemMaxLen );
    cstmt.registerIndexTableOutParameter
    ( 3, maxl, elemSqlType, elemMaxLen );
    cstmt.registerIndexTableOutParameter
    ( 4, maxl, elemSqlType, elemMaxLen );
    showElapsed( "Bound, going to execute" );
    cstmt.execute();

    Datum[] object_name = cstmt.getOraclePlsqlIndexTable(2);
    Datum[] object_type = cstmt.getOraclePlsqlIndexTable(3);
    Datum[] timestamp   = cstmt.getOraclePlsqlIndexTable(4);
    showElapsed( "First Row "+object_name.length );
    String data;
    int i;
    for( i = 0; i < object_name.length; i++ )
    {
        data = object_name[i].stringValue();
        data = object_type[i].stringValue();
        data = timestamp[i].stringValue();
    }
    showElapsed( "Last Row "+i );
}
}

