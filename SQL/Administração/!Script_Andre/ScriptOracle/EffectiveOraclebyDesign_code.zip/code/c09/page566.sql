
create table t1
as
select *
  from dba_objects
 where 1=0;

create or replace procedure row_at_a_time
as
begin
    for x in ( select * from dba_objects )
    loop
        insert into t1 (
        OWNER, OBJECT_NAME, SUBOBJECT_NAME,
        OBJECT_ID, DATA_OBJECT_ID, OBJECT_TYPE,
        CREATED, LAST_DDL_TIME, TIMESTAMP,
        STATUS, TEMPORARY, GENERATED, SECONDARY
        ) values (
        x.OWNER, x.OBJECT_NAME, x.SUBOBJECT_NAME,
        x.OBJECT_ID, x.DATA_OBJECT_ID, x.OBJECT_TYPE,
        x.CREATED, x.LAST_DDL_TIME, x.TIMESTAMP,
        x.STATUS, x.TEMPORARY, x.GENERATED, x.SECONDARY );
    end loop;
end;
/

create table t2
as
select *
  from dba_objects
 where 1=0;

create or replace procedure nrows_at_a_time
                                        ( p_array_size in number )
as
 l_OWNER            dbms_sql.VARCHAR2_table;
 l_OBJECT_NAME      dbms_sql.VARCHAR2_table;
 l_SUBOBJECT_NAME   dbms_sql.VARCHAR2_table;
 l_OBJECT_ID        dbms_sql.NUMBER_table;
 l_DATA_OBJECT_ID   dbms_sql.NUMBER_table;
 l_OBJECT_TYPE      dbms_sql.VARCHAR2_table;
 l_CREATED          dbms_sql.DATE_table;
 l_LAST_DDL_TIME    dbms_sql.DATE_table;
 l_TIMESTAMP        dbms_sql.VARCHAR2_table;
 l_STATUS           dbms_sql.VARCHAR2_table;
 l_TEMPORARY        dbms_sql.VARCHAR2_table;
 l_GENERATED        dbms_sql.VARCHAR2_table;
 l_SECONDARY        dbms_sql.VARCHAR2_table;
 cursor c is select * from dba_objects;
begin
    open c;
    loop
        fetch c bulk collect into
        l_OWNER, l_OBJECT_NAME, l_SUBOBJECT_NAME,
        l_OBJECT_ID, l_DATA_OBJECT_ID, l_OBJECT_TYPE,
        l_CREATED, l_LAST_DDL_TIME, l_TIMESTAMP,
        l_STATUS, l_TEMPORARY, l_GENERATED, l_SECONDARY
        LIMIT p_array_size;

        forall i in 1 .. l_owner.count
            insert into t2 (
            OWNER, OBJECT_NAME, SUBOBJECT_NAME,
            OBJECT_ID, DATA_OBJECT_ID, OBJECT_TYPE,
            CREATED, LAST_DDL_TIME, TIMESTAMP,
            STATUS, TEMPORARY, GENERATED, SECONDARY
            ) values (
            l_OWNER(i), l_OBJECT_NAME(i), l_SUBOBJECT_NAME(i),
            l_OBJECT_ID(i), l_DATA_OBJECT_ID(i), l_OBJECT_TYPE(i),
            l_CREATED(i), l_LAST_DDL_TIME(i), l_TIMESTAMP(i),
            l_STATUS(i), l_TEMPORARY(i), l_GENERATED(i), l_SECONDARY(i) );
        exit when c%notfound;
    end loop;
end;
/



