
declare
    l_dname  dept.dname%type;
    l_deptno dept.deptno%type;
    l_ename  emp.ename%type;
  
    cursor c1
    is
    select deptno, dname
      from dept
     order by deptno;
 
    cursor c2( p_deptno in number )
    is
    select ename
      from emp
     where deptno = p_deptno
       and sal = (select max(sal)
                    from emp
                   where deptno = p_deptno);
begin
    open c1;
    loop
        fetch c1 into l_deptno, l_dname;
        exit when c1%notfound;
        open c2(l_deptno);
        fetch c2 into l_ename;
        close c2;
        dbms_output.put_line
        ( l_deptno || ', ' || l_dname || ', ' || l_ename );
    end loop;
    close c1;
end;
/


declare
    l_ename  emp.ename%type;
begin
    for x in (select deptno, dname from dept order by deptno)
    loop
        select ename into l_ename
          from emp
         where deptno = x.deptno
           and sal = (select max(sal)
                        from emp
                       where deptno = x.deptno);
        dbms_output.put_line
        ( x.deptno || ', ' || x.dname || ', ' || l_ename );
    end loop;
end;
/



declare
    l_ename  emp.ename%type;
begin
    for x in (select deptno, dname from dept order by deptno)
    loop
        select ename into l_ename
          from emp
         where deptno = x.deptno
           and sal = (select max(sal)
                        from emp
                       where deptno = x.deptno) and rownum = 1;
        dbms_output.put_line
        ( x.deptno || ', ' || x.dname || ', ' || l_ename );
    end loop;
end;
/


declare
    l_ename  emp.ename%type;
begin
    for x in (select deptno, dname from dept order by deptno)
    loop
        begin
           select ename into l_ename
             from emp
            where deptno = x.deptno
              and sal = (select max(sal)
                           from emp
                          where deptno = x.deptno)
           and rownum = 1;
        exception when no_data_found
        then
            l_ename := '(none)';
        end;
        dbms_output.put_line
        ( x.deptno || ', ' || x.dname || ', ' || l_ename );
    end loop;
end;
/



