exec runstats_pkg.rs_start


exec row_at_a_time;


exec runstats_pkg.rs_middle


exec nrows_at_a_time(100);


exec runstats_pkg.rs_stop(5000)

