
exec runstats_pkg.rs_start;

begin
    for i in 1 .. 5000
    loop
        for x in ( select ename, empno, hiredate from emp )
        loop
            null;
        end loop;
    end loop;
end;
/

exec runstats_pkg.rs_middle;

declare
    l_ename    dbms_sql.varchar2_table;
    l_empno    dbms_sql.number_table;
    l_hiredate dbms_sql.date_table;
begin
    for i in 1 .. 5000
    loop
        select ename, empno, hiredate
          bulk collect into l_ename, l_empno, l_hiredate
          from emp;
    end loop;
end;
/

exec runstats_pkg.rs_stop(10000);
