

create or replace function get_value_dyn
            ( p_empno in number, p_cname in varchar2 ) return varchar2
as
    l_value  varchar2(4000);
begin
    execute immediate
    'select ' || p_cname || ' from emp where empno = :x'
    into l_value
    using p_empno;
 
    return l_value;
end;
/


create or replace function get_value_static
             ( p_empno in number, p_cname in varchar2 ) return varchar2
as
    l_value  varchar2(4000);
begin
    select decode( upper(p_cname),
                  'ENAME', ename,
                  'EMPNO', empno,
                  'HIREDATE', to_char(hiredate,'yyyymmddhh24miss')) 
      into l_value
      from emp
     where empno = p_empno;
 
    return l_value;
end;
/


exec runstats_pkg.rs_start;


declare
        l_dummy varchar2(30);
begin
    for i in 1 .. 500
    loop
        for x in ( select empno from emp )
        loop
            l_dummy := get_value_dyn(x.empno, 'ENAME' );
            l_dummy := get_value_dyn(x.empno, 'EMPNO' );
            l_dummy := get_value_dyn(x.empno, 'HIREDATE' );
        end loop;
    end loop;
end;
/
exec runstats_pkg.rs_middle


declare
        l_dummy varchar2(30);
begin
    for i in 1 .. 500
    loop
        for x in ( select empno from emp )
        loop
            l_dummy := get_value_static(x.empno, 'ENAME' );
            l_dummy := get_value_static(x.empno, 'EMPNO' );
            l_dummy := get_value_static(x.empno, 'HIREDATE' );
        end loop;
    end loop;
end;
/


exec runstats_pkg.rs_stop(1000);



