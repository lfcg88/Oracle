
create index t1_idx1 on t1(object_name);
create index t1_idx2 on t1(owner,object_type,object_name);
create index t1_idx3 on t1(object_id);

create index t2_idx1 on t2(object_name);
create index t2_idx2 on t2(owner,object_type,object_name);
create index t2_idx3 on t2(object_id);

