
create table lookup_heap
( key_col  primary key,
  key_val
)
as
select object_name, max( owner||'_'||object_id )
  from all_objects
 group by object_name
/


create cluster lookup_hash_cluster
( key_col varchar2(30) )
single table
hashkeys 20000
size 255
/
create table lookup_hash
( key_col, key_val )
cluster lookup_hash_cluster(key_col)
as
select * from lookup_heap;

create table lookup_iot
( key_col primary key, key_val )
as
select * from lookup_heap;


create table built_by_us as select * from lookup_heap where 1=0;


create or replace procedure row_fetch_row_select
                            ( p_arraysize in number default 100 )
as
    l_key_col built_by_us.key_col%type;
    l_key_val built_by_us.key_val%type;
    cursor c is select object_name from all_objects;
begin
    open c;
    loop
        fetch c into l_key_col;
        exit when c%notfound;

        begin
           select key_val into l_key_val
             from lookup_heap
            where key_col = l_key_col;
        exception
            when no_data_found then l_key_val := null;
        end;

        insert into built_by_us ( key_col, key_val )
        values ( l_key_col, l_key_val );
    end loop;
    close c;
end;
/


create or replace package lookup_pkg
as
    type array is table of lookup_heap.key_val%type
         index by lookup_heap.key_col%type;

    g_lookup_tbl array;

    function val( p_key in varchar2 ) return varchar2;
end;
/


create or replace package body lookup_pkg
as

function val( p_key in varchar2 ) return varchar2
as
begin
    return g_lookup_tbl(p_key);
end;

begin
   for x in (select * from lookup_heap)
   loop
    g_lookup_tbl(x.key_col) := x.key_val;
   end loop;
end;
/


create or replace procedure 
array_fetch_heap_insert( p_arraysize in number default 100 )
as
    type array is table of all_objects.object_name%type 
           index by binary_integer;
    l_key_col array;
    cursor c is select object_name from all_objects;
begin
    open c;
    loop
        fetch c bulk collect into l_key_col limit p_arraysize;

        forall i in 1 .. l_key_col.count
            insert into built_by_us ( key_col, key_val )
            values ( l_key_col(i),
                     (select key_val 
                        from lookup_heap 
                       where key_col = l_key_col(i))
                   );
        exit when c%notfound;
    end loop;
    close c;
end;
/



