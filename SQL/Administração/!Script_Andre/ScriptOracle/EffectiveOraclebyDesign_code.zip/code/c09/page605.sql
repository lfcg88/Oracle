
create table t ( object_id primary key, object_name )
organization index
as
select object_id, object_name from all_objects;

create or replace procedure explicit
as
    l_object_name t.object_name%type;
    l_dummy       t.object_name%type;

    cursor c( l_object_id in number )
    is
    select object_name
      from t
     where object_id = l_object_id;
begin
    for i in 1 .. 30000
    loop
        open c(i);
        fetch c into l_object_name;
        if ( c%notfound )
        then
            l_object_name := null;
        end if;
        fetch c into l_dummy;
        if ( c%found )
        then
            raise too_many_rows;
        end if;
        close c;
    end loop;
end;
/
create or replace procedure implicit
as
    l_object_name t.object_name%type;
begin
    for i in 1 .. 30000
    loop
    begin
        select object_name into l_object_name
          from t
         where object_id = i;
    exception
        when no_data_found then
            l_object_name := null;
    end;
        end loop;
end;
/
exec runStats_pkg.rs_start

exec implicit

exec runStats_pkg.rs_middle

exec explicit

exec runStats_pkg.rs_stop
create or replace procedure explicit
as
    l_object_name t.object_name%type;
    l_dummy       t.object_name%type;

    cursor c( l_object_id in number )
    is
    select object_name
      from t
     where object_id = l_object_id;
begin
    for i in 1 .. 30000
    loop
        open c(i);
        fetch c into l_object_name;
        close c;
    end loop;
end;
/

exec runStats_pkg.rs_start

exec implicit

exec runStats_pkg.rs_middle

exec explicit

exec runStats_pkg.rs_stop


