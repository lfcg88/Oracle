

create or replace procedure explicit
as
    l_rec   dept%rowtype;
 
    cursor c
    is
    select * from dept;
begin
    open c;
    loop
        fetch c into l_rec;
        exit when c%notfound;
    end loop;
    close c;
end;
/

create or replace procedure implicit
as
begin
    for x in ( select * from dept )
    loop
        null;
    end loop;
end;
/

