
create or replace package demo_pkg
as
    procedure process_data( p_inputs in varchar2 );
end;
/


create or replace package body demo_pkg
as
    type emp_rec is record
    ( EMPNO             NUMBER(4),
      ENAME             VARCHAR2(10),
      JOB               VARCHAR2(9),
      MGR               NUMBER(4),
      HIREDATE          DATE,
      SAL               NUMBER(7,2),
      COMM              NUMBER(7,2),
      DEPTNO            NUMBER(2)
    );

    procedure process1( p_record in emp%rowtype )
    is
    begin
        null;
    end;

    procedure process2( p_record in emp_rec )
    is
    begin
        null;
    end;

    procedure process_data( p_inputs in varchar2 )
    is
    begin
        for x in (select * from emp where ename like p_inputs)
        loop
            process1(x);
        end loop;

        for x in (select * from emp where ename like p_inputs)
        loop
            process2(x);
        end loop;
    end;
end;
/


exec demo_pkg.process_data( '%' );

alter table emp add x number;

alter package demo_pkg compile body;

show errors package body demo_pkg

alter table emp drop column x;

alter package demo_pkg compile body;

show errors package body demo_pkg

alter table emp modify ename varchar2(11);

update emp set ename = rpad( ename, 11, 'x' );

exec demo_pkg.process_data( '%' );


