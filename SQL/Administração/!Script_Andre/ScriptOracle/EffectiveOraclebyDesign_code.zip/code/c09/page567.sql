
create or replace procedure row_at_a_time
as
begin
    for x in ( select * from dba_objects )
    loop
        insert into t1 values X;
    end loop;
end;
/

create or replace procedure nrows_at_a_time( p_array_size in number )
as
  type array is table of dba_objects%rowtype;
  l_data array;
  cursor c is select * from dba_objects;
begin
  open c;
  loop
     fetch c bulk collect into l_data LIMIT p_array_size;

     forall i in 1 .. l_data.count
         insert into t2 values l_data(i);

     exit when c%notfound;
  end loop;
end;
/

