create table big_table
as
select *
  from all_objects
 where 1=0;
set autotrace on statistics;

insert into big_table select * from all_objects;
insert /*+ APPEND */ into big_table select * from all_objects;
commit;
alter table big_table nologging;
insert into big_table
select * from all_objects;
insert /*+ APPEND */ into big_table
select * from all_objects;
commit;

