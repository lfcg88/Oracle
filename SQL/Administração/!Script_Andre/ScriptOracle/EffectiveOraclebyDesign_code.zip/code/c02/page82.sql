CREATE TABLE t
(
  collection_year int,
  data            varchar2(25)
)
PARTITION BY RANGE (COLLECTION_YEAR) (
  PARTITION PART_99 VALUES LESS THAN (2000),
  PARTITION PART_00 VALUES LESS THAN (2001),
  PARTITION PART_01 VALUES LESS THAN (2002),
  PARTITION PART_02 VALUES LESS THAN (2003),
  PARTITION the_rest VALUES LESS THAN (MAXVALUE)
)
;
delete from plan_table;

explain plan for
select * from t where collection_year = 2002;
@?/rdbms/admin/utlxpls

set autotrace traceonly explain
select * from t where collection_year = 2002;
set autotrace off
