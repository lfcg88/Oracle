create tablespace testing
datafile '/tmp/testing.dbf' size 1m reuse
autoextend on next 1m
extent management dictionary
/

create table t
storage( initial 64k next 64k pctincrease 0 )
tablespace testing
as
select * from all_objects where 1=0;

variable n number;
exec :n := 5;

insert into t 
elect * from all_objects where rownum < :n;

set autotrace traceonly statistics;

exec :n := 99999

insert into t 
elect * from all_objects where rownum < :n;

set autotrace off

create tablespace testing_lmt
datafile '/tmp/testing_lmt.dbf' size 1m reuse
autoextend on next 1m
extent management local
uniform size 64k
/

drop table t;

create table t
tablespace testing_lmt
as
select * from all_objects where 1=0;

variable n number;
exec :n := 5;

insert into t 
elect * from all_objects where rownum < :n;

set autotrace traceonly statistics;
exec :n := 99999

insert into t 
elect * from all_objects where rownum < :n;

set autotrace off

