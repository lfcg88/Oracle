create or replace package demo_pkg
as
    procedure parse_bind_execute_close( p_input in varchar2 );
    procedure bind_execute( p_input in varchar2 );
end;
/


create or replace package body demo_pkg
as

g_first_time boolean := TRUE;
g_cursor     number;

procedure parse_bind_execute_close( p_input in varchar2 )
as
    l_cursor   number;
    l_output   varchar2(4000);
    l_status   number;
begin
    l_cursor := dbms_sql.open_cursor;
    dbms_sql.parse( l_cursor,
                   'select * from dual where dummy = :x',
                    dbms_sql.native );
    dbms_sql.bind_variable( l_cursor, ':x', p_input );
    dbms_sql.define_column( l_cursor, 1, l_output, 4000 );
    l_status := dbms_sql.execute( l_cursor );
    if ( dbms_sql.fetch_rows( l_cursor ) <= 0 )
    then
        l_output := null;
    else
        dbms_sql.column_value( l_cursor, 1, l_output );
    end if;
    dbms_sql.close_cursor( l_cursor );
end parse_bind_execute_close;

procedure bind_execute( p_input in varchar2 )
as
    l_output   varchar2(4000);
    l_status   number;
begin
    if ( g_first_Time )
    then
        g_cursor := dbms_sql.open_cursor;
        dbms_sql.parse( g_cursor,
                       'select * from dual where dummy = :x',
                       dbms_sql.native );
        dbms_sql.define_column( g_cursor, 1, l_output, 4000 );
        g_first_time := FALSE;
    end if;

    dbms_sql.bind_variable( g_cursor, ':x', p_input );
    l_status := dbms_sql.execute( g_cursor );
    if ( dbms_sql.fetch_rows( g_cursor ) <= 0 )
    then
        l_output := null;
    else
        dbms_sql.column_value( g_cursor, 1, l_output );
    end if;
end bind_execute;

end;
/

