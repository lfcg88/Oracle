
create user trace_files identified by trace_files 
default tablespace users quota unlimited on users;

grant create any directory, /* to read user dump dest */
create session ,  /* to log on in the first place */
create table ,    /* used to hold users -> trace files */
create view ,     /* used so users can see what traces they have */
create procedure , /* create the func that gets the trace data */
create trigger ,  /* to capture trace file names upon logoff */
create type ,  /* to create a type to be returned by function */
administer database trigger /* to create the logoff trigger */
to trace_files;

/* these are needed to find the trace file name */
grant select on v_$process to trace_files;
grant select on v_$session to trace_files;
grant select on v_$instance to trace_files;

create view session_trace_file_name
as
select d.instance_name || '_ora_' || ltrim(to_char(a.spid)) || 
       '.trc' filename
  from v$process a, v$session b, v$instance d
 where a.addr = b.paddr
   and b.audsid = sys_context( `userenv', 'sessionid')
/

create table avail_trace_files
( username   varchar2(30) default user,
  filename   varchar2(512),
  dt         timestamp default systimestamp,
  constraint avail_trace_files_pk primary key(username,filename)
)
organization index
/
create view user_avail_trace_files
as
select * from avail_trace_files where username = user
/
grant select on user_avail_trace_files to public
/

create or replace directory UDUMP_DIR
as '/usr/oracle/ora920/OraHome1/admin/ora920/udump'
/

create or replace trigger capture_trace_files
before logoff on database
begin
    for x in ( select * from session_trace_file_name )
    loop
        if ( dbms_lob.fileexists( 
                      bfilename('UDUMP_DIR', x.filename ) ) = 1 )
        then
            insert into avail_trace_files (filename)
            values (x.filename);
        end if;
    end loop;
end;
/
create or replace type vcArray as table of varchar2(4000)
/

create or replace
function trace_file_contents( p_filename in varchar2 )
return vcArray
pipelined
as
    l_bfile       bfile := bfilename('UDUMP_DIR',p_filename);
    l_last        number := 1;
    l_current     number;
begin
    select rownum into l_current
      from user_avail_trace_files
     where filename = p_filename;

    dbms_lob.fileopen( l_bfile );
    loop
        l_current := dbms_lob.instr( l_bfile, '0A', l_last, 1 );
        exit when (nvl(l_current,0) = 0);
        pipe row(
          utl_raw.cast_to_varchar2(
              dbms_lob.substr( l_bfile, l_current-l_last+1,
                                                    l_last ) )
        );
        l_last := l_current+1;
    end loop;
    dbms_lob.fileclose(l_bfile);
    return;
end;
/
grant execute on vcArray to public
/
grant execute on trace_file_contents to public
/

@connect "/ as sysdba"

create user developer identified by developer;

grant create session,
      alter session
to developer;

@connect developer/developer

select * from trace_files.user_avail_trace_files;

@connect developer/developer

select * from trace_files.user_avail_trace_files;
alter session set sql_trace=true;

@connect developer/developer

column filename new_val f
select * from trace_files.user_avail_trace_files;

select * 
from TABLE( trace_files.trace_file_contents( '&f' ) );
