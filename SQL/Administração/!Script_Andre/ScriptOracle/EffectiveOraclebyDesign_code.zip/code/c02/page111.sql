alter session set workarea_size_policy = manual;

alter session set hash_area_size = 1024;

create table t as select * from all_objects;

analyze table t compute statistics 
for table for columns object_id;
set autotrace traceonly
alter session set sort_area_size = 102400;

select *
  from t t1, t t2
 where t1.object_id = t2.object_id
/

/

