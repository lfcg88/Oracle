create table I1(n number primary key, v varchar2(10));
create table I2(n number primary key, v varchar2(10));

create table MAP
(n number primary key,
 i1 number referencing I1(n),
 i2 number referencing I2(n));

create unique index IDX_MAP on MAP(i1, i2);

select *
  from i1, map, i2
 where  i1.n = map.i1
   and i2.n = map.i2
   and i1.v = `x'
   and i2.v = `y';

