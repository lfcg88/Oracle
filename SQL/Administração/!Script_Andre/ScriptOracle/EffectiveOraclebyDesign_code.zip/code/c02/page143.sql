begin
    execute immediate
    'alter session set session_cached_cursors=100';
    runstats_pkg.rs_start;
    for i in 1 .. 1000
    loop
        demo_pkg.parse_bind_execute_close( 'Y' );
    end loop;
    runstats_pkg.rs_middle;
    for i in 1 .. 1000
    loop
        demo_pkg.bind_execute( 'Y' );
    end loop;
    runstats_pkg.rs_stop(500);
end;
/

