                                                                                                             
create table t ( x int );

create trigger t_trigger before insert on t for each row
begin
    for x in ( select *
                 from dual
                where :new.x > (select count(*) from emp))
    loop
        raise_application_error( -20001, 'check failed' );
    end loop;
end;
/


insert into t select 1 from all_users;

set autotrace traceonly statistics

insert into t select 1 from all_users;

