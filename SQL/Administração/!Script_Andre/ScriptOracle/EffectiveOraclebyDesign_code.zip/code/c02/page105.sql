insert into i1 
select rownum, rpad('*',10,'*') from all_objects;

insert into i2 
select rownum, rpad('*',10,'*') from all_objects;

insert into map 
select rownum, rownum, rownum from all_objects;

set autotrace traceonly

 select *
 from
       i1,
       map,
       i2
 where     i1.n = map.i1
 and i2.n = map.i2
 and i1.v = 'x'
 and i2.v = 'y';

analyze table i1 compute statistics;

analyze table i2 compute statistics;

analyze table map compute statistics;

 select *
 from
       i1,
       map,
       i2
 where     i1.n = map.i1
 and i2.n = map.i2
 and i1.v = 'x'
 and i2.v = 'y';

set autotrace off
create index i1_idx on i1(v);

analyze table i1 compute statistics;

set autotrace traceonly

 select *
 from
       i1,
       map,
       i2
 where     i1.n = map.i1
 and i2.n = map.i2
 and i1.v = 'x'
 and i2.v = 'y';

set autotrace off

