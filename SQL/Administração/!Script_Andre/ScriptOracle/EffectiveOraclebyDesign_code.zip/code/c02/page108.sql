create table t as select * from all_objects;

set autotrace traceonly statistics;

set arraysize 2
select * from t;

set arraysize 5
select * from t;
set arraysize 10
select * from t;
set arraysize 15
select * from t;
set arraysize 100
select * from t;
set arraysize 5000
select * from t;
set autotrace off

