alter session set sort_area_size = 1024000;

select *
  from t t1, t t2
 where t1.object_id = t2.object_id
/
alter session set sort_area_size = 10240000;

select *
  from t t1, t t2
 where t1.object_id = t2.object_id
/
set autotrace off

