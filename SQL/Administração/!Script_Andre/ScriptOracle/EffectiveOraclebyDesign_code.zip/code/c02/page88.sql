create table t
as
select * from all_objects;

alter table t add constraint t_pk primary key(object_id);

begin
   dbms_stats.gather_table_stats
   ( user, 'T',
     method_opt => 'for all columns size AUTO',
         cascade => TRUE );
end;
/

alter session set optimizer_index_cost_adj = 10;

select * from t t1 where object_id > 32000;

delete from plan_table;

explain plan for
select * from t t2 where object_id > 32000;

set echo off

@?/rdbms/admin/utlxpls
