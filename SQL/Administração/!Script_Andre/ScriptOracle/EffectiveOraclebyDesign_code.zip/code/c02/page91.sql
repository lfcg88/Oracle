create or replace view dynamic_plan_table
as
select
 rawtohex(address) || '_' || child_number statement_id,
 sysdate timestamp, operation, options, object_node,
 object_owner, object_name, 0 object_instance,
 optimizer,  search_columns, id, parent_id, position,
 cost, cardinality, bytes, other_tag, partition_start,
 partition_stop, partition_id, other, distribution,
 cpu_cost, io_cost, temp_space, access_predicates,
 filter_predicates
 from v$sql_plan;

select plan_table_output
  from TABLE( dbms_xplan.display
              ( 'dynamic_plan_table',
                (select rawtohex(address)||'_'||child_number x
                   from v$sql
where sql_text='select * from t t1 where object_id > 32000' ),
                'serial' ) )
/

