delete from plan_table
/

insert into plan_table
( STATEMENT_ID, TIMESTAMP, REMARKS, OPERATION,
  OPTIONS, OBJECT_NODE, OBJECT_OWNER, OBJECT_NAME,
 OPTIMIZER, SEARCH_COLUMNS, ID, PARENT_ID,
 POSITION, COST, CARDINALITY, BYTES, OTHER_TAG,
 PARTITION_START, PARTITION_STOP, PARTITION_ID,
 OTHER, DISTRIBUTION, CPU_COST,
 IO_COST, TEMP_SPACE )
select rawtohex(address)||'_'||child_number,
       sysdate, null, operation, options,
       object_node, object_owner, object_name,
       optimizer,  search_columns, id, parent_id,
       position, cost, cardinality, bytes, other_tag,
       partition_start, partition_stop, partition_id,
       other, distribution, cpu_cost, io_cost,
       temp_space
  from v$sql_plan
 where (address,child_number) in
       ( select address, child_number
           from v$sql
          where sql_text =
           'select * from t t1 where object_id > 32000'
            and child_number = 0 )
/

set echo off
@?/rdbms/admin/utlxpls

