
alter session set timed_statistics=true;

alter session set events 
10046 trace name context forever, level 12';

select count(*) from big_table
/

select *
  from big_table
 where owner = 'SYS'
   and object_type = 'PACKAGE'
   and object_name like 'F%'
/
select c.value || '\ORA' || to_char(a.spid,'fm00000') || '.trc'
  from v$process a, v$session b, v$parameter c
 where a.addr = b.paddr
   and b.audsid = sys_context(`userenv','sessionid')
   and c.name = 'user_dump_dest'
/

select rtrim(c.value,'/') || '/' || d.instance_name || 
       '_ora_' || ltrim(to_char(a.spid)) || '.trc'
  from v$process a, v$session b, v$parameter c, v$instance d
 where a.addr = b.paddr
   and b.audsid = sys_context( `userenv', 'sessionid')
   and c.name = 'user_dump_dest'
/
select rtrim(c.value,'/') || '/' || d.instance_name || 
                    '_ora_' || ltrim(to_char(a.spid)) || '.trc'
  from v$process a, v$session b, v$parameter c, v$instance d
 where a.addr = b.paddr
   and b.audsid = sys_context( `userenv', 'sessionid')
   and c.name = 'user_dump_dest'
/

