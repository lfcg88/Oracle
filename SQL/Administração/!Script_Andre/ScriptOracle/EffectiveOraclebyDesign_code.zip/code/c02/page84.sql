delete from plan_table;

explain plan for
select ename, dname, grade
  from emp, dept, salgrade
 where emp.deptno = dept.deptno
   and emp.sal between salgrade.losal and salgrade.hisal
/

@?/rdbms/admin/utlxpls

