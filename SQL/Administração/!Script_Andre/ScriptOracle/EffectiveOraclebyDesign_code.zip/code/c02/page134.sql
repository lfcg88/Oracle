
column filename new_val f
select filename
  from trace_files.user_avail_trace_files
 where dt = ( select max(dt)
                from trace_files.user_avail_trace_files
            )
/
set termout off
set heading off
set feedback off
set embedded on
set linesize 4000
set trimspool on
set verify off
spool &f
select * from TABLE( trace_files.trace_file_contents( '&f' ) );
spool off
set verify on
set feedback on
set heading on
set termout on
host tkprof &f tk.prf
edit tk.prf

