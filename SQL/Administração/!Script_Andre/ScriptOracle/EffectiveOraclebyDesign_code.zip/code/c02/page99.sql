create or replace function some_function return number
as
   l_user     varchar2(30) default user;
   l_cnt      number;
begin
   select count(*) into l_cnt from dual;
   return l_cnt;
end;
/
set autotrace traceonly statistics;
select ename, some_function
  from scott.emp
/

set autotrace off
select ename, (select count(*) from dual)
from scott.emp;

