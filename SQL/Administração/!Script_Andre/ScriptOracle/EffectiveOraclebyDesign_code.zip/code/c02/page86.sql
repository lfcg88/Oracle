
delete from plan_table;

explain plan for
select ename, dname, grade
  from salgrade, dept, emp
 where emp.deptno = dept.deptno
   and emp.sal between salgrade.losal and salgrade.hisal
/

@?/rdbms/admin/utlxpls

