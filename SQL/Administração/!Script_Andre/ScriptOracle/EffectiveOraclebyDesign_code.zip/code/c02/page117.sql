create index big_table_idx on
big_table(owner,object_type,object_name);

insert /*+ APPEND */ into big_table
select * from all_objects;

commit;
alter index big_table_idx unusable;

alter session set skip_unusable_indexes=true;

insert /*+ APPEND */ into big_table
select * from all_objects;

alter index big_table_idx rebuild nologging;

