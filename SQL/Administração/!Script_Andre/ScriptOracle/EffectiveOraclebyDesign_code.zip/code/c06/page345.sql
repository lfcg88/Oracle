create or replace procedure
get_result_set( p_hint       in varchar2,
                p_owner in varchar2,
                p_min_row in number,
                p_max_row in number,
                p_result_set in out sys_refcursor )
as
begin
    open p_result_set
     for 'select *
           from ( select ' || p_hint || ' a.*, rownum r
                    from (select t1.object_name a,
                                 t2.object_name b
                            from big_table t1, big_table t2
                           where t1.object_id = t2.object_id
                             and t1.owner = :p_owner ) a
                   where rownum <= :p_max_row )
          where r >= :p_min_row'
          using p_owner, p_max_row, p_min_row;
end;
/

set timing on
variable x refcursor
set autoprint on
exec get_result_set( null, 'WMSYS', 1, 3, :x )

exec get_result_set( null, 'WMSYS', 30, 33, :x )
begin 
get_result_set( '/*+ FIRST_ROWS */' , 'WMSYS', 1, 3, :x );
end;
/
begin 
get_result_set( '/*+ FIRST_ROWS */' , 'WMSYS', 30, 33, :x );
end;
/
begin 
get_result_set( '/*+ FIRST_ROWS */' , 'WMSYS', 7300, 7302, :x );
end;
/

