

create global temporary table
temp_table ( x int );

create table
real_table ( x int );

alter session set optimizer_goal=first_rows;
set autotrace traceonly explain
select * from temp_table;

select * from real_table;

create global temporary table t
( x int not null)
on commit preserve rows;

create index t_idx on t(x);

insert into t
select rownum
  from all_objects
 where rownum < 5;
set autotrace traceonly
alter session set optimizer_dynamic_sampling=0;

select *
  from big_table
 where object_id in ( select x from t );

alter session set optimizer_dynamic_sampling=1;

select *
  from big_table
 where object_id in ( select x from t );

alter session set optimizer_dynamic_sampling=2;

select *
  from big_table
 where object_id in ( select x from t );

set autotrace off
delete from t;

insert into t
select rownum
  from all_objects;

set autotrace traceonly
select *
  from big_table
 where object_id in ( select x from t );

select /*+ USE_NL(t big_table) */ *
  from big_table,
      (select /*+ INDEX_FFS(T T_IDX) */ distinct x from t ) t
 where object_id = x;


