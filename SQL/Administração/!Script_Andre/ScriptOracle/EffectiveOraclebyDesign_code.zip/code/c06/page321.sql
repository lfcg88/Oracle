

show parameter db_file_multi

set autotrace traceonly explain
select * from big_table;

alter session set db_file_multiblock_read_count = 32;

select * from big_table;

alter session set db_file_multiblock_read_count = 64;

select * from big_table;

alter session set events 
'10046 trace name context forever, level 12';

alter session set db_file_multiblock_read_count = 5000000;

show parameter db_cache_size;

alter system set db_cache_size=32m;

alter system set db_16k_cache_size=32m;

create tablespace sixteen_k
blocksize 16k
extent management local
uniform size 2m
/
create table big_table_copy_16k
TABLESPACE sixteen_k
as
select * from big_table.big_table;

analyze table big_table_copy_16k  
compute statistics for table;

select /*+ noparallel(b) full(b) */ count(*) 
from big_table_copy_16k b;

select /*+ noparallel(b) full(b) */ count(*) 
from big_table.big_table b;

set autotrace traceonly explain
select /*+ noparallel(b) full(b) */ count(*)
  from big_table_copy_4k b;
select /*+ noparallel(b) full(b) */ count(*)
  from big_table.big_table b;

select /*+ noparallel(b) full(b) */ count(*)
  from big_table_copy_16k b;


