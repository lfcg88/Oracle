
create table emp as select * from scott.emp;

create table dept as select * from scott.dept;
create or replace
function my_function(p_str in varchar2) return varchar2
deterministic
as
begin
        return initcap(p_str);
end;
/
create index dept_idx_custom on dept(my_function(dname));
create index dept_idx_builtin on dept(initcap(dname));

create materialized view emp_dept
build immediate
refresh on demand
enable query rewrite
as
select dept.deptno, dept.dname, count (*)
  from emp, dept
 where emp.deptno = dept.deptno
 group by dept.deptno, dept.dname
/

begin 
dbms_stats.set_table_stats( user, 'EMP', numrows => 100000 );
dbms_stats.set_table_stats( user, 'DEPT', numrows =>  1000 );
dbms_stats.set_table_stats( user, 'EMP_DEPT', numrows =>  1000 );
end;
/

alter session set query_rewrite_enabled=true;

alter session set query_rewrite_integrity=enforced;

set autotrace traceonly explain

select dept.deptno, dept.dname, count (*)
  from emp, dept
 where emp.deptno = dept.deptno
 group by dept.deptno, dept.dname
/


select count(*) from emp;

select * from dept where initcap(dname) = 'Sales';

select * from dept where my_function(dname) = 'Sales';

set autotrace off


alter table dept
add constraint dept_pk primary key(deptno)
RELY enable NOVALIDATE;


alter table emp
add constraint emp_fk_dept
foreign key(deptno) references dept(deptno)
RELY enable NOVALIDATE;

alter table emp modify deptno not null NOVALIDATE;

set autotrace traceonly explain

select count(*) from emp;

alter session set query_rewrite_integrity=trusted;


select count(*) from emp;

select * from dept where my_function(dname) = 'Sales';

set autotrace off

insert into emp(empno,deptno) values ( 1,10 );


commit;


set autotrace traceonly explain

select count(*) from emp;

alter session set query_rewrite_integrity=stale_tolerated;


select count(*) from emp;


