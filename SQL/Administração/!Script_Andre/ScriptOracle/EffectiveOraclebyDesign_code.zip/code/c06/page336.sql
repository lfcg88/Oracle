
                                                                                                             
create table t
as
select mod(object_id,10) id, a.*
  from all_objects a;

analyze table t compute statistics
for table
for columns id;
alter system flush shared_pool;

alter session set events 
10053 trace name context forever, level 1';

alter session set optimizer_max_permutations=80000;

explain plan for
select /* omp = 80000 */ count(*)
  from t t1, t t2, t t3, t t4, t t5, t t6
 where t1.id = t2.id
   and t1.id = t3.id
   and t1.id = t4.id
   and t1.id = t5.id
   and t1.id = t6.id;
