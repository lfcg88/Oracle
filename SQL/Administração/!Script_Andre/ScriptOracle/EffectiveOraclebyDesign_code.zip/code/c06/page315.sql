
alter system flush shared_pool;

alter session set optimizer_index_cost_adj=100;

alter session set optimizer_index_caching=0;

begin
   dbms_stats.import_system_stats
   ( stattab => 'SYSTEM_STATS', statid => 'OLTP', statown => user );
end;
/

set autotrace traceonly explain
select /* TAGGED OLTP */ *
  from t1, t2
 where t1.id = t2.id
   and t2.id between 50 and 55;

select * from sys.aux_stats$;
begin
   dbms_stats.import_system_stats
   ( stattab => 'SYSTEM_STATS', statid => 'DW', statown => user );
end;
/


select /* TAGGED DW */ *
  from t1, t2
 where t1.id = t2.id
   and t2.id between 50 and 55;

begin
   dbms_stats.import_system_stats
   ( stattab => 'SYSTEM_STATS', statid => 'MIXED', statown => user );
end;
/

select /* TAGGED MIXED */ *
  from t1, t2
 where t1.id = t2.id
   and t2.id between 50 and 55;

select * from big_table OLTP;

select * from big_table OLTP where owner = 'ORDSYS';

