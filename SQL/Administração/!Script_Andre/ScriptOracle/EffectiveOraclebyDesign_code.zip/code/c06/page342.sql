
set autotrace traceonly explain

alter session set optimizer_mode=all_rows;

select t1.object_name, t2.object_name
  from big_table t1, big_table t2
 where t1.object_id = t2.object_id
   and t1.owner = 'WMSYS'
/

alter session set optimizer_mode=first_rows;

select t1.object_name, t2.object_name
  from big_table t1, big_table t2
 where t1.object_id = t2.object_id
   and t1.owner = 'WMSYS'
/
alter session set sql_trace=true;

declare
   cursor all_rows is
   select /*+ ALL_ROWS */ t1.object_name a, t2.object_name b
      from big_table t1, big_table t2
     where t1.object_id = t2.object_id
       and t1.owner = 'WMSYS';

   cursor first_rows is
   select /*+ FIRST_ROWS */ t1.object_name a, t2.object_name b
      from big_table t1, big_table t2
     where t1.object_id = t2.object_id
       and t1.owner = 'WMSYS';

   l_rec all_rows%rowtype;
begin
   open all_rows;
   fetch all_rows into l_rec;
   close all_rows;

   open first_rows;
   fetch first_rows into l_rec;
   close first_rows;
end;
/

