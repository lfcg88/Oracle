
create or replace procedure oltp_style
as
    l_rec big_table%rowtype;
    l_n   number;
begin
    for i in 1 .. 10000
    loop
        l_n := trunc( dbms_random.value( 2, 1000000 ) );
        select * into l_rec from big_table where id = l_n;
    end loop;
end;
/
create or replace procedure dw_style
as
    l_n number;
begin
    select count(*) into l_n
      from (
    select /*+ USE_HASH(t1,t2) 
               FULL(t1) FULL(t2) 
               NOPARALLEL(t1) NOPARALLEL(t2) */
           t1.data_object_id, t2.data_object_id
      from big_table t1, big_Table t2
     where t1.id = t2.id
           );
end;
/
exec dbms_stats.drop_stat_table( user, 'SYSTEM_STATS' );
exec dbms_stats.create_stat_table( user, 'SYSTEM_STATS' );
exec dbms_stats.delete_system_stats;


declare
    n number;
begin
    oltp_style;
    dbms_job.submit( n, 'oltp_style;' );
    dbms_job.submit( n, 'oltp_style;' );
    dbms_job.submit( n, 'oltp_style;' );
    commit;

    dbms_stats.gather_system_stats( gathering_mode => 'START',
                                    stattab => 'SYSTEM_STATS',
                                    statid => 'OLTP' );

    select count(*) into n from user_jobs where what = 'oltp_style;';
    while ( n > 0 )
    loop
        dbms_lock.sleep(5);
        select count(*) into n from user_jobs where what = 'oltp_style;';
    end loop;

    dbms_stats.gather_system_stats( gathering_mode => 'STOP',
                                    stattab => 'SYSTEM_STATS',
                                    statid => 'OLTP' );
end;
/



For the data warehouse simulation, we use these DBMS_JOB.SUBMIT calls:
    dw_style;
    dbms_job.submit( n, 'dw_style;' );
    dbms_job.submit( n, 'dw_style;' );
    dbms_job.submit( n, 'dw_style;' );
    dbms_job.submit( n, 'dw_style;' );
    commit;

For the mixed workload simulation, use these DBMS_JOB.SUBMIT calls:
    dbms_job.submit( n, 'dw_style;' );
    dbms_job.submit( n, 'dw_style;' );
    dbms_job.submit( n, 'dw_style;' );
    dbms_job.submit( n, 'oltp_style;' );
    dbms_job.submit( n, 'oltp_style;' );
    dbms_job.submit( n, 'oltp_style;' );
    commit;

