
set autotrace traceonly explain

alter session set sort_area_size = 102400000;

alter session set hash_area_size = 204800000;

select a.object_type, b.object_name
  from big_table a, big_table b
 where a.last_ddl_time = b.last_ddl_time;

alter session set sort_area_size = 65536;

alter session set hash_area_size = 131072;

select a.object_type, b.object_name
  from big_table a, big_table b
 where a.last_ddl_time = b.last_ddl_time;

