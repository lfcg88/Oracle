
create table t
as
select *
  from all_objects;

create or replace function get_row_cnt return number
as
        l_cnt   number;
begin
        select count(*)
          into l_cnt
      from t;
        return l_cnt;
end;
/

show parameter optimizer_features

alter session set sql_trace=true;

alter session set optimizer_goal=first_rows;

exec dbms_output.put_line( get_row_cnt );

alter system 
set optimizer_features_enable = '8.1.5' scope = spfile;

