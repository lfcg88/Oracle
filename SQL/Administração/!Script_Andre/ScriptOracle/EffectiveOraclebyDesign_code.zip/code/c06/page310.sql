
alter session set optimizer_index_cost_adj = 50;

alter session set optimizer_index_caching = 0;

select *
  from t1, t2
 where t1.id = t2.id
   and t2.id between 50 and 55;

