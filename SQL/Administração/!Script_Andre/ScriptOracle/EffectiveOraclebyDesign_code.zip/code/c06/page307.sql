create table  t1
as
select mod(rownum,1000) id, rpad('x',300,'x') data
  from all_objects
 where rownum <= 5*1000;

create table  t2
as
select rownum id, rpad('x',300,'x') data
  from all_objects
 where rownum <= 1000;

create index t1_idx on t1(id);

create index t2_idx on t2(id);

begin
   dbms_stats.gather_table_stats
   ( user, 'T1', method_opt => 'for all indexed columns',
     cascade=>true );
   dbms_stats.gather_table_stats
   ( user, 'T2', method_opt => 'for all indexed columns',
     cascade=>true );
end;
/
set autotrace traceonly  explain

select *
  from t1, t2
 where t1.id = t2.id
   and t2.id between 50 and 55;

alter session set optimizer_index_caching = 50;

select *
  from t1, t2
 where t1.id = t2.id
   and t2.id between 50 and 55;

