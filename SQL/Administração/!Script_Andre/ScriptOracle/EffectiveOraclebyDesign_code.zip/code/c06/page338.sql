
create table iot( x int primary key ) organization index;

create table normal ( x int primary key );
alter session set optimizer_mode=choose;

set autotrace traceonly explain

select * from iot;

select * from normal;

select n1.x, n2.x 
from normal n1 full outer join normal n2 on (n1.x = n2.x);

select /*+ ordered */ * from normal;
select * from iot, normal;

analyze table normal compute statistics;
select * from normal;

