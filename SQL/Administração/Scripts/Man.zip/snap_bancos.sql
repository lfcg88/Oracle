Prompt ###############################################
Prompt #                                             #
Prompt #           REFRESH SNAPSHOT CAMBT001         #
Prompt #               EM TODAS AS BASES             #
Prompt #                                             #
Prompt ###############################################


ACCEPT SENHA CHAR PROMPT 'Digite a senha do SYSTEM:' HIDE


conn system/&senha@bad0
@onde

@snap_prob.sql

conn system/&senha@bhd1
@onde

@snap_prob.sql


conn system/&senha@bod0
@onde

@snap_prob.sql


conn system/&senha@dfd0
@onde

@snap_prob.sql


conn system/&senha@fld0
@onde
@snap_prob.sql

conn system/&senha@fzd0
@onde

@snap_prob.sql


conn system/&senha@mia0
@onde

@snap_prob.sql


conn system/&senha@mia1
@onde

@snap_prob.sql


conn system/&senha@mia2
@onde

@snap_prob.sql


conn system/&senha@ped0
@onde

@snap_prob.sql


conn system/&senha@rjd10
@onde

@snap_prob.sql


conn system/&senha@rjd11
@onde

@snap_prob.sql


conn system/&senha@ped0
@onde

@snap_prob.sql


conn system/&senha@rjd3
@onde

@snap_prob.sql




conn system/&senha@rjd5
@onde

@snap_prob.sql


conn system/&senha@rjd6
@onde

@snap_prob.sql


conn system/&senha@dftpux01
@onde

@snap_prob.sql


conn system/&senha@spd1
@onde

@snap_prob.sql



conn system/&senha@rsd0
@onde

@snap_prob.sql



