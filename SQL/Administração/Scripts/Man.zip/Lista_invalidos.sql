Prompt #############################################################
Prompt #                                                           #
Prompt #                     Lista todos os                        #
Prompt #                   objetos inv�lidos                       #
Prompt #                                                           #
Prompt #############################################################

set verify off
set heading off
COL OBJECT_TYPE FORMAT A20
COL OBJETO FORMAT A40

SELECT OBJECT_TYPE , OWNER||'.'||OBJECT_NAME OBJETO, TO_CHAR(LAST_DDL_TIME, 'DD/MM/YY HH24:MI:SS') LAST_DDL_TIME
FROM ALL_OBJECTS
WHERE STATUS = 'INVALID'
AND OBJECT_TYPE <> 'UNDEFINED'
/

CLEAR COLUMNS
set verify on
set heading oN

