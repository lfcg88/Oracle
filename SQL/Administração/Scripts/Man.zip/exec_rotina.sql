spool C:\Licio\Atividades\20091002\MDF_2686\MDF_2686.log

@onde

@lista_invalidos

@lista_proc
SCQ.ACERTA_CARGA_AIRJ

@C:\Licio\Atividades\20091002\MDF_2686\SCQ.ACERTA_CARGA_AIRJ_ddl.sql

@lista_proc
SCQ.ACERTA_CARGA_AISP

@C:\Licio\Atividades\20091002\MDF_2686\SCQ.ACERTA_CARGA_AISP_ddl.sql

@lista_proc
SCQ.ACERTA_CARGA_DP

@C:\Licio\Atividades\20091002\MDF_2686\SCQ.ACERTA_CARGA_DP_ddl.sql

@lista_proc
SCQ.CARGA_AIRJ

@C:\Licio\Atividades\20091002\MDF_2686\SCQ.CARGA_AIRJ_ddl.sql

@lista_proc
SCQ.CARGA_AISP

@C:\Licio\Atividades\20091002\MDF_2686\SCQ.CARGA_AISP_ddl.sql

@lista_proc
SCQ.CARGA_DP

@C:\Licio\Atividades\20091002\MDF_2686\SCQ.CARGA_DP_ddl.sql


@compila_todos_invalidos
