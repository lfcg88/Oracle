Prompt #############################################################
Prompt #                                                           #
Prompt #              Count na tabela usando ROWID                 #
Prompt #                                                           #
Prompt #############################################################


select count(rowid) from &tabela
/
